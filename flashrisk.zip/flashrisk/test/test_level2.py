"""Round-trip test for nexrad_l2: build a synthetic Archive II volume, serve it with byte ranges."""
import bz2, gzip, json, math, struct, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import nexrad_l2 as L2

NG, FIRST, GW, SCALE, OFFSET = 1832, 2125, 250, 2.0, 66.0
LAT, LON = 27.7055, -82.4017


def msg31(az, elev_num, elev_angle, ms, mjd, gates):
    vol = b"RVOL" + struct.pack(">HBB", 44, 1, 0) + struct.pack(">ff", LAT, LON) + bytes(44 - 16)
    ref = b"DREF" + struct.pack(">IHHHHhBBff", 0, NG, FIRST, GW, 0, 0, 0, 8, SCALE, OFFSET) + gates
    nblk = 2
    hdr_len = 32 + 4 * nblk
    ptr_vol, ptr_ref = hdr_len, hdr_len + len(vol)
    dh = b"KTBW" + struct.pack(">IHHfBBHBBBBfBBH", ms, mjd, 1, az, 0, 0, 0, 1, 0, elev_num, 1, elev_angle, 0, 0, nblk)
    dh += struct.pack(">II", ptr_vol, ptr_ref)
    payload = dh + vol + ref
    if len(payload) % 2:
        payload += b"\0"
    size_hw = (16 + len(payload)) // 2
    mh = struct.pack(">HBBHHIHH", size_hw, 0, 31, 0, mjd, ms, 1, 1)
    return bytes(12) + mh + payload


def legacy(mtype):
    mh = struct.pack(">HBBHHIHH", 1200, 0, mtype, 0, 0, 0, 1, 1)
    return (bytes(12) + mh).ljust(2432, b"\0")


def build():
    mjd = (1793736000 // 86400) + 1          # 2026-11-03
    ms = (18 * 3600 + 48 * 60) * 1000
    out = bytearray(b"AR2V0006.001" + struct.pack(">II", mjd, ms) + b"KTBW")
    def rec(raw):
        c = bz2.compress(raw)
        out.extend(struct.pack(">i", len(c)) + c)
    rec(b"".join(legacy(t) for t in (15, 13, 18, 3, 5, 2)))
    radials = []
    for i in range(720):
        az = (i * 0.5 + 0.25) % 360
        # a reflectivity ring 40-60 km out, strongest due east
        g = bytearray(NG)
        for k in range(NG):
            r_km = (FIRST + k * GW) / 1000
            if 40 <= r_km <= 60:
                dbz = 20 + 35 * max(0.0, math.cos(math.radians(az - 90)))
                g[k] = int(dbz * SCALE + OFFSET)
        radials.append(msg31(az, 1, 0.48, ms + i * 30, mjd, bytes(g)))
    for j in range(0, 720, 120):                              # 6 records of elevation 1
        rec(b"".join(radials[j:j + 120]))
    rec(b"".join(msg31(a * 0.5, 2, 0.48, ms, mjd, bytes(NG)) for a in range(120)))   # elevation 2
    rec(b"".join(msg31(a * 0.5, 3, 0.88, ms, mjd, bytes(NG)) for a in range(720)))   # never needed
    return bytes(out)


VOLUME = build()
calls = []


def fake_fetch(url, headers=None):
    if url.startswith(L2.BUCKET + "?list-type=2"):
        xml = ('<?xml version="1.0"?><ListBucketResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">'
               "<IsTruncated>false</IsTruncated>"
               "<Contents><Key>2026/11/03/KTBW/KTBW20261103_184812_V06</Key></Contents>"
               "<Contents><Key>2026/11/03/KTBW/KTBW20261103_184812_V06_MDM</Key></Contents>"
               "<Contents><Key>2026/11/03/KTBW/KTBW20261103_185301_V06</Key></Contents>"
               "</ListBucketResult>")
        return 200, "application/xml", xml.encode(), "fake"
    rng = (headers or {}).get("Range")
    calls.append(rng)
    a, b = map(int, rng.split("=")[1].split("-"))
    if a >= len(VOLUME):
        return 416, "text/plain", b"", "fake"
    return 206, "application/octet-stream", VOLUME[a:b + 1], "fake"


scans = L2.list_scans(fake_fetch, "KTBW", "2026/11/03")
assert [k for k, _ in scans] == ["2026/11/03/KTBW/KTBW20261103_184812_V06", "2026/11/03/KTBW/KTBW20261103_185301_V06"], scans
assert scans[0][1] == 1793731692, scans[0][1]
print("S3 listing parse: ok", scans)

L2.CHUNK = 200_000
meta, az, gates = L2.lowest_reflectivity(fake_fetch, "2026/11/03/KTBW/KTBW20261103_184812_V06")
assert meta["nrad"] == 720 and meta["ngates"] == NG and meta["first_m"] == FIRST and meta["gate_m"] == GW, meta
assert abs(meta["lat"] - LAT) < 1e-4 and abs(meta["lon"] - LON) < 1e-4
assert meta["elev"] == 0.48 and meta["elev_num"] == 1
assert time_ok if (time_ok := abs(meta["time"] - 1793731680) < 1) else False, meta["time"]
assert az == sorted(az) and len(gates) == 720 * NG
east = az.index(min(az, key=lambda a: abs(a - 90.25)))
k50 = round((50000 - FIRST) / GW)
dbz = (gates[east * NG + k50] - OFFSET) / SCALE
assert 54 <= dbz <= 55.5, dbz
print("lowest sweep: ok  bytes read %d of %d (%.0f%%), %d range requests" % (meta["bytes_read"], len(VOLUME), 100 * meta["bytes_read"] / len(VOLUME), len(calls)))

blob = L2.pack(meta, az, gates)
hl = struct.unpack_from("<I", blob)[0]
assert (4 + hl) % 4 == 0
h = json.loads(blob[4:4 + hl])
assert h["nrad"] == 720
print("pack: ok, payload %d KB raw, %d KB gzipped" % (len(blob) // 1024, len(gzip.compress(blob, 5)) // 1024))
