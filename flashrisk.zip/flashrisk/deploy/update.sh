#!/bin/bash
# Install a new FlashRisk version on the droplet.
# 1. From your Mac:   scp ~/Downloads/flashrisk.zip root@YOUR_DROPLET_IP:/root/
# 2. On the droplet:  bash /opt/flashrisk/deploy/update.sh
set -euo pipefail
ZIP=/root/flashrisk.zip
[ -f "$ZIP" ] || { echo "Upload the new flashrisk.zip to /root first."; exit 1; }
rm -rf /tmp/flashrisk-new && mkdir -p /tmp/flashrisk-new
unzip -q "$ZIP" -d /tmp/flashrisk-new
cp -a /tmp/flashrisk-new/flashrisk/. /opt/flashrisk/
chown -R flashrisk:flashrisk /opt/flashrisk
systemctl restart flashrisk
sleep 2
curl -fsS -o /dev/null http://127.0.0.1:8787/map && echo "Updated. FlashRisk is running." || echo "Updated, but FlashRisk isn't answering (see: journalctl -u flashrisk -n 50)"
