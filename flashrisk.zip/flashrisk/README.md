# FlashRisk

One map, one product: flood likelihood (%) from MRMS FLASH **CREST max unit streamflow**, the **mean of the 1, 3 and 6 h QPE÷FFG ratios** and **CREST soil saturation**, drawn as regional shading with labelled contours.

## Run

```
python3 serve.py        # then open http://localhost:8787
```

`serve.py` serves the map and relays the NOAA data (those servers block direct browser requests). It listens on this computer only. `http://localhost:8787/api/check` tests every data source. The Mac launcher (`Start FlashRisk.command`) opens the landing page; its Enter button goes to the map at `http://localhost:8787/map`.

## Map layout

A control banner runs across the top, split into groups:
- **Brand**: status and frame time.
- **Loop**: play/step/length, scrub, speed.
- **Next update**: risk map and radar countdowns.
- **Contours**: Standard / Every 5%; Both / Lines / Shading; opacity.
- **Radar and warnings**: on/off, radar search, opacity, and separate switches for warnings and storm reports (both remembered).
- **Export** and **Equation**: drop-down panels; Esc or a click elsewhere closes them.

A one-line status strip under the groups carries the loop status, frame notes (missing inputs, storm motion in view), radar scan, warnings count and any errors. The map fills the rest. Floating over it:
- the risk flash (top left, after each update)
- the point chart (bottom left once you click the map; × removes the point)
- the legend (bottom right)

The banner scrolls sideways on narrow screens.

## Speed

All data work runs in background workers (two to four, by CPU count), so the page stays responsive while frames load and update:
- downloading each GRIB2 file and decoding it with the browser's own decompressor
- reducing it to the 0.05° regional grid
- building each frame (equation and storm motion)
- rendering radar sweeps

Reductions are cached per file, so files shared between frames are decoded once. On a test feed at the full national MRMS size (7,000 × 3,500), the page's own thread was busy for 3.4 s in total during a full 2 h load (longest single stall 0.2 s), compared with about 4 minutes before. A zoom step with radar on settles in about 40 ms, down from about 4 s.

## How the map is built

1. Load the FLASH GRIB2 grids: `CREST_MAXUNITSTREAMFLOW`, `QPE_FFG01H`, `QPE_FFG03H`, `QPE_FFG06H`, `CREST_MAXSOILSAT` (1 km).
2. Aggregate to a fixed 0.05° (~5 km) regional grid: block maximum of streamflow and ratios, block mean of soil saturation.
3. Per regional cell: `R̄ = mean(QPE/FFG 1h, 3h, 6h)`, then `P = floodPercent(Q, R̄, S)`.
4. Smooth P with a ~25 km box blur, trace contours once with d3-contour, and fill the bands between them. Contour levels: **Standard** (5, 10, 25, 40, 55, 70, 85%) or **Every 5%** (5–95%; the odd fives are dashed). An opacity slider sets the fill and line strength.

Because the grid and contours are computed once per data update (not per view), zooming only scales the same field.

## Loop and radar

- The loop reads the directory listings and builds one frame every 5 min (on the :00/:05 marks) over the last 30 min, 1 h or 2 h (radar Level II lists only reach back about 2 h, so longer loops were dropped).
- **A frame is shown only when all of its data is in.** Its inputs are the five FLASH grids (CREST streamflow, QPE/FFG 1/3/6 h, soil saturation). Rain rate for storm motion is optional and never holds a frame.
  - Each input uses its newest file valid at or before the frame time, and that file must be final: either the product's next file would come after the frame time, or the feed has already posted past it (a skipped file isn't coming).
  - So a :10 frame waits for the 10-min CREST and soil files, not just the 2-min QPE/FFG files. A :05 frame correctly uses the :00 CREST.
  - If any download fails, the frame isn't built and is retried on the next pull. Frames are never shown from partial data and never rebuilt once shown.
  - While the newest frame is waiting, the Risk update box says how many inputs it's waiting on (hover for which ones), and the loop line names them. A refresh only loads frames it doesn't already have and keeps you on the frame you're viewing. Play/pause, step, scrub and speed (1×, 2×, 4×, 6×). Keys: space, ← →, + and −.
- **Update clock**. *Risk update* counts down to the next pull: frames are built on the :00/:05 marks, so the page pulls about 100 s after each mark (time for the FLASH files to post), then every 45 s until the new frame is there (every 2.5 min if the feed looks stalled; the box turns amber and says "data late"). *Next scan* counts down to when the selected radar's next volume should be listed: newest volume time + the site's typical volume interval (median of recent gaps, so it follows the VCP) + the posting delay measured on recent volumes. From 20 s before that it checks every 30 s; overdue time shows as +m:ss, and the box flashes when a new volume lands.
- **Risk flash.** Each new frame flashes the card and the flood layer and reports, for the area on screen: the peak likelihood and its change, the point probe's value and change if one is placed, and the biggest rise. A pulsing ring marks the spot that rose most (≥5 points); tap the flash to fly there.
- Radar is one WSR-88D site at a time, chosen with the search box in the banner (type an identifier like KMLB or MLB, the office, or the city; ↑/↓ and Enter work; picking a site turns radar on and moves the map to it), with an on/off switch that keeps the chosen site and an opacity slider (remembered between visits). It is raw NEXRAD Level II from the NOAA/Unidata archive on AWS (`s3://unidata-nexrad-level2`, keys `YYYY/MM/DD/SITE/SITEyyyymmdd_hhmmss_V06`). `serve.py` lists the volumes (`/api/l2/list`), reads each one with HTTP byte ranges until the lowest elevation is complete, and returns that 0.5° reflectivity sweep (`/api/l2/scan`, decoder in `nexrad_l2.py`, standard library bz2). A background worker draws each sweep once, in the NWS dBZ colors, into a Web-Mercator image of its full 460 km range, and the map shows it as an image overlay. Zooming and panning only rescale the image, and only the scan for the frame on screen is on the map. While looping, each frame shows the volume nearest its time (within 8 min); paused on the newest frame it shows the newest volume.

## Storm motion

MRMS rain rate now and 20 min earlier are matched tile by tile to measure how the rain is moving. The frame note and the contour graphic report the motion of the storms in the area on screen, in mph with a compass direction. Rain rate is optional: if it isn't posted yet, the frame still shows, just without the motion line.

## Warnings, reports and the point probe

- **Warnings & flood reports** (Radar section switch): NWS flash flood / flood warning polygons (emergencies in magenta) and flood-related storm reports for the selected radar's office, from the Iowa State archive (`/geojson/sbw.py`, `/geojson/lsr.py`), shown as they stood at each frame time.
- **Point**: click the map to place a probe. The chart plots the likelihood there across the loop, marks the first Flash Flood Warning / Emergency covering the point, and reports how far ahead of or behind them it crossed 50% and 70%.

## Export

In the **Export** section of the card:

- **Loop animation: GIF or video.** Renders every loaded frame of the map as you see it: background map, radar sweep at its opacity, contour shading and labels, warnings and reports, probe and rise marker. A title block (time, radar scan) and the legend are burned in. Frame timing follows the loop speed, and the last frame holds. Width 640 / 960 / 1280 px or the full map. GIF is encoded in the browser with [gifenc](https://github.com/mattdesl/gifenc). Video is recorded in real time from a canvas (MP4 where the browser supports it, otherwise WebM), so it takes as long as one pass of the loop. While exporting, the map is locked and auto-refresh waits. If the background tile server doesn't allow its tiles to be copied, the export uses a plain background and says so.
- **Contour graphic (PNG)**, 1920×1080 or 3840×2160, dark or light, with your own title. Contours only, no radar or background map. It has shading, labelled lines, state and county borders at every zoom (US Census via `us-atlas`), city names, lat/lon ticks, a scale bar and your point if one is placed. City names come from `data/us_places.tsv` (10,435 US places of 2,500+ people, from GeoNames, CC BY 4.0), served by `serve.py`. They're placed largest first, each tried in eight positions around its dot, and skipped where they'd collide with another name, a contour label or the point. Beside the map: valid time (UTC and local), peak likelihood in view, the legend, storm motion and a one-line method note. It uses the frame, contour levels and area currently on screen, re-projected in Web Mercator to fill the panel. Marked "Experimental · not an official NWS product".

## The equation

```
P = 1 / (1 + e^(-z))
z = 0.6·2.2·ln(Q / 2.0) + 0.4·4.5·(R̄ − 1.00) + 3.0·(S − 0.70)
```

- Q = CREST max unit streamflow (m³ s⁻¹ km⁻²), R̄ = mean of the 1/3/6 h QPE÷FFG ratios (1.00 = 100%), S = CREST max soil saturation (0–1).
- If Q or R̄ is missing, the other carries the full 1.0 weight; if S is missing its term is dropped.
- Q and R̄ anchors (2.0 and 100%) come from the NWS Memphis FLASH study. The weights, slopes and the soil term (S50 = 0.70, kS = 3.0) are our own starting choices and have not been fit to flood reports.
- Constants live in `EQ` in `src/core.js`; the page's Equation panel is generated from them.

## Rebuild / test

```
python3 build.py                                   # writes dist/index.html
python3 test/make_grib.py /tmp/t.grib2.gz && node test/test_core.js /tmp/t.grib2.gz
node test/test_motion.js                           # storm motion
python3 test/test_level2.py                        # Level II decoder
MOCK_LIVE_SPEED=20 python3 test/mock_server.py 8799   # offline mock of every live source on a fast virtual clock
```

## "Down for rest" page (Cloudflare Tunnel)

When FlashRisk is shared through a Cloudflare Tunnel and the Mac, `cloudflared` or `serve.py` isn't running, visitors normally see a Cloudflare error. `dist/worker.js` (built from `cloudflare/worker.template.js` and `src/offline.html`) is a Cloudflare Worker that passes every request through to the tunnel and shows the FlashRisk "Our servers are down for rest" page instead when the origin can't be reached. The page checks every minute and refreshes by itself once the site is back. Preview it locally at `http://localhost:8787/offline`.

This needs a named tunnel on your own domain in Cloudflare. A quick tunnel (`*.trycloudflare.com`) can't show it, because that link stops existing when the tunnel stops.

1. Run `python3 build.py`.
2. In the Cloudflare dashboard, create a Worker, open its code editor, replace everything with the contents of `dist/worker.js`, and deploy.
3. In the Worker's settings, add a **Route** (not a Custom Domain) for your tunnel's hostname, e.g. `flashrisk.example.com/*`.

After editing `src/offline.html`, rebuild and paste `dist/worker.js` again.
