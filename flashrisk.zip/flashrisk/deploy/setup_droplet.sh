#!/bin/bash
# One-time FlashRisk setup on a fresh Ubuntu DigitalOcean droplet.
# Run as root from the droplet console:
#   bash /opt/flashrisk/deploy/setup_droplet.sh "<your Cloudflare tunnel token>"
# Safe to run again; it just re-applies the same settings.
set -euo pipefail

APP=/opt/flashrisk
TOKEN="${1:-}"

if [ "$(id -u)" -ne 0 ]; then echo "Run this as root."; exit 1; fi
if [ ! -f "$APP/serve.py" ]; then echo "Can't find $APP/serve.py. Unzip flashrisk.zip into /opt first."; exit 1; fi

echo "== Installing packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -q
apt-get install -y -q python3 curl unzip ufw

echo "== Creating the flashrisk user"
id flashrisk >/dev/null 2>&1 || useradd --system --home "$APP" --shell /usr/sbin/nologin flashrisk
cd "$APP"
[ -f dist/index.html ] || python3 build.py
chown -R flashrisk:flashrisk "$APP"

echo "== Running FlashRisk as a service (starts on boot, restarts if it stops)"
cat > /etc/systemd/system/flashrisk.service <<EOF
[Unit]
Description=FlashRisk map and NOAA relay
After=network-online.target
Wants=network-online.target

[Service]
User=flashrisk
WorkingDirectory=$APP
ExecStart=/usr/bin/python3 $APP/serve.py 8787
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now flashrisk
systemctl restart flashrisk

echo "== Installing cloudflared"
if ! command -v cloudflared >/dev/null 2>&1; then
  mkdir -p --mode=0755 /usr/share/keyrings
  curl -fsSL https://pkg.cloudflare.com/cloudflare-main.gpg -o /usr/share/keyrings/cloudflare-main.gpg
  echo "deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] https://pkg.cloudflare.com/cloudflared any main" > /etc/apt/sources.list.d/cloudflared.list
  apt-get update -q
  apt-get install -y -q cloudflared
fi

if [ -n "$TOKEN" ]; then
  if systemctl list-unit-files | grep -q '^cloudflared.service'; then
    echo "   cloudflared service already installed; leaving it as is."
  else
    cloudflared service install "$TOKEN"
  fi
else
  echo "   No tunnel token given. Re-run with the token to connect flashrisk.net."
fi

echo "== Firewall: allow SSH only (the tunnel needs no open ports)"
ufw allow OpenSSH >/dev/null
ufw --force enable >/dev/null

echo
sleep 2
if curl -fsS -o /dev/null http://127.0.0.1:8787/map; then echo "FlashRisk: running"; else echo "FlashRisk: NOT answering (see: journalctl -u flashrisk -n 50)"; fi
if systemctl is-active --quiet cloudflared 2>/dev/null; then echo "Tunnel:    connected"; else echo "Tunnel:    not running yet"; fi
