"""Mock of every live data source, for offline end-to-end tests of FlashRisk.

Serves the page (argv[2], default dist/index.html) and the static files next to it, plus:
  /api/relay?url=  mrms.ncep.noaa.gov directory listings + synthetic MRMS/FLASH GRIB2 files,
                   NWS radar site list, IEM warnings/storm reports
  /api/l2/list, /api/l2/scan   synthetic KMLB Level II
  /clock           the virtual clock the mock runs on (give the page the same one)
Live time runs on a virtual clock inside 2026-11-02 so 5-min updates can be tested in seconds:
vnow = V0 + (real - R0) * K, with MOCK_LIVE_HOUR (V0, UTC hour on Nov 2) and MOCK_LIVE_SPEED (K).
One synthetic rain history drives every product: a storm approaches Palm Bay from the west,
stalls over it 09-15Z (training), then moves offshore; QPE, QPE/FFG, CREST and soil are all
integrated from the same rain-rate field.
"""
import calendar, gzip, http.server, io, json, math, re, socketserver, struct, sys, pathlib, urllib.parse
import png

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import nexrad_l2 as L2

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8799
PAGE = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / "dist" / "index.html"
DAY0 = calendar.timegm((2026, 11, 2, 0, 0, 0))
CADENCE = {"CREST_MAXUNITSTREAMFLOW": 600, "CREST_MAXSOILSAT": 600, "QPE_FFG01H": 120, "QPE_FFG03H": 120, "QPE_FFG06H": 120}
# grid: Florida peninsula at 0.02 deg, or MOCK_GRID=conus for the real MRMS size (7000 x 3500 at 0.01 deg)
import os
if os.environ.get("MOCK_GRID") == "conus":
    NI, NJ, LA1, LO1, D = 7000, 3500, 54.995, -129.995, 0.01
else:
    NI, NJ, LA1, LO1, D = 300, 350, 30.99, -83.99, 0.02
CLAT, CLON = 28.03, -80.62
stats = {"grib": 0, "live_list": 0}
# Live mode runs on a virtual clock inside the storm day so updates can be tested quickly:
# vnow = V0 + (real - R0) * K. The test page is given the same clock (GET /clock).
import os, time as _time
CLOCK = {"v0": DAY0 + int(float(os.environ.get("MOCK_LIVE_HOUR", "7.5")) * 3600), "r0": _time.time(), "k": float(os.environ.get("MOCK_LIVE_SPEED", "20"))}
def vnow():
    return CLOCK["v0"] + (_time.time() - CLOCK["r0"]) * CLOCK["k"]
LIVE_LAG = 60   # a file posts this many (virtual) seconds after its valid time
LAG = {"CREST_MAXUNITSTREAMFLOW": int(os.environ.get("MOCK_CREST_LAG", "60")), "CREST_MAXSOILSAT": int(os.environ.get("MOCK_CREST_LAG", "60"))}


import numpy as np
# the storm only touches Florida, so fields are computed on that sub-box and padded with zeros
J0, J1 = max(0, int((LA1 - 31.5) / D)), min(NJ, int((LA1 - 24.0) / D) + 1)
I0, I1 = max(0, int((-84.5 - LO1) / D)), min(NI, int((-78.0 - LO1) / D) + 1)
LATS = (LA1 - np.arange(J0, J1) * D)[:, None]
LONS = (LO1 + np.arange(I0, I1) * D)[None, :]
FFG_MM = {1: 75.0, 3: 95.0, 6: 110.0}
CADENCE.update({"PrecipRate": 120, "RadarOnly_QPE_01H": 120, "RadarOnly_QPE_03H": 3600, "RadarOnly_QPE_06H": 3600})


def center(ts):
    """Storm core: approaches Palm Bay from the west, stalls (training) 09-15Z, then moves offshore."""
    h = (ts - DAY0) / 3600.0
    if h < 9.0:
        lon = CLON - 0.16 * (9.0 - h)
    elif h <= 15.0:
        lon = CLON
    else:
        lon = CLON + 0.20 * (h - 15.0)
    return CLAT, lon


def strength(ts):
    h = (ts - DAY0) / 3600.0
    return float(np.clip(0.45 + 0.11 * (h - 3), 0.45, 1.0)) if h <= 15 else max(0.3, 1.0 - 0.14 * (h - 15))


def rate_ll(lats, lons, ts):       # mm/h at any lat/lon arrays
    la, lo = center(ts)
    dx = (lons - lo) * np.cos(np.radians(lats)); dy = lats - la
    return 95.0 * strength(ts) * np.exp(-(dx * dx + dy * dy) / (2 * 0.17 ** 2))


def rate(ts):                      # mm/h on the MRMS grid
    return rate_ll(LATS, LONS, ts)


_cache = {}
def qpe(ts, hours):                # mm over the past `hours`, 10-min sampling
    key = (ts, hours)
    if key not in _cache:
        acc = np.zeros(LATS.shape[:1] + LONS.shape[1:])
        for k in range(int(hours * 6)):
            acc += rate(ts - (k + 0.5) * 600) / 6.0
        _cache[key] = acc
    return _cache[key]


def field(product, ts):
    if product == "PrecipRate":
        return rate(ts)
    if product.startswith("RadarOnly_QPE_"):
        return qpe(ts, int(product[-3:-1]))
    if product.startswith("QPE_FFG"):
        h = int(product[-3:-1])
        return 100.0 * qpe(ts, h) / FFG_MM[h]         # percent, as FLASH is read
    if product == "CREST_MAXUNITSTREAMFLOW":
        return 14.0 * np.power(qpe(ts, 1) / 80.0, 1.3)
    if product == "CREST_MAXSOILSAT":
        return np.minimum(99.0, 55.0 + 0.35 * qpe(ts, 6))
    raise KeyError(product)


def sec(num, body):
    return struct.pack(">IB", 5 + len(body), num) + body


def sm32(v):
    return struct.pack(">I", (abs(v) | 0x80000000) if v < 0 else v)


def grib(product, ts):
    Dsc = 1 if product in ("CREST_MAXUNITSTREAMFLOW", "PrecipRate") or product.startswith("RadarOnly_QPE_") else 0
    R = -9990.0 if Dsc else -999.0
    full = np.full((NJ, NI), -R, dtype=np.float64)                      # value 0 everywhere ...
    full[J0:J1, I0:I1] = np.rint(field(product, ts) * 10 ** Dsc - R)    # ... except the storm box
    raw = full.clip(0, 65535).astype(">u2")
    rows = np.zeros((NJ, 1 + 2 * NI), dtype=np.uint8); rows[:, 1:] = raw.view(np.uint8).reshape(NJ, 2 * NI)   # filter byte 0 per row
    def chunk(tag, data): return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", __import__("zlib").crc32(tag + data) & 0xffffffff)
    buf = io.BytesIO(); buf.write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", NI, NJ, 16, 0, 0, 0, 0)) +
                                 chunk(b"IDAT", __import__("zlib").compress(rows.tobytes(), 1)) + chunk(b"IEND", b""))
    y, mo, d, hh, mi, ss = __import__("time").gmtime(ts)[:6]
    s1 = sec(1, struct.pack(">HHBBBHBBBBBBB", 161, 0, 1, 1, 1, y, mo, d, hh, mi, ss, 0, 0))
    t = struct.pack(">BBIBIBI", 6, 0, 0, 0, 0, 0, 0) + struct.pack(">IIII", NI, NJ, 0, 0xFFFFFFFF)
    t += sm32(round(LA1 * 1e6)) + sm32(round((LO1 + 360) * 1e6)) + b"\x30"
    t += sm32(round((LA1 - (NJ - 1) * D) * 1e6)) + sm32(round((LO1 + 360 + (NI - 1) * D) * 1e6))
    t += struct.pack(">II", round(D * 1e6), round(D * 1e6)) + b"\x00"
    s3 = sec(3, struct.pack(">BIBBH", 0, NI * NJ, 0, 0, 0) + t)
    s4 = sec(4, struct.pack(">HHBB", 0, 0, 6, 0) + bytes(20))
    s5 = sec(5, struct.pack(">IH", NI * NJ, 41) + struct.pack(">f", R) + struct.pack(">HH", 0, Dsc) + struct.pack(">BB", 16, 0))
    body = s1 + s3 + s4 + s5 + sec(6, b"\xff") + sec(7, buf.getvalue())
    msg = b"GRIB\x00\x00\xd1\x02" + struct.pack(">Q", 16 + len(body) + 4) + body + b"7777"
    return gzip.compress(msg, 3)


def stamp(ts):
    return __import__("time").strftime("%Y%m%d-%H%M%S", __import__("time").gmtime(ts))


def poly(lat0, lat1, lon0, lon1):
    return {"type": "MultiPolygon", "coordinates": [[[[lon0, lat0], [lon1, lat0], [lon1, lat1], [lon0, lat1], [lon0, lat0]]]]}


SBW = {"type": "FeatureCollection", "features": [
    {"type": "Feature", "geometry": poly(27.85, 28.25, -80.85, -80.45),
     "properties": {"phenomena": "FF", "significance": "W", "eventid": 31, "issue": "2026-11-02T09:40:00Z", "expire": "2026-11-02T12:56:00Z",
                    "polygon_begin": "2026-11-02T09:40:00Z", "polygon_end": "2026-11-02T12:56:00Z", "is_emergency": False}},
    {"type": "Feature", "geometry": poly(27.80, 28.20, -80.80, -80.45),
     "properties": {"phenomena": "FF", "significance": "W", "eventid": 32, "issue": "2026-11-02T12:56:00Z", "expire": "2026-11-02T20:45:00Z",
                    "polygon_begin": "2026-11-02T12:56:00Z", "polygon_end": "2026-11-02T20:45:00Z", "is_emergency": True}}]}
LSR = {"type": "FeatureCollection", "features": [
    {"type": "Feature", "geometry": {"type": "Point", "coordinates": [-80.59, 28.03]},
     "properties": {"valid": "2026-11-02T09:16:00Z", "typetext": "FLOOD", "city": "Palm Bay", "remark": "Flooding at Jupiter Blvd and White St."}},
    {"type": "Feature", "geometry": {"type": "Point", "coordinates": [-80.66, 28.07]},
     "properties": {"valid": "2026-11-02T14:10:00Z", "typetext": "FLASH FLOOD", "city": "West Melbourne", "remark": "Airboat rescues in Wingate."}},
    {"type": "Feature", "geometry": {"type": "Point", "coordinates": [-80.58, 27.99]},
     "properties": {"valid": "2026-11-02T20:00:00Z", "typetext": "HEAVY RAIN", "magnitude": 24.1, "unit": "INCH", "city": "Malabar", "remark": "Storm total."}}]}


def l2_blob():
    import runpy
    ns = runpy.run_path(str(ROOT / "test" / "test_level2.py"))
    meta, az, gates = L2.lowest_reflectivity(ns["fake_fetch"], "2026/11/03/KTBW/KTBW20261103_184812_V06")
    meta["lat"], meta["lon"], meta["key"] = 28.1133, -80.6542, "mock"
    return L2.pack(meta, az, gates)


L2BLOB = l2_blob()


class H(http.server.BaseHTTPRequestHandler):
    def send(self, code, body, ctype):
        self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(body)))
        self.end_headers(); self.wfile.write(body)

    def do_GET(self):
        u = urllib.parse.urlparse(self.path); q = urllib.parse.parse_qs(u.query)
        if u.path in ("/", "/index.html"):
            return self.send(200, PAGE.read_bytes(), "text/html")
        if u.path == "/api/l2/list":
            s, e = int(q["start"][0]) // 1000, int(q["end"][0]) // 1000
            scans = [{"key": f"2026/11/02/KMLB/KMLB{stamp(t).replace('-', '_')}_V06", "t": t * 1000}
                     for t in range(s - s % 270, e, 270) if t <= vnow() - 90]
            return self.send(200, json.dumps({"site": "KMLB", "scans": scans}).encode(), "application/json")
        if u.path == "/api/l2/scan":
            return self.send(200, L2BLOB, "application/octet-stream")
        if u.path == "/api/relay":
            target = q.get("url", [""])[0]; t = urllib.parse.urlparse(target); tq = urllib.parse.parse_qs(t.query)
            lm = re.match(r"/2D/(?:FLASH/)?([A-Za-z0-9_]+)/$", t.path)
            if t.hostname == "mrms.ncep.noaa.gov" and lm:
                stats["live_list"] += 1
                prod, flash = lm.group(1), "FLASH_" if "/FLASH/" in t.path else ""
                cad = CADENCE.get(prod, 600); end = int(vnow()) - LAG.get(prod, LIVE_LAG)
                names = [f"MRMS_{flash}{prod}_00.00_{stamp(x)}.grib2.gz" for x in range(end - end % cad - 4 * 3600, end + 1, cad) if x <= end]
                body = "<html><body><pre>" + "".join(f'<a href="{n}">{n}</a>\n' for n in names) + "</pre></body></html>"
                return self.send(200, body.encode(), "text/html")
            fm = re.search(r"MRMS_(?:FLASH_)?([A-Za-z0-9_]+?)_00\.00_(\d{8})-(\d{6})\.grib2\.gz$", t.path)
            if t.hostname == "mrms.ncep.noaa.gov" and fm:
                stats["grib"] += 1
                d, hm = fm.group(2), fm.group(3)
                ts = calendar.timegm((int(d[:4]), int(d[4:6]), int(d[6:]), int(hm[:2]), int(hm[2:4]), int(hm[4:])))
                return self.send(200, grib(fm.group(1), ts), "application/octet-stream")
            if t.path.endswith("/geojson/sbw.py"):
                return self.send(200, json.dumps(SBW).encode(), "application/json")
            if t.path.endswith("/geojson/lsr.py"):
                return self.send(200, json.dumps(LSR).encode(), "application/json")
            if t.path.endswith("/geoserver/nws/ows"):
                return self.send(200, json.dumps({"features": [{"properties": {"rda_id": "KMLB", "name": "Melbourne", "wfo_id": "MLB", "lat": 28.1133, "lon": -80.6542}},
                                                               {"properties": {"rda_id": "KTBW", "name": "Tampa Bay", "wfo_id": "TBW", "lat": 27.7055, "lon": -82.4017}}]}).encode(), "application/json")
            return self.send(404, b"mock: not found", "text/plain")
        f = PAGE.parent / u.path.lstrip("/")
        if u.path.count("/") == 1 and f.is_file():
            return self.send(200, f.read_bytes(), "text/css" if f.suffix == ".css" else "application/javascript")
        if u.path == "/data/us_places.tsv":
            return self.send(200, (ROOT / "data" / "us_places.tsv").read_bytes(), "text/tab-separated-values")
        if u.path == "/clock":
            return self.send(200, json.dumps(dict(CLOCK, vnow=vnow())).encode(), "application/json")
        if u.path == "/stats":
            return self.send(200, json.dumps(stats).encode(), "application/json")
        return self.send(404, b"", "text/plain")

    def log_message(self, *a):
        pass


class S(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True; allow_reuse_address = True


if __name__ == "__main__":
    print("mock on", PORT, flush=True)
    S(("127.0.0.1", PORT), H).serve_forever()
