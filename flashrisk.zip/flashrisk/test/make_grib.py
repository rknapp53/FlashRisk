"""Write a tiny MRMS-style GRIB2 file (grid 3.0, PNG packing 5.41) for decoder tests."""
import io, struct, sys, gzip
import png

def sec(num, body):
    return struct.pack(">IB", 5 + len(body), num) + body

def sm32(v):  # sign-magnitude 32-bit
    return struct.pack(">I", (abs(v) | 0x80000000) if v < 0 else v)

def sm16(v):
    return struct.pack(">H", (abs(v) | 0x8000) if v < 0 else v)

ni, nj = 7, 5
la1, lo1 = 54.995, 230.005          # MRMS-style: north-west corner, 0-360 lon
dlat, dlon = -0.01, 0.01
la2, lo2 = la1 + dlat * (nj - 1), lo1 + dlon * (ni - 1)
R, E, D = -9990.0, 0, 1               # value = (R + X) / 10
# physical values we want back (unit streamflow), plus one missing (-999)
vals = [[(j * ni + i) * 0.5 for i in range(ni)] for j in range(nj)]
vals[2][3] = -999.0
raw = [[int(round(v * 10 ** D - R)) for v in row] for row in vals]

buf = io.BytesIO()
png.Writer(ni, nj, greyscale=True, bitdepth=16).write(buf, raw)
pngdata = buf.getvalue()

s1 = sec(1, struct.pack(">HHBBBHBBBBBBBB", 161, 0, 1, 1, 1, 2026, 11, 3, 17, 40, 0, 0, 0, 0)[:16])
s3body = struct.pack(">BIBH", 0, ni * nj, 0, 0)          # source, npoints, list octets, interp  (octets 6-14 -> 9 bytes)
s3body += struct.pack(">H", 0)                              # template 3.0 (octets 13-14)
s3body = s3body[:7] + struct.pack(">H", 0)                  # keep octet layout exact: 6..12 then 13-14
# rebuild precisely: octet6 source(1) octets7-10 npts(4) octet11 nOct(1) octet12 interp(1) octets13-14 template(2)
s3body = struct.pack(">BIBBH", 0, ni * nj, 0, 0, 0)
t = struct.pack(">B", 6) + struct.pack(">B", 0) + struct.pack(">I", 0) + struct.pack(">B", 0) + struct.pack(">I", 0) + struct.pack(">B", 0) + struct.pack(">I", 0)
t += struct.pack(">II", ni, nj) + struct.pack(">II", 0, 0xFFFFFFFF)
t += sm32(round(la1 * 1e6)) + sm32(round(lo1 * 1e6)) + struct.pack(">B", 48)
t += sm32(round(la2 * 1e6)) + sm32(round(lo2 * 1e6))
t += struct.pack(">II", round(abs(dlon) * 1e6), round(abs(dlat) * 1e6)) + struct.pack(">B", 0)
s3 = sec(3, s3body + t)
s4 = sec(4, struct.pack(">HH", 0, 0) + struct.pack(">BB", 6, 0) + bytes(20))  # nv, template 4.0, cat 6, par 0
s5 = sec(5, struct.pack(">IH", ni * nj, 41) + struct.pack(">f", R) + sm16(E) + sm16(D) + struct.pack(">BB", 16, 0))
s6 = sec(6, struct.pack(">B", 255))
s7 = sec(7, pngdata)
body = s1 + s3 + s4 + s5 + s6 + s7
total = 16 + len(body) + 4
out = b"GRIB" + b"\x00\x00" + bytes([209, 2]) + struct.pack(">Q", total) + body + b"7777"
with gzip.open(sys.argv[1], "wb") as f:
    f.write(out)
print("wrote", sys.argv[1], total, "bytes")
