/* FlashRisk: flood likelihood from CREST max unit streamflow and the mean of the
   1/3/6 h QPE/FFG ratios, drawn on a fixed regional grid as shaded bands and labelled
   contours. Past FLASH files make a time loop; NWS radar can loop alongside it. */
(function () {
  "use strict";
  var C = window.FBCore;
  var $ = function (s) { return document.querySelector(s); };

  var FLASH = "https://mrms.ncep.noaa.gov/2D/FLASH/";          // live: ~26 h of files
  var MRMS_2D = "https://mrms.ncep.noaa.gov/2D/";                // live non-FLASH MRMS products
  var IEM_GEO = "https://mesonet.agron.iastate.edu/geojson/";   // warnings + storm reports for verification
  var PRODUCTS = { crest: "CREST_MAXUNITSTREAMFLOW", r1: "QPE_FFG01H", r3: "QPE_FFG03H", r6: "QPE_FFG06H", sat: "CREST_MAXSOILSAT" };
  // Nowcast inputs (plain MRMS, not FLASH): instantaneous rain rate (mm/h) and the radar-only QPE (mm)
  // that the FLASH QPE/FFG ratios are built from.
  // MRMS rain rate, now and 20 min earlier: only used to measure storm motion (never holds a frame back)
  var NOW_PRODUCTS = { rate: "PrecipRate" };
  var QPE = "https://mapservices.weather.noaa.gov/raster/rest/services/obs/mrms_qpe/ImageServer";
  var FFG = "https://mapservices.weather.noaa.gov/raster/rest/services/precip/rfc_gridded_ffg/MapServer";

  var CELL = 0.05;                 // regional grid spacing, degrees (~5 km)
  var BLUR = 2;                    // box-blur radius in regional cells (~25 km window)
  var STEP_MIN = 5;                // loop step; frames sit on the :00/:05 marks
  var REFRESH_MIN = 5;             // how often new data is pulled
  var FRAME_MS = 700, LAST_HOLD_MS = 1800;
  var SPEEDS = [1, 2, 4, 6];
  // Contour levels: "standard" breaks, or every 5% from 5 to 95.
  var LEVEL_SETS = {
    standard: [0.05, 0.10, 0.25, 0.40, 0.55, 0.70, 0.85],
    every5: Array.from({ length: 19 }, function (_, i) { return Math.round((i + 1) * 5) / 100; })
  };
  // One colour scale for both sets; standard breaks land exactly on these anchors.
  var COLOR_ANCHORS = [[0.05, "#7f95a8"], [0.10, "#5ab4d6"], [0.25, "#3fbf6f"], [0.40, "#e4c03a"],
    [0.55, "#f08a30"], [0.70, "#e5463c"], [0.85, "#c43bd6"], [0.95, "#f0a6f7"]];
  function levelColor(v) {
    var A = COLOR_ANCHORS;
    if (v <= A[0][0]) return A[0][1];
    for (var i = 1; i < A.length; i++) {
      if (v <= A[i][0] + 1e-9) {
        var f = (v - A[i - 1][0]) / (A[i][0] - A[i - 1][0]), a = parseInt(A[i - 1][1].slice(1), 16), b = parseInt(A[i][1].slice(1), 16);
        var mix = function (s) { return Math.round(((a >> s) & 255) * (1 - f) + ((b >> s) & 255) * f); };
        return "#" + ((1 << 24) + (mix(16) << 16) + (mix(8) << 8) + mix(0)).toString(16).slice(1);
      }
    }
    return A[A.length - 1][1];
  }
  var STYLES = { both: "Lines and shading", lines: "Lines only", fill: "Shading only" };
  var view = { mode: "standard", opacity: 1, lead: 0, style: "lines" };
  // Defaults changed (lines only, contour opacity 100%, radar on at 30%): saved settings from before
  // this version are dropped once so the new defaults show; changes made after that are remembered.
  try {
    if (localStorage.getItem("fb.settingsVersion") !== "2") {
      ["fb.style", "fb.opacity", "fb.radarOn", "fb.radarOpacity", "fb.speed"].forEach(function (k) { localStorage.removeItem(k); });
      localStorage.setItem("fb.settingsVersion", "2");
    }
  } catch (x) { /* storage unavailable: defaults apply */ }
  try {
    var vm = localStorage.getItem("fb.levels"); if (LEVEL_SETS[vm]) view.mode = vm;
    var vo = parseFloat(localStorage.getItem("fb.opacity")); if (vo >= 0.1 && vo <= 1) view.opacity = vo;
    var vs = localStorage.getItem("fb.style"); if (STYLES[vs]) view.style = vs;
  } catch (x) { /* ignore */ }
  function levels() { return LEVEL_SETS[view.mode]; }
  // Contour style: lines with shading between them, lines alone, or shading alone.
  function showFill() { return view.style !== "lines"; }
  function showLines() { return view.style !== "fill"; }
  function fillOpacity() { return 0.7 * view.opacity; }
  function lineOpacity() { return Math.min(1, 0.3 + 1.5 * view.opacity); }

  var state = {
    frames: [],          // [{key, t, plan, reg, group, labels, status}] oldest -> newest
    idx: -1, playing: false, timer: null, scale: null, gen: 0, loading: false
  };

  // ---------- network ----------
  function relayBase() { return /^https?:$/.test(location.protocol) ? "/api/relay" : ""; }
  async function fetchVia(url, kind) {
    var relay = relayBase(), routes = relay ? ["relay", "direct"] : ["direct"], last = null;
    for (var i = 0; i < routes.length; i++) {
      var u = routes[i] === "direct" ? url : relay + "?url=" + encodeURIComponent(url);
      try {
        var res = await fetch(u);
        if (!res.ok) throw new Error("HTTP " + res.status);
        if (kind === "json") { var j = await res.json(); if (j && j.error) throw new Error(j.error.message || "service error"); return j; }
        if (kind === "text") return await res.text();
        return new Uint8Array(await res.arrayBuffer());
      } catch (e) { last = e; }
    }
    if (last instanceof TypeError) throw new Error(relay ? "Data server unreachable. Is serve.py still running?" : "Start the page with python3 serve.py and open http://localhost:8787.");
    throw last;
  }
  // ---------- background workers ----------
  // Everything heavy runs off the page's main thread so the map never freezes: downloading and decoding
  // each GRIB2 file down to the 0.05° regional grid, building each frame (equation + storm motion), and
  // rendering radar sweeps. The same code runs inline if workers aren't available.
  function workerMain(C) {
    async function inflate(bytes, fmt) {
      if (typeof DecompressionStream !== "undefined") {
        var st = new Blob([bytes]).stream().pipeThrough(new DecompressionStream(fmt));
        return new Uint8Array(await new Response(st).arrayBuffer());
      }
      var P = self.pako || (typeof window !== "undefined" && window.pako);
      if (!P) throw new Error("No decompressor available.");
      return fmt === "gzip" ? P.ungzip(bytes) : P.inflate(bytes);
    }
    async function fetchBytes(urls) {
      var last = null;
      for (var i = 0; i < urls.length; i++) {
        try { var res = await fetch(urls[i]); if (!res.ok) throw new Error("HTTP " + res.status);
          return new Uint8Array(await res.arrayBuffer()); } catch (e) { last = e; }
      }
      if (last instanceof TypeError) throw new Error("Data server unreachable. Is serve.py still running?");
      throw last;
    }
    async function reduce(m) {
      var u = await fetchBytes(m.urls);
      if (u[0] === 0x1f && u[1] === 0x8b) u = await inflate(u, "gzip");
      var h = C.grib2Header(u), pix = null;
      if (h.tpl5 === 41 && h.nbits) {
        var info = C.pngInfo(h.data);
        if (info.width !== h.ni || info.height !== h.nj) throw new Error("PNG size does not match grid size.");
        pix = C.pngUnfilter(await inflate(info.idat, "deflate"), info); h.bpp = info.bpp;
      } else if (h.nbits) { h.getter = C.parseGrib2(u).get; h.bpp = 0; }
      var r = C.reduceField(h, pix, m.want, m.cell), tr = [];
      if (r.max) tr.push(r.max.buffer); if (r.mean) tr.push(r.mean.buffer);
      return { res: r, transfer: tr };
    }
    function assemble(m) {
      var o = C.assembleFrame(m.input), tr = [o.values.buffer];
      if (o.proj) Object.keys(o.proj).forEach(function (k) { tr.push(o.proj[k].buffer); });
      if (o.motion && o.motion.field) ["tu", "tv", "ok", "wt"].forEach(function (k) { tr.push(o.motion.field[k].buffer); });
      return { res: o, transfer: tr };
    }
    async function radarJob(m) {
      var res = await fetch(m.url);
      if (!res.ok) throw new Error((await res.text()) || ("HTTP " + res.status));
      var sw = C.renderSweep(await res.arrayBuffer(), m.size);
      if (typeof OffscreenCanvas !== "undefined") {
        try {
          var oc = new OffscreenCanvas(sw.size, sw.size);
          oc.getContext("2d").putImageData(new ImageData(sw.rgba, sw.size, sw.size), 0, 0);
          return { res: { meta: sw.meta, bounds: sw.bounds, blob: await oc.convertToBlob({ type: "image/png" }) }, transfer: [] };
        } catch (e) { /* fall back to raw pixels */ }
      }
      return { res: { meta: sw.meta, bounds: sw.bounds, rgba: sw.rgba, size: sw.size }, transfer: [sw.rgba.buffer] };
    }
    return function handle(m) {
      if (m.op === "reduce") return reduce(m);
      if (m.op === "assemble") return Promise.resolve(assemble(m));
      if (m.op === "radar") return radarJob(m);
      return Promise.reject(new Error("unknown job " + m.op));
    };
  }
  var pool = (function () {
    var size = Math.max(2, Math.min(4, (navigator.hardwareConcurrency || 4) - 1)), idle = [], queue = [], jobs = {}, seq = 0, inline = null;
    try {
      var core = document.getElementById("fb-core"), pakoTag = Array.from(document.scripts).find(function (s) { return /pako/.test(s.src); });
      if (!core || typeof Worker === "undefined") throw new Error("no workers");
      var src = "self.window = self;\n" + (pakoTag ? "try { importScripts(" + JSON.stringify(pakoTag.src) + "); } catch (e) {}\n" : "") + core.textContent +
        "\nvar handle = (" + workerMain.toString() + ")(self.FBCore);\n" +
        "self.onmessage = function (e) { var m = e.data; handle(m).then(function (r) { self.postMessage({ id: m.id, ok: true, res: r.res }, r.transfer || []); })" +
        ".catch(function (err) { self.postMessage({ id: m.id, ok: false, error: String(err && err.message || err) }); }); };\n";
      var url = URL.createObjectURL(new Blob([src], { type: "text/javascript" }));
      for (var i = 0; i < size; i++) (function (w) {
        w.onmessage = function (e) { var d = e.data, j = jobs[d.id]; delete jobs[d.id]; idle.push(w); pump(); if (j) { if (d.ok) j.resolve(d.res); else j.reject(new Error(d.error)); } };
        w.onerror = function (e) { e.preventDefault(); var j = jobs[w.current]; delete jobs[w.current]; idle.push(w); pump(); if (j) j.reject(new Error(e.message || "worker error")); };
        idle.push(w);
      })(new Worker(url));
    } catch (e) { inline = workerMain(C); }
    function pump() {
      while (idle.length && queue.length) { var w = idle.pop(), j = queue.shift(); jobs[j.msg.id] = j; w.current = j.msg.id; w.postMessage(j.msg, j.transfer || []); }
    }
    return {
      workers: inline ? 0 : size,
      run: function (msg, opts) {
        msg.id = ++seq;
        if (inline) return inline(msg).then(function (r) { return r.res; });
        return new Promise(function (resolve, reject) {
          var j = { msg: msg, resolve: resolve, reject: reject, transfer: opts && opts.transfer };
          if (opts && opts.urgent) queue.unshift(j); else queue.push(j);
          pump();
        });
      }
    };
  })();
  function routes(url) {
    return /^https?:$/.test(location.protocol) ? [location.origin + "/api/relay?url=" + encodeURIComponent(url), url] : [url];
  }
  // Regional reductions per file, shared by every frame that uses the file (CREST and soil serve two
  // frames, the hourly QPE serves twelve, a rain-rate file is "now" for one frame and "20 min ago" for another).
  var redCache = new Map();
  function reduceFile(url, want) {
    var key = url + (want.max ? "|max" : "") + (want.mean ? "|mean" : "");
    if (redCache.has(key)) { var hit = redCache.get(key); redCache.delete(key); redCache.set(key, hit); return hit; }
    var p = pool.run({ op: "reduce", urls: routes(url), want: want, cell: CELL });
    redCache.set(key, p);
    p.catch(function () { if (redCache.get(key) === p) redCache.delete(key); });
    while (redCache.size > 48) redCache.delete(redCache.keys().next().value);
    return p;
  }

  // ---------- frame planning from the FLASH directory listings ----------
  async function listTimes(product, plain) {
    var dir = (plain ? MRMS_2D : FLASH) + product + "/", pre = (plain ? "MRMS_" : "MRMS_FLASH_") + product;
    var html = await fetchVia(dir, "text"), seen = {}, out = [];
    var re = new RegExp(pre + "_00\\.00_(\\d{8})-(\\d{6})\\.grib2\\.gz", "g"), m;
    while ((m = re.exec(html))) {
      if (seen[m[0]]) continue; seen[m[0]] = 1;
      out.push({ t: stampMs(m[1], m[2]), file: m[0], url: dir + m[0] });
    }
    return out.sort(function (a, b) { return a.t - b.t; });
  }
  function stampMs(d, h) { return Date.UTC(+d.slice(0, 4), +d.slice(4, 6) - 1, +d.slice(6, 8), +h.slice(0, 2), +h.slice(2, 4), +h.slice(4, 6)); }
  function nearest(list, t, tolMs) {
    var best = null, bd = Infinity;
    for (var i = 0; i < list.length; i++) { var d = Math.abs(list[i].t - t); if (d < bd) { bd = d; best = list[i]; } }
    return bd <= tolMs ? best : null;
  }
  function latestBefore(list, t, maxAgeMs) {
    var best = null;
    for (var i = 0; i < list.length; i++) if (list[i].t <= t + 60e3 && t - list[i].t <= maxAgeMs) best = list[i];
    return best;
  }
  // A frame is built only when every input is in for its time. Each input uses its newest file valid
  // at or before the frame time, and that file has to be final: the product's next file would fall
  // after the frame time (so nothing newer can still arrive for it), or the feed has already posted
  // past the frame time (a skipped file isn't coming). Frames that aren't complete wait; they are
  // never built from partial data and never rebuilt once shown.
  var INPUT_NAMES = { crest: "CREST streamflow", r1: "QPE/FFG 1 h", r3: "QPE/FFG 3 h", r6: "QPE/FFG 6 h", sat: "soil saturation",
    rate: "rain rate", prev: "rain rate −20 min", q1: "radar QPE 1 h", q3: "radar QPE 3 h", q6: "radar QPE 6 h", r3h: "QPE/FFG 3 h (hourly)", r6h: "QPE/FFG 6 h (hourly)" };
  function cadence(list) {
    var g = [];
    for (var i = Math.max(1, list.length - 12); i < list.length; i++) g.push(list[i].t - list[i - 1].t);
    g.sort(function (a, b) { return a - b; });
    return g.length ? g[g.length >> 1] : 120e3;
  }
  function asOf(list, t, maxAgeMs) {
    var m = null;
    for (var i = 0; i < list.length && list[i].t <= t + 30e3; i++) m = list[i];
    if (!m || t - m.t > maxAgeMs) return null;
    var last = list[list.length - 1].t;
    return t - m.t < cadence(list) - 20e3 || last > t + 30e3 ? m : null;
  }
  async function planFrames(hours) {
    var keys = Object.keys(PRODUCTS), nkeys = Object.keys(NOW_PRODUCTS);
    var lists = await Promise.all(keys.map(function (k) { return listTimes(PRODUCTS[k]); }));
    var nl = await Promise.allSettled(nkeys.map(function (k) { return listTimes(NOW_PRODUCTS[k], true); }));
    var L = {}; keys.forEach(function (k, i) { L[k] = lists[i]; });
    nkeys.forEach(function (k, i) { L[k] = nl[i].status === "fulfilled" ? nl[i].value : []; });
    var downFeeds = nkeys.filter(function (k, i) { return nl[i].status !== "fulfilled"; });
    // Candidate frame times run up to the newest QPE/FFG or CREST file, on the :00/:05 marks.
    var newest = 0;
    ["r1", "r3", "r6", "crest"].forEach(function (k) { if (L[k].length) newest = Math.max(newest, L[k][L[k].length - 1].t); });
    if (!newest) throw new Error("No timestamped FLASH files listed.");
    var step = STEP_MIN * 60e3, latest = Math.floor(newest / step) * step, start = latest - hours * 3600e3;
    var plans = [], waiting = null, M = 60e3;
    for (var t = latest; t >= start - 1; t -= step) {
      var f = { crest: asOf(L.crest, t, 12 * M), r1: asOf(L.r1, t, 6 * M), r3: asOf(L.r3, t, 6 * M), r6: asOf(L.r6, t, 6 * M), sat: asOf(L.sat, t, 12 * M) };
      var n = { rate: asOf(L.rate, t, 6 * M), prev: asOf(L.rate, t - C.NOWCAST.dtMin * M, 6 * M) };   // storm motion only: optional
      var missing = Object.keys(f).filter(function (k) { return !f[k]; });
      if (!missing.length) plans.push({ t: t, files: f, now: n });
      else if (!plans.length) waiting = { t: t, missing: missing.map(function (k) { return INPUT_NAMES[k]; }), down: downFeeds.map(function (k) { return NOW_PRODUCTS[k]; }) };
    }
    plans.reverse();
    plans.waiting = waiting && (!plans.length || waiting.t > plans[plans.length - 1].t) ? waiting : null;
    return plans;
  }

  // ---------- ratio units (FLASH grids may be percent) ----------
  async function ratioScale(r6) {      // r6: the 6 h ratio file's reduction (its maximum and where it is)
    var best = r6.vmax, lat = r6.vlat, lon = r6.vlon;
    if (!(best > 0)) return 0.01;
    try {
      var cat = await fetchVia(QPE + "/query?where=1%3D1&outFields=objectid,name,idp_subset&returnGeometry=false&f=json", "json"), oid = null;
      (cat.features || []).forEach(function (f) {
        var s = ((f.attributes.name || "") + " " + (f.attributes.idp_subset || "")).toLowerCase();
        if (/(^|[^0-9])0?6\s*h/.test(s) && /(^|[^a-z])co([^a-z]|$)|conus/.test(s)) oid = f.attributes.objectid;
      });
      var geom = encodeURIComponent(JSON.stringify({ x: lon, y: lat, spatialReference: { wkid: 4326 } }));
      var q = await fetchVia(QPE + "/identify?geometry=" + geom + "&geometryType=esriGeometryPoint&mosaicRule=" +
        encodeURIComponent(JSON.stringify({ mosaicMethod: "esriMosaicLockRaster", lockRasterIds: [oid] })) +
        "&renderingRule=" + encodeURIComponent('{"rasterFunction":"None"}') + "&returnGeometry=false&returnCatalogItems=false&f=json", "json");
      var f = await fetchVia(FFG + "/identify?geometry=" + lon + "," + lat + "&geometryType=esriGeometryPoint&sr=4326&layers=all&tolerance=1&mapExtent=" +
        [lon - 0.05, lat - 0.05, lon + 0.05, lat + 0.05].join(",") + "&imageDisplay=200,200,96&returnGeometry=false&f=json", "json");
      var ffg6 = NaN;
      (f.results || []).forEach(function (r) {
        var six = /0?6\s*Hour/i.test(r.layerName || "") || r.layerId === 8 || r.layerId === 11, a = r.attributes || {};
        var key = Object.keys(a).find(function (k) { return /pixel value/i.test(k) && !/stretch/i.test(k); });
        var v = parseFloat(key ? a[key] : NaN);
        if (six && v > 0 && !(ffg6 > 0)) ffg6 = v;
      });
      var live = parseFloat(q.value) / ffg6;
      if (live > 0.05) return best / live > 15 ? 0.01 : 1;
    } catch (e) { /* fall through */ }
    return 0.01; // percent is the safe reading: it never inflates the ratio
  }

  // ---------- map ----------
  var map = L.map("map", { zoomSnap: 0.5, zoomControl: false, worldCopyJump: true }).setView([37.8, -96], 4.5);
  L.control.zoom({ position: "topleft" }).addTo(map);
  // The banner's height depends on how its groups wrap; the map starts right under it.
  (function () {
    var banner = $("#banner"); if (!banner) return;
    var fit = function () { document.documentElement.style.setProperty("--banner-h", banner.offsetHeight + "px"); map.invalidateSize(); };
    if (window.ResizeObserver) new ResizeObserver(fit).observe(banner); else window.addEventListener("resize", fit);
    fit();
  })();
  // Banner popovers (Export, Equation): one open at a time, placed under their button, closed by Esc or a click elsewhere.
  document.querySelectorAll("details.pop").forEach(function (d) {
    d.addEventListener("toggle", function () {
      if (!d.open) return;
      document.querySelectorAll("details.pop").forEach(function (o) { if (o !== d) o.open = false; });
      var s = d.querySelector("summary").getBoundingClientRect(), panel = d.querySelector(".panel"), w = panel.offsetWidth;
      panel.style.top = ($("#banner").getBoundingClientRect().bottom + 6) + "px";
      panel.style.left = Math.max(12, Math.min(s.left, window.innerWidth - w - 12)) + "px";
    });
  });
  document.addEventListener("click", function (e) {
    document.querySelectorAll("details.pop[open]").forEach(function (d) { if (!d.contains(e.target)) d.open = false; });
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") document.querySelectorAll("details.pop[open]").forEach(function (d) { d.open = false; d.querySelector("summary").focus(); });
  });
  [["labels", 650], ["radar", 410], ["flood", 420], ["floodLabels", 660]].forEach(function (p) {
    map.createPane(p[0]); map.getPane(p[0]).style.zIndex = p[1]; map.getPane(p[0]).style.pointerEvents = "none";
  });

  var ESRI = "https://server.arcgisonline.com/ArcGIS/rest/services/";
  var BASES = [
    { url: ESRI + "Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}", nz: 16, attr: "Esri, HERE, Garmin, © OpenStreetMap contributors", lab: ESRI + "Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}" },
    { url: "https://{s}.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}{r}.png", nz: 19, attr: "© OpenStreetMap contributors, © CARTO", lab: "https://{s}.basemaps.cartocdn.com/dark_only_labels/{z}/{x}/{y}{r}.png" },
    { url: ESRI + "World_Topo_Map/MapServer/tile/{z}/{y}/{x}", nz: 19, attr: "Esri, HERE, Garmin, USGS, NGA" },
    { url: "https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer/tile/{z}/{y}/{x}", nz: 16, attr: "USGS The National Map" },
    { url: "https://tile.openstreetmap.org/{z}/{x}/{y}.png", nz: 19, attr: "© OpenStreetMap contributors" }
  ];
  var baseIdx = -1, baseLayer = null, labelLayer = null, baseTimer = null;
  function nextBase() {
    if (baseLayer) map.removeLayer(baseLayer);
    if (labelLayer) map.removeLayer(labelLayer);
    baseIdx++;
    if (baseIdx >= BASES.length) { setNote("No background map could load on this network; the flood layer still works."); return; }
    var d = BASES[baseIdx], ok = 0, bad = 0;
    baseLayer = L.tileLayer(d.url, { maxNativeZoom: d.nz, maxZoom: 19, attribution: d.attr }).addTo(map);
    labelLayer = d.lab ? L.tileLayer(d.lab, { pane: "labels", maxNativeZoom: d.nz, maxZoom: 19 }).addTo(map) : null;
    baseLayer.on("tileload", function () { ok++; clearTimeout(baseTimer); });
    baseLayer.on("tileerror", function () { bad++; if (!ok && bad >= 3) nextBase(); });
    clearTimeout(baseTimer);
    baseTimer = setTimeout(function () { if (!ok) nextBase(); }, 8000);
  }
  nextBase();

  // ---------- single-site radar: raw NEXRAD Level II from AWS ----------
  // serve.py lists volumes in s3://unidata-nexrad-level2 and decodes the lowest-tilt
  // reflectivity; the browser draws it in polar coordinates around the radar.
  var OPENGEO = "https://opengeo.ncep.noaa.gov/geoserver/";
  var RADAR_TOL_MS = 8 * 60e3;
  var radar = { on: true, sites: [], byId: {}, site: null, scans: [], data: {}, loading: {}, layers: {}, shownKey: null,
    dots: L.layerGroup().addTo(map), ring: null };

  async function loadSites() {
    var list = [];
    try {
      var j = await fetchVia(OPENGEO + "nws/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=nws:radar_sites&outputFormat=application/json", "json");
      (j.features || []).forEach(function (f) {
        var a = f.properties || {};
        if (a.rda_id && isFinite(+a.lat) && isFinite(+a.lon)) list.push({ id: String(a.rda_id).toUpperCase(), name: a.name || "", wfo: a.wfo_id || "", lat: +a.lat, lon: +a.lon });
      });
    } catch (e) { /* try the next source */ }
    if (!list.length) {
      try {
        var r = await fetch("https://api.weather.gov/radar/stations?stationType=WSR-88D", { headers: { Accept: "application/geo+json" } });
        var g = await r.json();
        (g.features || []).forEach(function (f) {
          var p = f.properties || {}, c = (f.geometry || {}).coordinates || [];
          if (p.id && isFinite(c[1])) list.push({ id: String(p.id).toUpperCase(), name: p.name || "", wfo: "", lat: c[1], lon: c[0] });
        });
      } catch (e) { /* no list */ }
    }
    var seen = {};
    radar.sites = list.filter(function (s) { if (seen[s.id] || !/^[A-Z]{4}$/.test(s.id)) return false; seen[s.id] = 1; return true; })
      .sort(function (a, b) { return a.id < b.id ? -1 : 1; });
    radar.byId = {}; radar.sites.forEach(function (s) { radar.byId[s.id] = s; });
    siteSearchReady();
    // sites are picked from the Radar menu only (no clickable dots on the map)
    if (!radar.sites.length) setRadarNote("Couldn't load the radar site list.");
    var saved = null; try { saved = localStorage.getItem("fb.site"); } catch (x) { /* ignore */ }
    if (saved && radar.byId[saved]) selectSite(saved, true);
  }

  async function listScans(s) {
    if (!/^https?:$/.test(location.protocol)) throw new Error("Radar needs serve.py: run python3 serve.py and open http://localhost:8787.");
    var first = state.frames.length && state.frames[0].t ? state.frames[0].t : Date.now() - 3 * 3600e3, last = Date.now();
    var res = await fetch("/api/l2/list?site=" + s.id + "&start=" + Math.round(first - 15 * 60e3) + "&end=" + Math.round(last));
    if (!res.ok) throw new Error((await res.text()) || ("HTTP " + res.status));
    return ((await res.json()).scans || []).sort(function (a, b) { return a.t - b.t; });
  }

  // Each Level II sweep is decoded and drawn once, in a worker, into a Web-Mercator PNG of its full range.
  // The map shows it as an image overlay, so zooming and panning just rescale it, and only the scan
  // for the frame on screen is on the map.
  var RADAR_PX = 2400;    // ~385 m per pixel across the 460 km reflectivity range (gates are 250 m)
  function rgbaToBlob(rgba, size) {
    var c = document.createElement("canvas"); c.width = c.height = size;
    c.getContext("2d").putImageData(new ImageData(rgba, size, size), 0, 0);
    return new Promise(function (r) { c.toBlob(r, "image/png"); });
  }
  function getScan(key) {
    if (radar.data[key]) return Promise.resolve(radar.data[key]);
    if (!radar.loading[key]) {
      var site = radar.site;
      radar.loading[key] = pool.run({ op: "radar", url: location.origin + "/api/l2/scan?key=" + encodeURIComponent(key), size: RADAR_PX }).then(async function (r) {
        var blob = r.blob || await rgbaToBlob(r.rgba, r.size);
        var sc = { meta: r.meta, bounds: r.bounds, url: URL.createObjectURL(blob) };
        if (radar.site !== site) { URL.revokeObjectURL(sc.url); throw new Error("site changed"); }
        radar.data[key] = sc;
        return sc;
      }).finally(function () { delete radar.loading[key]; });
    }
    return radar.loading[key];
  }
  function sweepLayer(key) {
    if (radar.layers[key]) return radar.layers[key];
    var sc = radar.data[key];
    radar.layers[key] = L.imageOverlay(sc.url, sc.bounds, { pane: "radar", opacity: radar.opacity, interactive: false, className: "radar-img",
      attribution: "Radar: NWS " + radar.site.id + " Level II (NOAA/Unidata on AWS)" });
    return radar.layers[key];
  }
  // drop decoded scans that have fallen out of the loop window
  function pruneScans() {
    var keep = {}; radar.scans.forEach(function (s) { keep[s.key] = 1; });
    Object.keys(radar.data).forEach(function (k) {
      if (keep[k] || k === radar.shownKey) return;
      if (radar.layers[k]) { map.removeLayer(radar.layers[k]); delete radar.layers[k]; }
      URL.revokeObjectURL(radar.data[k].url); delete radar.data[k];
    });
  }
  function clearRadarLayers() {
    Object.keys(radar.layers).forEach(function (k) { map.removeLayer(radar.layers[k]); });
    Object.keys(radar.data).forEach(function (k) { URL.revokeObjectURL(radar.data[k].url); });
    radar.layers = {}; radar.shownKey = null;
  }

  function wantedScan() {
    if (!radar.scans.length) return null;
    var f = state.frames[state.idx], isNewest = state.idx === state.frames.length - 1;
    if (!f || (isNewest && !state.playing)) return radar.scans[radar.scans.length - 1];
    var best = null, bd = Infinity;
    radar.scans.forEach(function (s) { var d = Math.abs(s.t - f.t); if (d < bd) { bd = d; best = s; } });
    return bd <= RADAR_TOL_MS ? best : null;
  }
  function syncRadar() {
    if (radar.ring) { if (radar.on && !map.hasLayer(radar.ring)) radar.ring.addTo(map); if (!radar.on && map.hasLayer(radar.ring)) map.removeLayer(radar.ring); }
    if (!radar.site) { clearRadarLayers(); $("#radarTime").textContent = radar.on ? "Pick a radar site from the menu" : ""; return; }
    var hideAll = function () { Object.keys(radar.layers).forEach(function (k) { if (map.hasLayer(radar.layers[k])) map.removeLayer(radar.layers[k]); }); radar.shownKey = null; };
    if (!radar.on) { hideAll(); $("#radarTime").textContent = radar.site.id + " · off"; return; }
    var s = wantedScan(), f = state.frames[state.idx];
    if (!s) {
      hideAll();
      $("#radarTime").textContent = radar.site.id + " · " + (radar.scans.length && f ? "no scan within 8 min of " + zTime(new Date(f.t)) : "no scans yet");
      return;
    }
    var label = radar.site.id + " · " + zTime(new Date(s.t));
    if (!radar.data[s.key]) {
      $("#radarTime").textContent = label + " · loading…";
      getScan(s.key).then(function () { if (wantedScan() === s) syncRadar(); })
        .catch(function (e) { setRadarNote(radar.site.id + " scan " + zTime(new Date(s.t)) + " couldn't be read: " + e.message); });
      return;
    }
    var l = sweepLayer(s.key);
    if (radar.shownKey !== s.key || !map.hasLayer(l)) {
      if (!map.hasLayer(l)) l.addTo(map);
      l.setOpacity(radar.opacity);
      // take the previous image off once the new one has painted, so the radar never blinks out
      var swap = function () { if (radar.shownKey !== s.key) return; Object.keys(radar.layers).forEach(function (k) { if (k !== s.key && map.hasLayer(radar.layers[k])) map.removeLayer(radar.layers[k]); }); };
      var img = l.getElement();
      radar.shownKey = s.key;
      if (img && !img.complete) { img.addEventListener("load", swap, { once: true }); setTimeout(swap, 500); } else swap();
    }
    var m = radar.data[s.key].meta;
    $("#radarTime").textContent = label + " · " + m.elev.toFixed(1) + "°";
  }
  function setRadarNote(t) { $("#radarNote").textContent = t || ""; }

  // Load the scans that match loop frames, newest first, so playback is smooth.
  async function prefetchScans() {
    var site = radar.site, want = [];
    state.frames.forEach(function (f) {
      var best = null, bd = Infinity;
      radar.scans.forEach(function (s) { var d = Math.abs(s.t - f.t); if (d < bd) { bd = d; best = s; } });
      if (best && bd <= RADAR_TOL_MS && want.indexOf(best) < 0) want.push(best);
    });
    if (radar.scans.length) want.push(radar.scans[radar.scans.length - 1]);
    want.sort(function (a, b) { return b.t - a.t; });
    for (var i = 0; i < want.length; i++) {
      if (radar.site !== site) return;
      try { await getScan(want[i].key); } catch (e) { /* shown when that frame is viewed */ }
    }
  }
  async function refreshScans() {
    if (!radar.site) return;
    var s = radar.site, before = radar.scans.length ? radar.scans[radar.scans.length - 1].t : 0;
    try {
      var list = await listScans(s);
      if (radar.site !== s) return;
      radar.scans = list; setRadarNote(list.length ? "" : "No Level II volumes from " + s.id + " in the loop window.");
      pruneScans();
      scheduleRadar(before);
    } catch (e) { if (radar.site === s) setRadarNote(e.message); clock.radarCheck = Date.now() + 60e3; }
    syncRadar(); if (radar.on) prefetchScans();
  }

  async function selectSite(id, quiet) {
    var s = id ? radar.byId[id] : null;
    clearRadarLayers(); setRadarNote(""); radar.data = {}; radar.loading = {}; radar.scans = [];
    if (radar.ring) { map.removeLayer(radar.ring); radar.ring = null; }
    radar.site = s;
    $("#site").value = s ? siteLabel(s) : "";
    try { localStorage.setItem("fb.site", s ? s.id : ""); } catch (x) { /* ignore */ }
    if (!s) { syncRadar(); return; }
    if (!quiet) setRadarOn(true);   // picking a site means you want to see it
    radar.ring = L.circle([s.lat, s.lon], { radius: 230000, pane: "radar", color: "#a6a6a6", weight: 1, dashArray: "4 6", fill: false, interactive: false });
    if (!quiet) map.flyTo([s.lat, s.lon], 8, { duration: 0.9 });      // go to the chosen radar, its full range in view
    $("#radarTime").textContent = s.id + " · listing scans…";
    await refreshScans();
  }
  // ---------- radar site search: type an identifier (KMLB), office (MLB) or city (Melbourne) ----------
  function siteLabel(s) { return s.id + " · " + s.name; }
  function siteMatches(q) {
    q = q.trim().toUpperCase(); if (!q) return [];
    var out = [];
    radar.sites.forEach(function (s) {
      var id = s.id, wfo = (s.wfo || "").toUpperCase(), name = (s.name || "").toUpperCase(), rank = -1;
      if (id === q || id === "K" + q || wfo === q) rank = 0;                         // KMLB, MLB (as typed or without the K)
      else if (id.indexOf(q) === 0 || id.indexOf("K" + q) === 0 || wfo.indexOf(q) === 0) rank = 1;
      else if (name.indexOf(q) === 0 || name.split(/[\s\/,-]+/).some(function (w) { return w.indexOf(q) === 0; })) rank = 2;
      else if (name.indexOf(q) >= 0) rank = 3;
      if (rank >= 0) out.push({ s: s, rank: rank });
    });
    out.sort(function (a, b) { return a.rank - b.rank || (a.s.id < b.s.id ? -1 : 1); });
    return out.slice(0, 8).map(function (o) { return o.s; });
  }
  var siteUI = { list: null, items: [], active: -1 };
  function siteSearchReady() { $("#site").placeholder = radar.sites.length ? "Search radar…" : "No radar list"; }
  function closeSiteList() { if (siteUI.list) siteUI.list.hidden = true; siteUI.active = -1; $("#site").setAttribute("aria-expanded", "false"); }
  function renderSiteList() {
    var input = $("#site"), q = input.value;
    if (!siteUI.list) {
      siteUI.list = document.createElement("ul"); siteUI.list.id = "siteList"; siteUI.list.className = "site-list"; siteUI.list.setAttribute("role", "listbox");
      document.body.appendChild(siteUI.list);
      siteUI.list.addEventListener("mousedown", function (e) { e.preventDefault(); });      // keep focus in the box
      siteUI.list.addEventListener("click", function (e) { var li = e.target.closest("li[data-id]"); if (li) pickSite(li.dataset.id); });
    }
    siteUI.items = siteMatches(q);
    if (!siteUI.items.length) {
      siteUI.list.innerHTML = q.trim() ? '<li class="none">No radar matches “' + q.replace(/[<&]/g, "") + '”</li>' : "";
      siteUI.list.hidden = !q.trim();
    } else {
      siteUI.active = Math.min(Math.max(siteUI.active, 0), siteUI.items.length - 1);
      siteUI.list.innerHTML = siteUI.items.map(function (s, i) {
        return '<li role="option" data-id="' + s.id + '" id="site-opt-' + i + '"' + (i === siteUI.active ? ' aria-selected="true"' : "") + '><b>' + s.id + "</b> " +
          s.name.replace(/</g, "") + (s.wfo ? ' <span>' + s.wfo + " office</span>" : "") + "</li>";
      }).join("");
      siteUI.list.hidden = false;
      input.setAttribute("aria-activedescendant", "site-opt-" + siteUI.active);
    }
    var r = input.getBoundingClientRect();
    siteUI.list.style.left = r.left + "px"; siteUI.list.style.top = (r.bottom + 4) + "px";
    input.setAttribute("aria-expanded", siteUI.list.hidden ? "false" : "true");
  }
  function pickSite(id) { closeSiteList(); $("#site").blur(); if (!radar.site || radar.site.id !== id) selectSite(id); else $("#site").value = siteLabel(radar.site); }
  $("#site").addEventListener("focus", function (e) { e.target.select(); });
  $("#site").addEventListener("input", function () { siteUI.active = 0; renderSiteList(); });
  $("#site").addEventListener("keydown", function (e) {
    var open = siteUI.list && !siteUI.list.hidden && siteUI.items.length;
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault(); if (!open) { siteUI.active = 0; renderSiteList(); return; }
      siteUI.active = (siteUI.active + (e.key === "ArrowDown" ? 1 : -1) + siteUI.items.length) % siteUI.items.length; renderSiteList();
    } else if (e.key === "Enter") {
      e.preventDefault(); var m = open ? siteUI.items[siteUI.active] : siteMatches(e.target.value)[0];
      if (m) pickSite(m.id);
    } else if (e.key === "Escape") {
      closeSiteList(); e.target.value = radar.site ? siteLabel(radar.site) : ""; e.target.blur();
    }
  });
  $("#site").addEventListener("blur", function (e) {
    setTimeout(function () { closeSiteList(); if (document.activeElement !== e.target) e.target.value = radar.site ? siteLabel(radar.site) : ""; }, 120);
  });
  function setRadarOn(on) {
    radar.on = on; $("#radarOn").checked = on;
    try { localStorage.setItem("fb.radarOn", on ? "1" : "0"); } catch (x) { /* ignore */ }
    syncRadar();
    if (on && radar.site) prefetchScans();
  }
  try { radar.on = localStorage.getItem("fb.radarOn") !== "0"; } catch (x) { /* ignore */ }
  $("#radarOn").checked = radar.on;
  $("#radarOn").addEventListener("change", function (e) {
    setRadarOn(e.target.checked);
    if (e.target.checked && !radar.site) $("#site").focus();     // radar on with no site yet: go straight to the menu
  });
  radar.opacity = 0.3;
  try { var ro = parseFloat(localStorage.getItem("fb.radarOpacity")); if (ro >= 0.1 && ro <= 1) radar.opacity = ro; } catch (x) { /* ignore */ }
  function setRadarOpacity(v) {
    radar.opacity = v; $("#radarOpacity").value = Math.round(v * 100); $("#radarOpacityVal").textContent = Math.round(v * 100) + "%";
    try { localStorage.setItem("fb.radarOpacity", String(v)); } catch (x) { /* ignore */ }
    if (radar.shownKey && radar.layers[radar.shownKey] && radar.on) radar.layers[radar.shownKey].setOpacity(v);
  }
  $("#radarOpacity").addEventListener("input", function (e) { setRadarOpacity(+e.target.value / 100); });
  setRadarOpacity(radar.opacity);

  // ---------- flood layer per frame ----------
  var floodHost = L.layerGroup().addTo(map), labelHost = L.layerGroup().addTo(map);
  // Likelihood grid for a lead time: 0 = now (float), 60/120 = projection (stored as bytes, 250 = 100%)
  function leadValues(reg, lead) {
    if (!lead) return reg.values;
    var u8 = reg.proj && reg.proj[lead]; if (!u8) return null;
    var out = new Float32Array(u8.length); for (var k = 0; k < u8.length; k++) out[k] = u8[k] / 250;
    return out;
  }
  function buildLayers(reg) {
    var group = L.layerGroup(), labels = [], fills = [], lines = [], LV = levels(), every5 = view.mode === "every5";
    var toLL = function (pt) { return [reg.north + pt[1] * reg.dLat, reg.west + pt[0] * reg.dLon]; };
    var src = leadValues(reg, view.lead);
    if (!src) return { group: group, labels: labels, fills: fills, lines: lines };
    var cs = d3.contours().size([reg.W, reg.H]).thresholds(LV)(src);
    var lls = cs.map(function (c) { return c.coordinates.map(function (poly) { return poly.map(function (ring) { return ring.map(toLL); }); }); });
    // band fills: level i minus level i+1 (even-odd), so colours don't stack
    if (showFill()) cs.forEach(function (c, i) {
      if (!c.coordinates.length) return;
      fills.push(L.polygon(lls[i].concat(lls[i + 1] || []), { pane: "flood", interactive: false, stroke: false, fillRule: "evenodd",
        fillColor: levelColor(LV[i]), fillOpacity: fillOpacity() }).addTo(group));
    });
    if (showLines()) cs.forEach(function (c, i) {
      if (!c.coordinates.length) return;
      var v = LV[i], pct = Math.round(v * 100), minor = every5 && pct % 10 !== 0, color = levelColor(v), bold = showFill() ? 0 : 0.5;   // a little heavier without shading behind
      lines.push(L.polygon(lls[i], { pane: "flood", interactive: false, fill: false, color: color, smoothFactor: 1,
        weight: (minor ? 1.1 : (v >= 0.55 ? 2.2 : 1.5)) + bold, dashArray: minor ? "4 4" : null, opacity: lineOpacity() }).addTo(group));
      var ang = (-30 + i * 47) * Math.PI / 180, ux = Math.cos(ang), uy = Math.sin(ang);
      c.coordinates.forEach(function (poly) {
        var ring = poly[0]; if (!ring || ring.length < 8) return;
        var cx = 0, cy = 0; ring.forEach(function (p) { cx += p[0]; cy += p[1]; }); cx /= ring.length; cy /= ring.length;
        var bestP = ring[0], bestS = -Infinity;
        ring.forEach(function (p) { var s2 = (p[0] - cx) * ux + (p[1] - cy) * uy; if (s2 > bestS) { bestS = s2; bestP = p; } });
        labels.push({ level: i, major: !minor, size: ring.length, m: L.marker(toLL(bestP), { pane: "floodLabels", interactive: false, keyboard: false,
          icon: L.divIcon({ className: "clabel" + (minor ? " minor" : ""), iconSize: null, html: '<span style="--c:' + color + '">' + pct + "%</span>" }) }) });
      });
    });
    // majors first, then higher levels, then bigger rings
    labels.sort(function (a, b) { return (b.major - a.major) || b.level - a.level || b.size - a.size; });
    return { group: group, labels: labels, fills: fills, lines: lines };
  }
  function applyOpacity(f) {
    if (!f || !f.fills) return;
    var fo = fillOpacity(), lo = lineOpacity();
    f.fills.forEach(function (p) { p.setStyle({ fillOpacity: fo }); });
    f.lines.forEach(function (p) { p.setStyle({ opacity: lo }); });
    f.opacityApplied = view.opacity;
  }
  function placeLabels() {
    var f = state.shown; labelHost.clearLayers();
    if (!f || !f.labels) return;
    var size = map.getSize(), shown = [];
    f.labels.forEach(function (l) {
      var pt = map.latLngToContainerPoint(l.m.getLatLng());
      // keep labels out from under the floating legend, zoom buttons and point chart
      var underKey = pt.x > size.x - 330 && pt.y > size.y - 110, underPoint = !$("#probeSec").hidden && pt.x < 350 && pt.y > size.y - 250;
      var inView = pt.x > 24 && pt.y > 14 && pt.x < size.x - 24 && pt.y < size.y - 14 && !underKey && !underPoint;
      if (inView && !shown.some(function (q) { return q.distanceTo(pt) < 40; })) { shown.push(pt); l.m.addTo(labelHost); }
    });
  }
  map.on("zoomend moveend", placeLabels);

  // ---------- frames: show / play ----------
  function zTime(d) { return d && !isNaN(d) ? d.toISOString().slice(11, 16) + "Z" : "–"; }
  function readyIdx() { var a = []; state.frames.forEach(function (f, i) { if (f.reg) a.push(i); }); return a; }
  // The layers for one frame (built once, reused while looping).
  function bundle(f, lead) {
    var b = lead ? ((f.fg = f.fg || {})[lead] = (f.fg && f.fg[lead]) || {}) : f;
    if (!b.group) { view.lead = lead; var x = buildLayers(f.reg); b.group = x.group; b.labels = x.labels; b.fills = x.fills; b.lines = x.lines; b.opacityApplied = view.opacity; }
    else if (b.opacityApplied !== view.opacity) applyOpacity(b);
    return b;
  }
  function clearBundles() { state.frames.forEach(function (f) { f.group = null; f.labels = null; f.fills = null; f.lines = null; f.fg = null; }); }
  // Re-show whatever is on screen (after a style/level change or new data).
  function redisplay(i) {
    if (i !== undefined ? i >= 0 : state.idx >= 0) showFrame(i !== undefined ? i : state.idx);
  }
  function showFrame(i) {
    var f = state.frames[i]; if (!f || !f.reg) return;
    view.lead = 0;
    var b = bundle(f, 0);
    floodHost.clearLayers(); b.group.addTo(floodHost); state.shown = b;
    state.idx = i; placeLabels(); syncRadar();
    var newest = state.frames[state.frames.length - 1], ago = Math.round((newest.t - f.t) / 60000);
    $("#frameTime").textContent = zTime(new Date(f.t)) + (ago ? "  −" + ago + " min" : "  latest");
    $("#scrub").value = i;
    var miss = [];
    if (!f.reg.inputs.crest) miss.push("CREST");
    if (!(f.reg.inputs.r1 && f.reg.inputs.r3 && f.reg.inputs.r6)) miss.push("some QPE÷FFG durations");
    if (!f.reg.inputs.sat) miss.push("soil saturation");
    var notes = miss.length ? ["This frame is missing " + miss.join(" and ") + "."] : [];
    var mv = viewMotion(f.reg);
    if (mv) notes.push(motionText(mv) + ".");
    $("#frameNote").textContent = notes.join(" ");
    drawVerification(); drawProbe();
  }
  // Storm motion for the area on screen (rain-weighted over the tracked tiles in view), not the whole grid:
  // storms over South Florida can move NW while the CONUS average is NE.
  function viewMotion(reg, box) {
    if (!reg || !reg.motion || !reg.motion.field) return null;
    if (!box) { var b = map.getBounds(); box = { south: b.getSouth(), north: b.getNorth(), west: b.getWest(), east: b.getEast() }; }
    return C.motionIn(reg.motion.field, reg, box);
  }
  function motionText(m) {
    return "Storms in view moving " + C.compass(m.toward) + " (toward " + Math.round(m.toward) + "°) at about " + Math.round(m.mph) + " mph";
  }
  map.on("moveend", function () {
    var f = state.frames[state.idx]; if (!f || !f.reg) return;
    var el = $("#frameNote"), txt = el.textContent.replace(/\s*Storms in view moving [^.]*\.|\s*No tracked rain in view\./, "").trim(), mv = viewMotion(f.reg);
    el.textContent = (txt ? txt + " " : "") + (mv ? motionText(mv) + "." : "");
  });
  function step(dir) {
    var r = readyIdx(); if (!r.length) return;
    var pos = r.indexOf(state.idx);
    showFrame(r[(pos + dir + r.length) % r.length]);
  }
  function play(on) {
    state.playing = on; clearTimeout(state.timer);
    $("#play").setAttribute("aria-pressed", on ? "true" : "false");
    $("#play").innerHTML = on ? ICON.pause + "<span>Pause</span>" : ICON.play + "<span>Play loop</span>";
    if (on) {
      var tick = function () {
        if (!state.playing) return;
        step(1);
        var r = readyIdx(), atEnd = state.idx === r[r.length - 1];
        state.timer = setTimeout(tick, atEnd ? Math.max(500, LAST_HOLD_MS / state.speed) : FRAME_MS / state.speed);
      };
      var r0 = readyIdx(); if (state.idx === r0[r0.length - 1]) showFrame(r0[0]);
      state.timer = setTimeout(tick, FRAME_MS / state.speed);
    } else syncRadar();
  }
  var ICON = {
    play: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 2.5v11l9-5.5z"/></svg>',
    pause: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3.5 2.5h3v11h-3zM9.5 2.5h3v11h-3z"/></svg>'
  };
  $("#play").addEventListener("click", function () { play(!state.playing); });
  state.speed = 1;
  try { var sp = parseFloat(localStorage.getItem("fb.speed")); if (SPEEDS.indexOf(sp) >= 0) state.speed = sp; } catch (x) { /* ignore */ }
  function setSpeed(v) {
    state.speed = v;
    try { localStorage.setItem("fb.speed", String(v)); } catch (x) { /* ignore */ }
    document.querySelectorAll("#speed button").forEach(function (b) { b.setAttribute("aria-pressed", +b.dataset.speed === v ? "true" : "false"); });
    if (state.playing) play(true);   // restart the timer at the new pace
  }
  $("#speed").innerHTML = SPEEDS.map(function (v) {
    return '<button type="button" data-speed="' + v + '" aria-pressed="false">' + v + "×</button>";
  }).join("");
  document.querySelectorAll("#speed button").forEach(function (b) { b.addEventListener("click", function () { setSpeed(+b.dataset.speed); }); });
  setSpeed(state.speed);
  $("#prev").addEventListener("click", function () { play(false); step(-1); });
  $("#next").addEventListener("click", function () { play(false); step(1); });
  $("#scrub").addEventListener("input", function (e) {
    play(false);
    var want = +e.target.value, r = readyIdx(), best = r[0];
    r.forEach(function (i) { if (Math.abs(i - want) < Math.abs(best - want)) best = i; });
    if (best !== undefined) showFrame(best);
  });
  document.addEventListener("keydown", function (e) {
    if (e.target.closest && e.target.closest("input, select, textarea")) return;
    if (e.key === " ") { e.preventDefault(); play(!state.playing); }
    else if (e.key === "ArrowLeft") { play(false); step(-1); }
    else if (e.key === "ArrowRight") { play(false); step(1); }
    else if (e.key === "+" || e.key === "=") { var i1 = SPEEDS.indexOf(state.speed); if (i1 < SPEEDS.length - 1) setSpeed(SPEEDS[i1 + 1]); }
    else if (e.key === "-") { var i2 = SPEEDS.indexOf(state.speed); if (i2 > 0) setSpeed(SPEEDS[i2 - 1]); }
  });

  // ---------- status ----------
  function setNote(t, bad) { var n = $("#note"); n.textContent = t || ""; n.hidden = !t; n.classList.toggle("bad", !!bad); }
  function setLoop(text) { $("#loopStatus").textContent = text; }
  function setStatus(s) { $("#status").dataset.state = s; }

  // What each input contributes: block maximum (peaks: streamflow, rain/guidance ratios) and/or block mean.
  var NEED = { crest: { max: true }, r1: { max: true }, r3: { max: true }, r6: { max: true }, sat: { mean: true } };
  var NOW_KEYS = ["rate", "prev"];
  async function loadFrame(f, gen) {
    var keys = Object.keys(NEED);
    var urls = keys.map(function (k) { return f.plan ? f.plan.files[k].url : FLASH + PRODUCTS[k] + "/MRMS_FLASH_" + PRODUCTS[k] + ".latest.grib2.gz"; });
    var res = await Promise.allSettled(keys.map(function (k, i) { return reduceFile(urls[i], NEED[k]); }));
    if (gen !== state.gen) return false;
    var failed = keys.filter(function (k, i) { return res[i].status !== "fulfilled"; });
    // all five inputs or nothing: the frame is retried on the next pull
    if (failed.length) throw new Error("waiting on " + failed.map(function (k) { return INPUT_NAMES[k]; }).join(", ") + " (" + res[keys.indexOf(failed[0])].reason.message + ")");
    var R = {}; keys.forEach(function (k, i) { R[k] = res[i].value; });
    if (state.scale === null) {
      state.scale = await ratioScale(R.r6);
      try { localStorage.setItem("fb.ratioScale", String(state.scale)); } catch (x) { /* ignore */ }
    }
    var geo = R.crest, al = function (r, which) { return C.resampleRegion(r[which], r, geo); };
    var input = { W: geo.W, H: geo.H, scale: state.scale, satScale: R.sat.vmax > 1.5 ? 0.01 : 1, blur: BLUR,
      crest: al(R.crest, "max"), r1: al(R.r1, "max"), r3: al(R.r3, "max"), r6: al(R.r6, "max"), sat: al(R.sat, "mean") };
    if (f.plan && f.plan.now.rate && f.plan.now.prev) {     // storm motion: nice to have, never holds the frame
      var nres = await Promise.allSettled(NOW_KEYS.map(function (k) { return reduceFile(f.plan.now[k].url, { mean: true }); }));
      if (gen !== state.gen) return false;
      if (nres.every(function (r) { return r.status === "fulfilled"; })) NOW_KEYS.forEach(function (k, i) { input[k] = al(nres[i].value, "mean"); });
    }
    var out = await pool.run({ op: "assemble", input: input });
    if (gen !== state.gen) return false;
    f.reg = { W: geo.W, H: geo.H, values: out.values, north: geo.north, west: geo.west, dLat: geo.dLat, dLon: geo.dLon,
      inputs: { crest: true, r1: true, r3: true, r6: true, sat: true }, proj: null, motion: out.motion || null };
    if (!f.t && geo.refTime) f.t = geo.refTime;
    return true;
  }

  async function load() {
    if (state.loading) return;
    state.loading = true; var gen = ++state.gen, hours = +$("#loopLen").value;
    setStatus("load"); setNote("");
    var old = {}; state.frames.forEach(function (f) { if (f.reg) old[f.key] = f; });
    var wasNewest = state.idx < 0 || state.idx === state.frames.length - 1, prevKey = state.frames[state.idx] && state.frames[state.idx].key;
    var plans = null;
    try { plans = await planFrames(hours); } catch (e) { plans = null; }
    if (gen !== state.gen) { state.loading = false; return; }

    if (!plans) {
      // Directory listing unavailable: fall back to the single latest frame.
      var only = { key: "latest", t: null, plan: null };
      state.frames = [only]; $("#scrub").max = 0;
      setLoop("Loading latest grids…");
      try {
        await loadFrame(only, gen);
        only.t = only.t || Date.now(); redisplay(0); setStatus("warn");
        setLoop("Loop unavailable (couldn't list past files); showing latest only.");
      } catch (e) { setStatus("err"); setLoop("No data loaded"); setNote(e.message, true); }
      clock.riskAt = Date.now() + REFRESH_MIN * 60e3;
      state.loading = false; return;
    }

    state.waiting = plans.waiting;
    if (!plans.length) {
      setStatus("warn"); setLoop("Waiting for all inputs" + (plans.waiting ? " at " + zTime(new Date(plans.waiting.t)) + ": " + plans.waiting.missing.join(", ") : "") + ".");
      clock.riskAt = Date.now() + 30e3; state.loading = false; return;
    }
    state.frames = plans.map(function (p) { var k = String(p.t); return old[k] || { key: k, t: p.t, plan: p }; });
    $("#scrub").max = Math.max(0, state.frames.length - 1);
    state.idx = state.frames.findIndex(function (f) { return f.key === prevKey; });
    if (state.idx >= 0 && !wasNewest && !state.playing) showFrame(state.idx);
    var order = state.frames.map(function (f, i) { return i; }).reverse();   // newest first
    var done = 0, failed = 0, firstShown = false, n = state.frames.length;
    for (var k = 0; k < order.length; k++) {
      var i = order[k], f = state.frames[i];
      if (!f.reg) {
        setLoop("Loading frame " + (done + 1) + " of " + n + "…");
        try { if (!(await loadFrame(f, gen))) { state.loading = false; return; } }
        catch (e) { failed++; if (k === 0) setNote((f.t ? zTime(new Date(f.t)) + " frame " : "") + e.message + ". It will be retried.", false); }
      }
      done++;
      if (f.reg && !firstShown) { firstShown = true; setStatus("ok"); if (!state.playing && (wasNewest || state.idx < 0)) redisplay(i); }
    }
    var ready = readyIdx().length;
    setStatus(ready ? (failed ? "warn" : "ok") : "err");
    var nowZ = new Date().toISOString().slice(11, 16) + "Z";
    var wt = state.waiting ? " · " + zTime(new Date(state.waiting.t)) + " waiting on " + state.waiting.missing.join(", ") : "";
    setLoop(ready ? ready + " frames · " + (hours < 1 ? Math.round(hours * 60) + " min" : hours + " h") + ", every " + STEP_MIN + " min · checked " + nowZ + (failed ? " · " + failed + " still loading" : "") + wt : "No frames loaded" + wt);
    loadVerification();
    if (!state.playing && ready && (wasNewest || state.idx < 0)) showFrame(readyIdx().pop());
    state.loading = false;
    clock.riskAt = nextRiskTime(); riskUpdated(); drawProbe();
  }
  $("#loopLen").addEventListener("change", function () { play(false); state.gen++; state.loading = false; load(); });

  // ---------- update clock and risk flash ----------
  // Risk frames are built on the :00/:05 marks, so the next one is pulled ~100 s after the next mark
  // (time for the FLASH files to post), then every 45 s until it shows up. Radar: a Level II volume is
  // named for its start time and posts after it finishes, so the next one is expected at
  // newest start + typical volume interval (median of recent gaps) + typical posting delay (measured
  // each time a new volume shows up; one interval + 1 min until measured). Checks start 20 s before
  // that and repeat every 30 s.
  var clock = { riskAt: 0, radarDue: 0, radarVol: 0, radarCheck: Infinity, radarBusy: false, radarNewAt: 0, radarLags: [], flashKey: null, rise: null };
  var POST_LAG = 100e3;
  function nextRiskTime() {
    var fr = state.frames, last = null, now = Date.now();
    for (var i = fr.length - 1; i >= 0; i--) if (fr[i].reg && fr[i].t) { last = fr[i]; break; }
    if (!last) return now + 60e3;
    if (state.waiting || fr.some(function (f) { return !f.reg; })) return now + 30e3;    // inputs still arriving
    var t = last.t + STEP_MIN * 60e3 + POST_LAG;
    if (t > now + 30e3) return t;
    return now + (now - last.t > 20 * 60e3 ? 150e3 : 45e3);    // late: poll (slower if the feed looks stalled)
  }
  function scheduleRadar(prevNewest) {
    var sc = radar.scans, now = Date.now();
    if (!sc.length) { clock.radarDue = 0; clock.radarCheck = now + 120e3; return; }
    var newest = sc[sc.length - 1].t, gaps = [];
    for (var i = Math.max(1, sc.length - 8); i < sc.length; i++) { var g = sc[i].t - sc[i - 1].t; if (g > 60e3 && g < 15 * 60e3) gaps.push(g); }
    gaps.sort(function (a, b) { return a - b; });
    var every = gaps.length ? gaps[gaps.length >> 1] : 5 * 60e3;
    if (prevNewest && newest > prevNewest) {
      clock.radarNewAt = now;
      var lag = now - newest; if (lag > 0 && lag < 20 * 60e3) { clock.radarLags.push(lag); if (clock.radarLags.length > 6) clock.radarLags.shift(); }
    }
    var lags = clock.radarLags.slice().sort(function (a, b) { return a - b; });
    var postLag = lags.length ? lags[lags.length >> 1] : every + 60e3;
    clock.radarVol = newest + every;               // start time of the next volume
    clock.radarDue = clock.radarVol + postLag;     // when it should be listed
    clock.radarCheck = Math.max(clock.radarDue - 20e3, now + 30e3);
  }
  function mmss(ms) { var s = Math.max(0, Math.round(ms / 1000)); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); }
  function tick() {
    var now = Date.now();
    if (!state.loading && !state.exporting && clock.riskAt && now >= clock.riskAt) { clock.riskAt = now + 90e3; load(); }
    if (radar.site && !clock.radarBusy && now >= clock.radarCheck) {
      clock.radarBusy = true;
      refreshScans().finally(function () { clock.radarBusy = false; if (clock.radarCheck <= Date.now()) clock.radarCheck = Date.now() + 30e3; });
    }
    // risk
    var rt = $("#ckRisk").parentNode;
    if (state.loading) { $("#ckRisk").textContent = "updating"; $("#ckRiskAt").textContent = ""; rt.dataset.s = "busy"; }
    else if (clock.riskAt) {
      var newest = null; for (var i = state.frames.length - 1; i >= 0; i--) if (state.frames[i].reg && state.frames[i].t) { newest = state.frames[i]; break; }
      var expect = newest ? newest.t + STEP_MIN * 60e3 : 0;
      $("#ckRisk").textContent = mmss(clock.riskAt - now);
      $("#ckRiskAt").textContent = expect ? "for " + zTime(new Date(expect)) : "";
      rt.dataset.s = newest && now - newest.t > STEP_MIN * 60e3 + 4 * 60e3 ? "late" : "";
      if (state.waiting) {
        $("#ckRiskAt").textContent = state.waiting.missing.length + " waiting";
        $("#ckRiskAt").title = zTime(new Date(state.waiting.t)) + " frame is waiting on " + state.waiting.missing.join(", ");
        if (now - state.waiting.t > 6 * 60e3) rt.dataset.s = "late";
      } else if (rt.dataset.s === "late") $("#ckRiskAt").textContent = "data late";
    }
    // radar
    var rk = $("#ckRadar").parentNode;
    if (!radar.site) { $("#ckRadarLbl").textContent = "Radar"; $("#ckRadar").textContent = "–:––"; $("#ckRadarAt").textContent = "pick a site"; rk.dataset.s = ""; return; }
    $("#ckRadarLbl").textContent = radar.site.id + " scan";
    if (now - clock.radarNewAt < 1600) rk.dataset.s = "new";
    else if (!clock.radarDue) { $("#ckRadar").textContent = "–:––"; $("#ckRadarAt").textContent = "listing…"; rk.dataset.s = "busy"; }
    else if (now < clock.radarDue) { $("#ckRadar").textContent = mmss(clock.radarDue - now); $("#ckRadarAt").textContent = "vol " + zTime(new Date(clock.radarVol)); rk.dataset.s = ""; }
    else { $("#ckRadar").textContent = "+" + mmss(now - clock.radarDue); $("#ckRadarAt").textContent = clock.radarBusy ? "checking…" : "posting soon"; rk.dataset.s = "late"; }
  }

  // After a live update: compare the newest frame with the one before it inside the current view
  // (at the lead shown: Now, +1 h or +2 h), flash the card and the flood layer, and ring the spot
  // where risk rose most.
  var riseLayer = L.layerGroup().addTo(map);
  function riskUpdated() {
    var ready = readyIdx(); if (!ready.length) return;
    var cur = state.frames[ready[ready.length - 1]], prev = ready.length > 1 ? state.frames[ready[ready.length - 2]] : null;
    if (cur.key === clock.flashKey) return;
    var first = clock.flashKey === null; clock.flashKey = cur.key;
    var lead = view.lead, vals = leadValues(cur.reg, lead);
    if (!vals) { lead = 0; vals = cur.reg.values; }
    var pv = prev && prev.reg && prev.reg.W === cur.reg.W && prev.reg.H === cur.reg.H ? leadValues(prev.reg, lead) : null;
    var r = cur.reg, b = map.getBounds();
    var j0 = Math.max(0, Math.floor((b.getNorth() - r.north) / r.dLat)), j1 = Math.min(r.H - 1, Math.ceil((b.getSouth() - r.north) / r.dLat));
    var i0 = Math.max(0, Math.floor((b.getWest() - r.west) / r.dLon)), i1 = Math.min(r.W - 1, Math.ceil((b.getEast() - r.west) / r.dLon));
    var peak = 0, peakPrev = 0, rise = 0, rk = -1;
    for (var j = j0; j <= j1; j++) for (var i = i0; i <= i1; i++) {
      var k = j * r.W + i, v = vals[k]; if (!(v === v)) continue;
      if (v > peak) peak = v;
      if (pv) { var w = pv[k]; if (w === w) { if (w > peakPrev) peakPrev = w; if (v - w > rise) { rise = v - w; rk = k; } } }
    }
    var pct = function (x) { return Math.round(x * 100); };
    var arrow = function (d) { d = Math.round(d * 100); return d > 0 ? '<span class="up">▲' + d + "</span>" : d < 0 ? '<span class="down">▼' + (-d) + "</span>" : "±0"; };
    var tag = lead ? " (+" + lead + " min)" : "";
    var html = "<b>" + zTime(new Date(cur.t)) + "</b> " + (first ? "risk loaded" : "risk updated") + " · peak in view <b>" + pct(peak) + "%</b>" + tag;
    if (pv && !first) html += " " + arrow(peak - peakPrev);
    if (probe.lat !== null) {
      var a = sampleReg(cur.reg, probe.lat, probe.lon, lead), z = pv ? sampleReg(prev.reg, probe.lat, probe.lon, lead) : NaN;
      if (a === a) html += " · " + (probe.name || "point") + " <b>" + pct(a) + "%</b>" + (z === z && !first ? " " + arrow(a - z) : "");
    }
    riseLayer.clearLayers(); clock.rise = null;
    if (pv && !first && rise >= 0.05 && rk >= 0) {
      var lat = r.north + (Math.floor(rk / r.W) + 0.5) * r.dLat, lon = r.west + (rk % r.W + 0.5) * r.dLon, c = levelColor(vals[rk]);
      clock.rise = [lat, lon];
      html += " · biggest rise <span class=\"up\">▲" + pct(rise) + "</span> to " + pct(vals[rk]) + "% (tap to show)";
      L.marker([lat, lon], { pane: "floodLabels", interactive: false, keyboard: false,
        icon: L.divIcon({ className: "rise", iconSize: null, html: '<span>▲' + pct(rise) + "</span>" }) }).addTo(riseLayer);
      riseLayer.eachLayer(function (m) { var el = m.getElement(); if (el) el.style.setProperty("--c", c); });
    } else if (pv && !first) html += " · no rise of 5% or more in view";
    var f = $("#riskFlash");
    f.innerHTML = html; f.hidden = false; f.style.setProperty("--c", levelColor(Math.max(peak, 0.05)));
    if (!first) [f, map.getPane("flood")].forEach(function (el) { el.classList.remove("go"); void el.offsetWidth; el.classList.add("go"); });
  }
  $("#riskFlash").addEventListener("click", function () { if (clock.rise) map.flyTo(clock.rise, Math.max(map.getZoom(), 8), { duration: 0.8 }); });

  // ---------- verification: NWS flood warnings and storm reports (Iowa State archive) ----------
  map.createPane("verify"); map.getPane("verify").style.zIndex = 640; map.getPane("verify").style.pointerEvents = "none";
  var verify = { on: true, reportsOn: true, warnings: [], reports: [], layer: L.layerGroup().addTo(map), key: null, note: "" };
  try { verify.on = localStorage.getItem("fb.warningsOn") !== "0"; verify.reportsOn = localStorage.getItem("fb.reportsOn") !== "0"; } catch (x) { /* ignore */ }
  function isoMin(ms) { return new Date(ms).toISOString().slice(0, 16) + "Z"; }
  function toMs(v) { if (v === null || v === undefined || v === "") return NaN; var t = Date.parse(String(v).replace(" ", "T") + (/[zZ]|[+-]\d\d:?\d\d$/.test(String(v)) ? "" : "Z")); return t; }
  async function loadVerification() {
    var fr = state.frames.filter(function (f) { return f.t; }), start, end;
    if (!fr.length) return;
    start = fr[0].t - 3 * 3600e3; end = fr[fr.length - 1].t + 30 * 60e3;
    var wfos = (radar.site && radar.site.wfo) || "";
    if (!wfos) { verify.warnings = []; verify.reports = []; drawVerification(); return; }
    var key = wfos + start + end; if (verify.key === key) return; verify.key = key;
    var notes = [];
    try {
      var j = await fetchVia(IEM_GEO + "sbw.py?sts=" + isoMin(start) + "&ets=" + isoMin(end) + "&wfos=" + wfos, "json");
      verify.warnings = (j.features || []).map(function (f) {
        var p = f.properties || {};
        var begin = toMs(p.polygon_begin || p.issue), stop = toMs(p.polygon_end || p.expire);
        return { f: f, ph: p.phenomena, sig: p.significance, begin: begin, end: stop, emergency: !!(p.is_emergency || p.emergency),
          label: (p.phenomena === "FF" ? "Flash Flood Warning" : "Flood Warning") + (p.eventid ? " #" + p.eventid : "") };
      }).filter(function (w) { return (w.ph === "FF" || w.ph === "FA") && w.sig === "W" && w.begin === w.begin; });
    } catch (e) { verify.warnings = []; notes.push("warnings unavailable"); }
    try {
      var j2 = await fetchVia(IEM_GEO + "lsr.py?sts=" + isoMin(start) + "&ets=" + isoMin(end) + "&wfos=" + wfos, "json");
      verify.reports = (j2.features || []).map(function (f) {
        var p = f.properties || {}, c = (f.geometry || {}).coordinates || [];
        return { t: toMs(p.valid), lat: c[1], lon: c[0], type: String(p.typetext || p.type || ""), mag: p.magnitude, unit: p.unit || "",
          city: p.city || "", remark: p.remark || "" };
      }).filter(function (r) { return r.t === r.t && /FLOOD|RAIN/i.test(r.type); });
    } catch (e) { verify.reports = []; notes.push("storm reports unavailable"); }
    verify.note = notes.length ? "Verification: " + notes.join(", ") + "." : "";
    drawVerification(); drawProbe();
  }
  function drawVerification() {
    verify.layer.clearLayers();
    var f = state.frames[state.idx];
    $("#verifyNote").textContent = verify.note;
    if ((!verify.on && !verify.reportsOn) || !f || !f.t) { $("#verifyNow").textContent = ""; return; }
    var t = f.t, active = 0, emerg = 0;
    if (verify.on) verify.warnings.forEach(function (w) {
      if (!(w.begin <= t && (!(w.end === w.end) || t < w.end))) return;
      active++; if (w.emergency) emerg++;
      L.geoJSON(w.f, { pane: "verify", interactive: false, style: w.emergency ?
        { color: "#ff3ec8", weight: 3.2, fill: false } : w.ph === "FF" ? { color: "#ff5a5a", weight: 2, dashArray: "6 4", fill: false } : { color: "#3ddc84", weight: 1.5, dashArray: "2 4", fill: false } }).addTo(verify.layer);
    });
    var shown = 0;
    if (verify.reportsOn) verify.reports.forEach(function (r) {
      if (r.t > t || r.t < state.frames[0].t - 3 * 3600e3) return;
      shown++;
      var rain = /RAIN/i.test(r.type), fresh = t - r.t < 60 * 60e3;
      var m = L.circleMarker([r.lat, r.lon], { pane: "verify", radius: rain ? 4 : 6, weight: 2, color: rain ? "#9fd8ea" : "#ffffff",
        fillColor: rain ? "#000000" : (fresh ? "#ff3ec8" : "#7a2b66"), fillOpacity: 1, interactive: true });
      var when = new Date(r.t).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
      m.bindTooltip("<b>" + r.type + "</b> · " + when + (r.city ? " · " + r.city : "") + (r.mag ? " · " + r.mag + " " + r.unit : "") +
        (r.remark ? "<br>" + String(r.remark).slice(0, 160).replace(/</g, "&lt;") : ""), { direction: "top" });
      m.addTo(verify.layer);
    });
    var parts = [];
    if (verify.on) parts.push(active + " warning" + (active === 1 ? "" : "s") + (emerg ? " (" + emerg + " emergency)" : ""));
    if (verify.reportsOn) parts.push(shown + " flood report" + (shown === 1 ? "" : "s") + " so far");
    $("#verifyNow").textContent = active || shown ? parts.join(" · ") : verify.on && verify.reportsOn ? "No warnings or flood reports yet" : verify.on ? "No warnings yet" : "No flood reports yet";
  }
  $("#verifyOn").checked = verify.on; $("#reportsOn").checked = verify.reportsOn;
  $("#verifyOn").addEventListener("change", function (e) { verify.on = e.target.checked; try { localStorage.setItem("fb.warningsOn", verify.on ? "1" : "0"); } catch (x) { /* ignore */ } drawVerification(); });
  $("#reportsOn").addEventListener("change", function (e) { verify.reportsOn = e.target.checked; try { localStorage.setItem("fb.reportsOn", verify.reportsOn ? "1" : "0"); } catch (x) { /* ignore */ } drawVerification(); });

  // ---------- point probe: likelihood over time at one spot ----------
  var probe = { lat: null, lon: null, name: "", marker: null };
  function setProbe(lat, lon, name) {
    probe.lat = lat; probe.lon = lon; probe.name = name || llText(lat, lon);
    if (probe.marker) map.removeLayer(probe.marker);
    probe.marker = L.marker([lat, lon], { interactive: false, keyboard: false, pane: "floodLabels",
      icon: L.divIcon({ className: "probe-pin", iconSize: [18, 18], iconAnchor: [9, 9], html: "<span></span>" }) }).addTo(map);
    $("#probeSec").hidden = false;
    drawProbe();
  }
  $("#probeClose").addEventListener("click", function () {
    if (probe.marker) map.removeLayer(probe.marker);
    probe.lat = probe.lon = null; probe.marker = null; $("#probeSec").hidden = true; placeLabels();
  });
  function llText(lat, lon) { return Math.abs(lat).toFixed(2) + "°" + (lat >= 0 ? "N" : "S") + " " + Math.abs(lon).toFixed(2) + "°" + (lon >= 0 ? "E" : "W"); }
  function sampleReg(reg, lat, lon, lead) {
    var v = lead ? reg.proj && reg.proj[lead] : reg.values, sc = lead ? 1 / 250 : 1;
    if (!v) return NaN;
    var fx = (lon - reg.west) / reg.dLon - 0.5, fy = (lat - reg.north) / reg.dLat - 0.5;
    var i = Math.floor(fx), j = Math.floor(fy);
    if (i < 0 || j < 0 || i >= reg.W - 1 || j >= reg.H - 1) return NaN;
    var tx = fx - i, ty = fy - j, W = reg.W;
    return sc * (v[j * W + i] * (1 - tx) * (1 - ty) + v[j * W + i + 1] * tx * (1 - ty) + v[(j + 1) * W + i] * (1 - tx) * ty + v[(j + 1) * W + i + 1] * tx * ty);
  }
  function pointInGeom(geom, lat, lon) {
    if (!geom) return false;
    var polys = geom.type === "Polygon" ? [geom.coordinates] : geom.type === "MultiPolygon" ? geom.coordinates : [];
    return polys.some(function (poly) {
      var inside = false, ring = poly[0] || [];
      for (var i = 0, j = ring.length - 1; i < ring.length; j = i++) {
        var xi = ring[i][0], yi = ring[i][1], xj = ring[j][0], yj = ring[j][1];
        if (((yi > lat) !== (yj > lat)) && (lon < (xj - xi) * (lat - yi) / (yj - yi) + xi)) inside = !inside;
      }
      return inside;
    });
  }
  function fmtDur(ms) { var m = Math.round(Math.abs(ms) / 60000), h = Math.floor(m / 60); return (h ? h + " h " : "") + (m % 60) + " min"; }
  function drawProbe() {
    if (probe.lat === null) return;
    var pts = state.frames.filter(function (f) { return f.reg && f.t; }).map(function (f) { return { t: f.t, p: sampleReg(f.reg, probe.lat, probe.lon) }; })
      .filter(function (d) { return d.p === d.p; });
    $("#probeName").textContent = probe.name;
    var svg = $("#probeChart");
    if (pts.length < 2) { svg.innerHTML = ""; $("#probeStats").textContent = pts.length ? "Waiting for more frames…" : "No frames cover this point yet."; return; }
    var W = 280, H = 84, padL = 26, padR = 6, padT = 6, padB = 16;
    var t0 = state.frames[0].t, t1 = state.frames[state.frames.length - 1].t;
    var X = function (t) { return padL + (t - t0) / Math.max(1, t1 - t0) * (W - padL - padR); };
    var Y = function (p) { return padT + (1 - p) * (H - padT - padB); };
    var line = pts.map(function (d, k) { return (k ? "L" : "M") + X(d.t).toFixed(1) + "," + Y(d.p).toFixed(1); }).join("");
    var area = line + "L" + X(pts[pts.length - 1].t).toFixed(1) + "," + Y(0) + "L" + X(pts[0].t).toFixed(1) + "," + Y(0) + "Z";
    var hits = verify.warnings.filter(function (w) { return w.ph === "FF" && pointInGeom(w.f.geometry, probe.lat, probe.lon); });
    var firstFF = hits.reduce(function (m, w) { return Math.min(m, w.begin); }, Infinity);
    var firstFFE = hits.filter(function (w) { return w.emergency; }).reduce(function (m, w) { return Math.min(m, w.begin); }, Infinity);
    var marks = "";
    [[firstFF, "#ff5a5a", "FFW"], [firstFFE, "#ff3ec8", "FFE"]].forEach(function (m) {
      if (m[0] === Infinity || m[0] < t0 || m[0] > t1) return;
      marks += '<line x1="' + X(m[0]) + '" x2="' + X(m[0]) + '" y1="' + padT + '" y2="' + (H - padB) + '" stroke="' + m[1] + '" stroke-width="1.5" stroke-dasharray="3 2"/>' +
        '<text x="' + (X(m[0]) + 3) + '" y="' + (padT + 9) + '" fill="' + m[1] + '" font-size="9">' + m[2] + "</text>";
    });
    var cur = state.frames[state.idx], curX = cur && cur.t ? X(cur.t) : null;
    var grid = [0.5, 0.7].map(function (v) {
      return '<line x1="' + padL + '" x2="' + (W - padR) + '" y1="' + Y(v) + '" y2="' + Y(v) + '" stroke="' + levelColor(v) + '" stroke-opacity=".55" stroke-dasharray="2 3"/>' +
        '<text x="' + (padL - 4) + '" y="' + (Y(v) + 3) + '" fill="#9a9a9a" font-size="9" text-anchor="end">' + Math.round(v * 100) + "</text>";
    }).join("");
    var tl = function (t) { return new Date(t).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }); };
    svg.setAttribute("viewBox", "0 0 " + W + " " + H);
    svg.innerHTML = '<rect x="' + padL + '" y="' + padT + '" width="' + (W - padL - padR) + '" height="' + (H - padT - padB) + '" fill="#000000" stroke="#2a2a2a"/>' + grid +
      '<path d="' + area + '" fill="#34d27b" fill-opacity=".14"/><path d="' + line + '" fill="none" stroke="#34d27b" stroke-width="1.8"/>' +
      marks +
      (curX !== null ? '<line x1="' + curX + '" x2="' + curX + '" y1="' + padT + '" y2="' + (H - padB) + '" stroke="#f2f2f2" stroke-opacity=".5"/>' : "") +
      '<text x="' + padL + '" y="' + (H - 4) + '" fill="#9a9a9a" font-size="9">' + tl(t0) + "</text>" +
      '<text x="' + (W - padR) + '" y="' + (H - 4) + '" fill="#9a9a9a" font-size="9" text-anchor="end">' + tl(t1) + "</text>" +
      '<text x="' + (padL - 4) + '" y="' + (padT + 6) + '" fill="#9a9a9a" font-size="9" text-anchor="end">100</text>';
    var peak = pts.reduce(function (m, d) { return d.p > m.p ? d : m; }, pts[0]);
    var cross = function (v) { var d = pts.find(function (q) { return q.p >= v; }); return d ? d.t : null; };
    var c50 = cross(0.5), c70 = cross(0.7);
    var out = ["Peak " + Math.round(peak.p * 100) + "% at " + tl(peak.t)];
    out.push(c50 ? "≥50% from " + tl(c50) : "never reached 50%");
    if (c70) out.push("≥70% from " + tl(c70));
    var vs = function (tw, name) {
      if (tw === Infinity) return;
      var rel = function (ref, what) { return ref ? what + " " + (ref <= tw ? fmtDur(tw - ref) + " ahead" : fmtDur(ref - tw) + " behind") : what + " never reached it"; };
      out.push(name + " at " + tl(tw) + ": " + rel(c70 || c50, (c70 ? "70%" : "50%")));
    };
    vs(firstFF, "First FFW"); vs(firstFFE, "FF Emergency");
    $("#probeStats").textContent = out.join(" · ");
  }
  map.on("click", function (e) { setProbe(e.latlng.lat, L.Util.wrapNum(e.latlng.lng, [-180, 180], true)); });

  // ---------- contour display: level set, opacity, legend ----------
  function drawLegend() {
    var LV = levels();
    if (view.mode === "standard") {
      $("#legend").className = "legend";
      $("#legend").style.gridTemplateColumns = "repeat(" + LV.length + ", 1fr)";
      $("#legend").innerHTML = LV.map(function (l) {
        return '<span class="sw"><i style="background:' + levelColor(l) + '"></i>' + Math.round(l * 100) + "%</span>";
      }).join("");
    } else {
      $("#legend").className = "legend ramp";
      $("#legend").style.gridTemplateColumns = "";
      $("#legend").innerHTML = '<div class="bands">' + LV.map(function (l) { return '<i style="background:' + levelColor(l) + '"></i>'; }).join("") + "</div>" +
        '<div class="ticks">' + [0.05, 0.25, 0.50, 0.75, 0.95].map(function (v) {
          return '<span style="left:' + ((v - 0.05) / 0.95 * 100 + 100 / 38).toFixed(2) + '%">' + Math.round(v * 100) + "</span>";
        }).join("") + "</div>";
    }
  }
  function setStyle(st) {
    if (!STYLES[st]) return;
    view.style = st;
    try { localStorage.setItem("fb.style", st); } catch (x) { /* ignore */ }
    document.querySelectorAll("#cstyle button").forEach(function (b) { b.setAttribute("aria-pressed", b.dataset.style === st ? "true" : "false"); });
    clearBundles(); redisplay();
  }
  document.querySelectorAll("#cstyle button").forEach(function (b) { b.addEventListener("click", function () { setStyle(b.dataset.style); }); });
  function setLevelMode(m) {
    if (!LEVEL_SETS[m]) return;
    view.mode = m;
    try { localStorage.setItem("fb.levels", m); } catch (x) { /* ignore */ }
    document.querySelectorAll("#levels button").forEach(function (b) { b.setAttribute("aria-pressed", b.dataset.mode === m ? "true" : "false"); });
    clearBundles();   // rebuild on next show
    drawLegend();
    redisplay();
  }
  document.querySelectorAll("#levels button").forEach(function (b) { b.addEventListener("click", function () { setLevelMode(b.dataset.mode); }); });
  function setOpacity(v) {
    view.opacity = v;
    $("#opacityVal").textContent = Math.round(v * 100) + "%";
    try { localStorage.setItem("fb.opacity", String(v)); } catch (x) { /* ignore */ }
    if (state.shown) applyOpacity(state.shown);
  }
  $("#opacity").value = Math.round(view.opacity * 100);
  $("#opacity").addEventListener("input", function (e) { setOpacity(+e.target.value / 100); });
  setOpacity(view.opacity);
  setLevelMode(view.mode);
  setStyle(view.style);
  $("#play").innerHTML = ICON.play + "<span>Play loop</span>";

  // ---------- equation (rendered from the constants the code uses) ----------
  (function () {
    var E = C.EQ, k = function (v) { return '<span class="k">' + v + "</span>"; };
    $("#equation").innerHTML =
      '<div class="formula">P = 1 / (1 + e<sup>−z</sup>)<br>' +
      "z = " + k(E.wQ) + "·" + k(E.kQ) + "·ln(Q / " + k(E.Q50.toFixed(1)) + ")<br>" +
      "&nbsp;&nbsp;+ " + k(E.wR) + "·" + k(E.kR) + "·(R̄ − " + k(E.R50.toFixed(2)) + ")<br>" +
      "&nbsp;&nbsp;+ " + k(E.kS.toFixed(1)) + "·(S − " + k(E.S50.toFixed(2)) + ")</div>" +
      '<dl class="terms">' +
      "<dt>Q</dt><dd>CREST max unit streamflow, m³ s⁻¹ km⁻² (5 km block max)</dd>" +
      "<dt>R̄</dt><dd>Mean of the 1, 3 and 6 h QPE÷FFG ratios (1.00 = 100%)</dd>" +
      "<dt>S</dt><dd>CREST max soil saturation, 0–1 (5 km block mean)</dd>" +
      "<dt>P</dt><dd>Flood likelihood, smoothed over ~25 km, contoured at 5–85% (or every 5%)</dd>" +
      "</dl>" +
      '<p class="note" style="margin-top:6px">If Q or R̄ is missing, the other carries the full ' + (E.wQ + E.wR).toFixed(1) +
      " weight. If S is missing, its term is left out. 50% sits at Q = " + E.Q50 + ", R̄ = " + E.R50.toFixed(2) + ", S = " + E.S50 + ".</p>" +
      "";
  })();

  // ---------- export: loop as GIF or video, contour-only design graphic (PNG) ----------
  var GIFENC_URL = "https://cdn.jsdelivr.net/npm/gifenc@1.0.3/dist/gifenc.esm.js";
  var TOPO_URL = "https://cdn.jsdelivr.net/npm/topojson-client@3.1.0/dist/topojson-client.min.js";
  var ATLAS_URL = "https://cdn.jsdelivr.net/npm/us-atlas@3.0.1/counties-10m.json";
  var FONT_UI = "'Barlow Semi Condensed', 'Arial Narrow', Arial, sans-serif", FONT_MONO = "'JetBrains Mono', ui-monospace, Menlo, Consolas, monospace";
  var PLACES_URL = /^https?:$/.test(location.protocol) ? "/data/us_places.tsv" : "data/us_places.tsv";   // served by serve.py: GeoNames places >= 2,500 people
  var exp = { busy: false, fmt: "gif", theme: "dark", tiles: {}, atlas: null, places: null };
  function setExpNote(t, bad) { var n = $("#expNote"); n.textContent = t || ""; n.classList.toggle("bad", !!bad); }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function frames2() { return new Promise(function (r) { requestAnimationFrame(function () { requestAnimationFrame(r); }); }); }
  function loadImg(src, cors) {
    return new Promise(function (res, rej) { var im = new Image(); if (cors) im.crossOrigin = "anonymous"; im.onload = function () { res(im); }; im.onerror = function () { rej(new Error("image")); }; im.src = src; });
  }
  function loadScript(src) {
    return new Promise(function (res, rej) { var s = document.createElement("script"); s.src = src; s.onload = res; s.onerror = function () { rej(new Error("couldn't load " + src)); }; document.head.appendChild(s); });
  }
  function fileStamp(ms) { return new Date(ms).toISOString().slice(0, 16).replace(/[-:]/g, "").replace("T", "_") + "Z"; }
  function download(blob, name) {
    var a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(a.href); }, 60e3);
  }
  function rrect(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  async function fontsReady() {
    try { await Promise.all(["400 16px 'Barlow Semi Condensed'", "600 16px 'Barlow Semi Condensed'", "700 16px 'Barlow Semi Condensed'", "400 16px 'JetBrains Mono'", "600 16px 'JetBrains Mono'"].map(function (f) { return document.fonts.load(f); })); } catch (e) { /* system fonts */ }
  }
  function lockMap(on) {
    ["dragging", "touchZoom", "doubleClickZoom", "scrollWheelZoom", "boxZoom", "keyboard"].forEach(function (h) { if (map[h]) map[h][on ? "disable" : "enable"](); });
    document.querySelectorAll("#expLoop, #expPng").forEach(function (b) { b.disabled = on; });
  }
  function leadLabel(f, lead) {
    return lead ? "+" + lead + " min projection · valid " + zTime(new Date(f.t + lead * 60e3)) + " · made " + zTime(new Date(f.t)) : "Now · valid " + zTime(new Date(f.t));
  }

  // Draw what the map shows (background tiles, radar sweep, contours, warnings, labels) onto ctx.
  async function snapshotMap(ctx, scale) {
    var box = map.getContainer().getBoundingClientRect(), W = box.width, H = box.height, missing = false;
    var rectOf = function (el) { var r = el.getBoundingClientRect(); return { x: r.left - box.left, y: r.top - box.top, w: r.width, h: r.height }; };
    var seen = function (r) { return r.w > 0 && r.h > 0 && r.x < W && r.y < H && r.x + r.w > 0 && r.y + r.h > 0; };
    ctx.save(); ctx.scale(scale, scale);
    ctx.fillStyle = "#000000"; ctx.fillRect(0, 0, W, H);
    async function tiles(layer, alpha) {
      if (!layer || !map.hasLayer(layer)) return;
      var ts = layer._tiles || {};
      for (var k in ts) {
        var t = ts[k]; if (!t.current || !t.el) continue;
        var r = rectOf(t.el); if (!seen(r)) continue;
        if (t.el.tagName === "CANVAS") { ctx.globalAlpha = alpha; ctx.drawImage(t.el, r.x, r.y, r.w, r.h); continue; }
        var src = t.el.currentSrc || t.el.src; if (!src) continue;
        if (!(src in exp.tiles)) { try { exp.tiles[src] = await loadImg(src, true); } catch (e) { exp.tiles[src] = null; } }
        if (exp.tiles[src]) { ctx.globalAlpha = alpha; ctx.drawImage(exp.tiles[src], r.x, r.y, r.w, r.h); } else missing = true;
      }
      ctx.globalAlpha = 1;
    }
    async function svgs(pane) {
      var el = map.getPane(pane); if (!el) return;
      var list = el.querySelectorAll("svg");
      for (var i = 0; i < list.length; i++) {
        var r = rectOf(list[i]); if (!seen(r)) continue;
        var c = list[i].cloneNode(true);
        c.setAttribute("xmlns", "http://www.w3.org/2000/svg"); c.setAttribute("width", r.w); c.setAttribute("height", r.h); c.removeAttribute("style");
        try { ctx.drawImage(await loadImg("data:image/svg+xml;charset=utf-8," + encodeURIComponent(new XMLSerializer().serializeToString(c))), r.x, r.y, r.w, r.h); } catch (e) { /* skip */ }
      }
    }
    await tiles(baseLayer, 1);
    var ov = radar.on && radar.shownKey && radar.layers[radar.shownKey], ovImg = ov && map.hasLayer(ov) && ov.getElement();
    if (ovImg) { try { await ovImg.decode(); } catch (e) { /* drawn as is */ } var orr = rectOf(ovImg); if (seen(orr)) { ctx.globalAlpha = radar.opacity; ctx.drawImage(ovImg, orr.x, orr.y, orr.w, orr.h); ctx.globalAlpha = 1; } }
    await svgs("radar"); await svgs("flood"); await svgs("verify");
    await tiles(labelLayer, 1);
    // contour labels, probe pin, rise marker (HTML markers)
    map.getPane("floodLabels").querySelectorAll(".clabel span").forEach(function (sp) {
      var r = rectOf(sp); if (!seen(r)) return;
      var c = getComputedStyle(sp).getPropertyValue("--c").trim() || "#ffffff", minor = sp.parentNode.classList.contains("minor");
      rrect(ctx, r.x, r.y, r.w, r.h, 3); ctx.fillStyle = "rgba(0,0,0,.88)"; ctx.fill();
      ctx.setLineDash(minor ? [3, 2] : []); ctx.lineWidth = 1; ctx.strokeStyle = c; ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = c; ctx.font = (minor ? "400" : "600") + " 11px " + FONT_MONO; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.fillText(sp.textContent, r.x + r.w / 2, r.y + r.h / 2 + 0.5);
    });
    var pin = document.querySelector(".probe-pin span");
    if (pin) { var pr = rectOf(pin); if (seen(pr)) { var px = pr.x + pr.w / 2, py = pr.y + pr.h / 2;
      ctx.beginPath(); ctx.arc(px, py, 10, 0, 7); ctx.strokeStyle = "#000000"; ctx.lineWidth = 2; ctx.stroke();
      ctx.beginPath(); ctx.arc(px, py, 8, 0, 7); ctx.strokeStyle = "#ffffff"; ctx.stroke();
      ctx.beginPath(); ctx.arc(px, py, 2, 0, 7); ctx.fillStyle = "#ffffff"; ctx.fill(); } }
    riseLayer.eachLayer(function (m) {
      var el = m.getElement(); if (!el) return;
      var r = rectOf(el), c = el.style.getPropertyValue("--c") || "#ff8a7a", sp = el.querySelector("span");
      ctx.beginPath(); ctx.arc(r.x, r.y, 14, 0, 7); ctx.strokeStyle = c; ctx.lineWidth = 2; ctx.stroke();
      if (sp) { var s = rectOf(sp); rrect(ctx, s.x, s.y, s.w, s.h, 3); ctx.fillStyle = c; ctx.fill();
        ctx.fillStyle = "#000000"; ctx.font = "600 11.5px " + FONT_MONO; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText(sp.textContent, s.x + s.w / 2, s.y + s.h / 2 + 0.5); }
    });
    ctx.restore();
    return { missingTiles: missing };
  }

  // Title block and legend burned into each loop frame.
  function drawLoopOverlay(ctx, w, h, f) {
    var s = Math.max(0.75, Math.min(1.4, w / 960)), pad = 12 * s, LV = levels();
    var title = "FlashRisk · Flood likelihood", line2 = leadLabel(f, view.lead) + " · " + new Date(f.t).toLocaleDateString([], { month: "short", day: "numeric", year: "numeric", timeZone: "UTC" });
    var line3 = radar.on && radar.site && radar.shownKey ? "Radar " + radar.site.id + " " + zTime(new Date(radar.scans.filter(function (q) { return q.key === radar.shownKey; }).concat([{ t: NaN }])[0].t)) + " · 0.5° reflectivity" : "";
    ctx.save();
    ctx.font = "700 " + 17 * s + "px " + FONT_UI; var tw = ctx.measureText(title).width;
    ctx.font = "600 " + 12 * s + "px " + FONT_MONO; tw = Math.max(tw, ctx.measureText(line2).width, line3 ? ctx.measureText(line3).width : 0);
    var bh = (line3 ? 64 : 48) * s;
    rrect(ctx, pad, pad, tw + 24 * s, bh, 6 * s); ctx.fillStyle = "rgba(0,0,0,.84)"; ctx.fill(); ctx.strokeStyle = "rgba(52,210,123,.55)"; ctx.lineWidth = 1; ctx.stroke();
    ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "#f2f2f2"; ctx.font = "700 " + 17 * s + "px " + FONT_UI; ctx.fillText(title, pad + 12 * s, pad + 22 * s);
    ctx.fillStyle = "#34d27b"; ctx.font = "600 " + 12 * s + "px " + FONT_MONO; ctx.fillText(line2, pad + 12 * s, pad + 39 * s);
    if (line3) { ctx.fillStyle = "#9a9a9a"; ctx.fillText(line3, pad + 12 * s, pad + 55 * s); }
    // legend, bottom left
    var sw = (view.mode === "every5" ? 15 : 34) * s, lx = pad, ly = h - pad - 30 * s, lw = sw * LV.length + 20 * s;
    rrect(ctx, lx, ly, lw, 30 * s - 2, 5 * s); ctx.fillStyle = "rgba(0,0,0,.84)"; ctx.fill();
    LV.forEach(function (v, i) {
      ctx.fillStyle = levelColor(v); ctx.fillRect(lx + 10 * s + i * sw, ly + 6 * s, sw - 2, 7 * s);
      var p = Math.round(v * 100);
      if (view.mode !== "every5" || p % 10 === 0 && p % 20 !== 0 || p === 5) { ctx.fillStyle = "#9a9a9a"; ctx.font = 9.5 * s + "px " + FONT_MONO; ctx.textAlign = "center"; ctx.fillText(p + "%", lx + 10 * s + i * sw + sw / 2, ly + 24 * s); }
    });
    ctx.textAlign = "right"; ctx.fillStyle = "rgba(235,235,235,.7)"; ctx.font = 10 * s + "px " + FONT_MONO;
    ctx.fillText("Experimental · not an official NWS product", w - pad, h - pad);
    ctx.restore();
  }

  async function radarReady() {
    if (!(radar.on && radar.site)) return;
    var sc = wantedScan();
    if (sc && !radar.data[sc.key]) { try { await getScan(sc.key); } catch (e) { /* frame shows without radar */ } syncRadar(); }
    var ov = radar.shownKey && radar.layers[radar.shownKey], el = ov && ov.getElement();
    if (el) { try { await el.decode(); } catch (e) { /* ignore */ } }
  }

  async function exportLoop() {
    if (exp.busy) return;
    var r = readyIdx();
    if (r.length < 2) { setExpNote("Wait for at least two frames to load.", true); return; }
    exp.busy = true; state.exporting = true; var keep = state.idx, wasPlaying = state.playing; play(false); lockMap(true);
    var fmt = exp.fmt, mime = null;
    try {
      if (fmt === "video") {
        mime = ["video/mp4;codecs=avc1", "video/mp4", "video/webm;codecs=vp9", "video/webm"].filter(function (m) { return window.MediaRecorder && MediaRecorder.isTypeSupported(m); })[0];
        if (!mime) throw new Error("this browser can't record video; use GIF");
      }
      var gifenc = fmt === "gif" ? await import(GIFENC_URL) : null;
      await fontsReady();
      if (radar.on && radar.site) { setExpNote("Loading radar scans…"); await prefetchScans(); }
      var size = map.getSize(), target = +$("#expSize").value || size.x, scale = Math.min(1, target / size.x);
      var cw = Math.round(size.x * scale / 2) * 2, ch = Math.round(size.y * scale / 2) * 2;
      var cv = document.createElement("canvas"); cv.width = cw; cv.height = ch;
      var ctx = cv.getContext("2d", { willReadFrequently: true }), enc = gifenc ? gifenc.GIFEncoder() : null, shots = [], missing = false;
      for (var k = 0; k < r.length; k++) {
        setExpNote("Rendering frame " + (k + 1) + " of " + r.length + "…");
        showFrame(r[k]);
        await radarReady(); await frames2();
        ctx.clearRect(0, 0, cw, ch);
        missing = (await snapshotMap(ctx, scale)).missingTiles || missing;
        drawLoopOverlay(ctx, cw, ch, state.frames[r[k]]);
        var delay = Math.round(k === r.length - 1 ? Math.max(500, LAST_HOLD_MS / state.speed) : FRAME_MS / state.speed);
        if (enc) {
          var px = ctx.getImageData(0, 0, cw, ch).data, pal = gifenc.quantize(px, 256), idx = gifenc.applyPalette(px, pal);
          enc.writeFrame(idx, cw, ch, { palette: pal, delay: delay });
        } else shots.push({ img: await createImageBitmap(cv), delay: delay });
        await wait(0);
      }
      var first = state.frames[r[0]], last = state.frames[r[r.length - 1]];
      var name = "flashrisk_loop_" + fileStamp(first.t) + "-" + zTime(new Date(last.t)).replace(":", "");
      var blob;
      if (enc) { enc.finish(); blob = new Blob([enc.bytes()], { type: "image/gif" }); }
      else {
        setExpNote("Recording video (plays the loop once in real time)…");
        var vc = document.createElement("canvas"); vc.width = cw; vc.height = ch; var vctx = vc.getContext("2d");
        vctx.drawImage(shots[0].img, 0, 0);
        var stream = vc.captureStream(30), rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 8e6 }), chunks = [];
        rec.ondataavailable = function (e) { if (e.data.size) chunks.push(e.data); };
        var stopped = new Promise(function (res) { rec.onstop = res; });
        rec.start(250);
        for (var j = 0; j < shots.length; j++) { vctx.drawImage(shots[j].img, 0, 0); await wait(shots[j].delay); }
        rec.stop(); await stopped; stream.getTracks().forEach(function (t) { t.stop(); });
        blob = new Blob(chunks, { type: mime.split(";")[0] });
      }
      download(blob, name + (fmt === "gif" ? ".gif" : mime.indexOf("mp4") >= 0 ? ".mp4" : ".webm"));
      setExpNote("Saved " + r.length + " frames, " + cw + "×" + ch + ", " + (blob.size / 1048576).toFixed(1) + " MB." +
        (missing ? " The background map server didn't allow copying its tiles, so the background is plain." : ""));
    } catch (e) { setExpNote("Export failed: " + e.message, true); }
    finally {
      if (state.frames[keep]) showFrame(keep);
      lockMap(false); exp.busy = false; state.exporting = false; if (wasPlaying) play(true);
    }
  }

  // ---------- contour-only design graphic ----------
  var THEMES = {
    dark: { bg: "#000000", panel: "#0c0c0c", edge: "#2a2a2a", ink: "#f2f2f2", muted: "#9a9a9a", accent: "#34d27b", fill: 0.55,
      coast: "rgba(235,235,235,.78)", state: "rgba(235,235,235,.55)", county: "rgba(235,235,235,.24)", grid: "rgba(235,235,235,.06)", chip: "rgba(0,0,0,.9)", labelInk: null, cityInk: "#c4c4c4" },
    light: { bg: "#f7f7f7", panel: "#ffffff", edge: "#d9d9d9", ink: "#111111", muted: "#666666", accent: "#12924a", fill: 0.5,
      coast: "rgba(17,17,17,.72)", state: "rgba(17,17,17,.52)", county: "rgba(17,17,17,.2)", grid: "rgba(17,17,17,.05)", chip: "rgba(255,255,255,.94)", labelInk: "#111111", cityInk: "#3a3a3a" }
  };
  async function loadAtlas() {
    if (exp.atlas) return exp.atlas;
    if (!window.topojson) await loadScript(TOPO_URL);
    var us = await (await fetch(ATLAS_URL)).json(), T = window.topojson;
    exp.atlas = {
      nation: T.mesh(us, us.objects.nation),
      states: T.mesh(us, us.objects.states, function (a, b) { return a !== b; }),
      counties: T.mesh(us, us.objects.counties, function (a, b) { return a !== b && (a.id / 1000 | 0) === (b.id / 1000 | 0); })
    };
    return exp.atlas;
  }
  function shade(hex, f) {   // darken a #rrggbb colour (f < 1) for text on a light background
    var h = parseInt(hex.slice(1), 16), c = function (sh) { return Math.round(((h >> sh) & 255) * f); };
    return "rgb(" + c(16) + "," + c(8) + "," + c(0) + ")";
  }
  async function loadPlaces() {
    if (exp.places) return exp.places;
    var res = await fetch(PLACES_URL);
    if (!res.ok) throw new Error("HTTP " + res.status);
    exp.places = (await res.text()).split("\n").filter(function (l) { return l && l[0] !== "#"; }).map(function (l) {
      var a = l.split("\t"); return { name: a[0], st: a[1], lat: +a[2], lon: +a[3], pop: +a[4] };
    });
    return exp.places;
  }
  function mercY(lat) { var r = Math.max(-85, Math.min(85, lat)) * Math.PI / 180; return Math.log(Math.tan(Math.PI / 4 + r / 2)); }
  function wrapText(ctx, text, x, y, maxW, lh) {
    var words = text.split(" "), line = "";
    words.forEach(function (w) { var t = line ? line + " " + w : w; if (ctx.measureText(t).width > maxW && line) { ctx.fillText(line, x, y); y += lh; line = w; } else line = t; });
    if (line) { ctx.fillText(line, x, y); y += lh; }
    return y;
  }

  async function exportGraphic() {
    if (exp.busy) return;
    var f = state.frames[state.idx];
    if (!f || !f.reg) { setExpNote("No frame loaded yet.", true); return; }
    var lead = view.lead, vals = leadValues(f.reg, lead);
    if (!vals) { setExpNote("This step has no projection yet.", true); return; }
    exp.busy = true; lockMap(true);
    try {
      setExpNote("Drawing graphic…");
      await fontsReady();
      var atlas = null, places = null;
      try { atlas = await loadAtlas(); } catch (e) { atlas = null; }
      try { places = await loadPlaces(); } catch (e) { places = null; }
      var T = THEMES[exp.theme], S = +$("#gfxSize").value || 1, W = 1920, H = 1080;
      var cv = document.createElement("canvas"); cv.width = W * S; cv.height = H * S;
      var ctx = cv.getContext("2d"); ctx.scale(S, S);
      ctx.fillStyle = T.bg; ctx.fillRect(0, 0, W, H);

      // ---- projection: current map view, Web Mercator, fitted to the panel ----
      var P = { x: 48, y: 184, w: 1336, h: 848 };
      var b = map.getBounds(), x0 = b.getWest() * Math.PI / 180, x1 = b.getEast() * Math.PI / 180, y0 = mercY(b.getSouth()), y1 = mercY(b.getNorth());
      var k = Math.min(P.w / (x1 - x0), P.h / (y1 - y0)), cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
      var proj = function (lat, lon) { return [P.x + P.w / 2 + (lon * Math.PI / 180 - cx) * k, P.y + P.h / 2 - (mercY(lat) - cy) * k]; };
      var spanLon = (P.w / k) * 180 / Math.PI, lonW = cx * 180 / Math.PI - spanLon / 2, lonE = lonW + spanLon;
      var latS = Math.atan(Math.sinh(cy - P.h / 2 / k)) * 180 / Math.PI, latN = Math.atan(Math.sinh(cy + P.h / 2 / k)) * 180 / Math.PI;

      // ---- panel ----
      ctx.save(); rrect(ctx, P.x, P.y, P.w, P.h, 14); ctx.fillStyle = T.panel; ctx.fill(); ctx.clip();
      var step = spanLon > 24 ? 5 : spanLon > 6 ? 2 : spanLon > 2.5 ? 1 : 0.5;
      ctx.strokeStyle = T.grid; ctx.lineWidth = 1; ctx.beginPath();
      for (var gl = Math.ceil(lonW / step) * step; gl <= lonE; gl += step) { var a1 = proj(latS, gl), a2 = proj(latN, gl); ctx.moveTo(a1[0], a1[1]); ctx.lineTo(a2[0], a2[1]); }
      for (var gt = Math.ceil(latS / step) * step; gt <= latN; gt += step) { var b1 = proj(gt, lonW), b2 = proj(gt, lonE); ctx.moveTo(b1[0], b1[1]); ctx.lineTo(b2[0], b2[1]); }
      ctx.stroke();

      // contours
      var LV = levels(), every5 = view.mode === "every5", reg = f.reg;
      var cs = d3.contours().size([reg.W, reg.H]).thresholds(LV)(vals);
      var toXY = function (pt) { return proj(reg.north + pt[1] * reg.dLat, reg.west + pt[0] * reg.dLon); };
      var trace = function (mp) { mp.coordinates.forEach(function (poly) { poly.forEach(function (ring) { ring.forEach(function (pt, i) { var q = toXY(pt); if (i) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]); }); ctx.closePath(); }); }); };
      if (showFill()) cs.forEach(function (c, i) {
        if (!c.coordinates.length) return;
        ctx.beginPath(); trace(c); if (cs[i + 1]) trace(cs[i + 1]);
        ctx.globalAlpha = T.fill; ctx.fillStyle = levelColor(LV[i]); ctx.fill("evenodd"); ctx.globalAlpha = 1;
      });
      // boundaries over the shading
      var geoLine = function (g, color, width) {
        if (!g) return;
        ctx.beginPath();
        (g.type === "MultiLineString" ? g.coordinates : [g.coordinates]).forEach(function (line) {
          var prev = null;
          line.forEach(function (c) { if (c[0] < lonW - 3 || c[0] > lonE + 3 || c[1] < latS - 3 || c[1] > latN + 3) { prev = null; return; }
            var q = proj(c[1], c[0]); if (prev) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]); prev = q; });
        });
        ctx.strokeStyle = color; ctx.lineWidth = width; ctx.lineJoin = "round"; ctx.stroke();
      };
      if (atlas) {
        geoLine(atlas.counties, T.county, spanLon < 9 ? 0.9 : spanLon < 20 ? 0.6 : 0.4);
        geoLine(atlas.states, T.state, 1.4);
        geoLine(atlas.nation, T.coast, 1.6);
      }
      if (showLines()) cs.forEach(function (c, i) {
        if (!c.coordinates.length) return;
        var v = LV[i], minor = every5 && Math.round(v * 100) % 10 !== 0;
        ctx.beginPath(); trace(c);
        ctx.setLineDash(minor ? [6, 5] : []); ctx.lineWidth = (minor ? 1.3 : v >= 0.55 ? 2.8 : 2) + (showFill() ? 0 : 0.6); ctx.strokeStyle = levelColor(v); ctx.stroke(); ctx.setLineDash([]);
      });
      // contour labels
      var placed = [];
      var labels = [];
      cs.forEach(function (c, i) {
        var v = LV[i], pct = Math.round(v * 100), minor = every5 && pct % 10 !== 0, ang = (-30 + i * 47) * Math.PI / 180, ux = Math.cos(ang), uy = Math.sin(ang);
        c.coordinates.forEach(function (poly) {
          var ring = poly[0]; if (!ring || ring.length < 8) return;
          var mx = 0, my = 0; ring.forEach(function (p) { mx += p[0]; my += p[1]; }); mx /= ring.length; my /= ring.length;
          var best = ring[0], bs = -Infinity; ring.forEach(function (p) { var s2 = (p[0] - mx) * ux + (p[1] - my) * uy; if (s2 > bs) { bs = s2; best = p; } });
          labels.push({ q: toXY(best), pct: pct, minor: minor, color: levelColor(v), level: i, size: ring.length });
        });
      });
      labels.sort(function (a, b2) { return (a.minor - b2.minor) || b2.level - a.level || b2.size - a.size; });
      var boxes = [], chips = [];        // occupied rectangles [x0, y0, x1, y1], shared by contour labels and city names
      var hits = function (r, pad) { return boxes.some(function (q) { return r[0] < q[2] + pad && r[2] > q[0] - pad && r[1] < q[3] + pad && r[3] > q[1] - pad; }); };
      if (showLines()) labels.forEach(function (l) {
        var x = l.q[0], y = l.q[1];
        if (x < P.x + 34 || x > P.x + P.w - 34 || y < P.y + 18 || y > P.y + P.h - 18) return;
        if (placed.some(function (p) { return Math.hypot(p[0] - x, p[1] - y) < 58; })) return;
        placed.push([x, y]);
        ctx.font = (l.minor ? "400 " : "600 ") + "15px " + FONT_MONO;
        var tw = ctx.measureText(l.pct + "%").width + 12;
        boxes.push([x - tw / 2, y - 11, x + tw / 2, y + 11]); chips.push({ l: l, x: x, y: y, tw: tw });
      });
      // reserve the point's label before cities so they don't cover it
      var probeLbl = null;
      if (probe.lat !== null) {
        var pp = proj(probe.lat, probe.lon), pv = sampleReg(reg, probe.lat, probe.lon, lead);
        if (pp[0] > P.x && pp[0] < P.x + P.w && pp[1] > P.y && pp[1] < P.y + P.h) {
          ctx.font = "700 17px " + FONT_UI;
          var ptxt = probe.name + (pv === pv ? "  " + Math.round(pv * 100) + "%" : ""), pw = ctx.measureText(ptxt).width;
          probeLbl = { x: pp[0], y: pp[1], txt: ptxt };
          boxes.push([pp[0] - 9, pp[1] - 13, pp[0] + 14 + pw, pp[1] + 10]);
        }
      }
      // city names: biggest first, each tried right / left / above / below its dot, kept only where it doesn't collide
      var cityCount = 0;
      if (places) {
        var maxN = Math.max(12, Math.min(60, Math.round(P.w * P.h / 22000))), dots = [], cand = [];
        for (var pi = 0; pi < places.length && cand.length < 2500; pi++) {
          var pl = places[pi];
          if (pl.lat < latS || pl.lat > latN || pl.lon < lonW || pl.lon > lonE) continue;
          var cq = proj(pl.lat, pl.lon);
          if (cq[0] < P.x + 14 || cq[0] > P.x + P.w - 14 || cq[1] < P.y + 14 || cq[1] > P.y + P.h - 40) continue;
          cand.push({ p: pl, x: cq[0], y: cq[1] });
        }
        var big = cand.length ? cand[0].p.pop : 0;
        cand.forEach(function (c) {
          if (cityCount >= maxN) return;
          if (dots.some(function (d) { return Math.hypot(d[0] - c.x, d[1] - c.y) < 11; })) return;
          var major = cityCount < 6 || c.p.pop >= Math.max(100000, big * 0.25), fs = major ? 17 : 14;
          ctx.font = (major ? "600 " : "500 ") + fs + "px " + FONT_UI;
          var w = ctx.measureText(c.p.name).width, h = fs * 0.8, dot = [c.x - 3, c.y - 3, c.x + 3, c.y + 3];
          var opts = [[c.x + 8, c.y - h / 2 - 1], [c.x - 8 - w, c.y - h / 2 - 1], [c.x + 6, c.y - 7 - h], [c.x + 6, c.y + 6],
            [c.x - 6 - w, c.y - 7 - h], [c.x - 6 - w, c.y + 6], [c.x - w / 2, c.y - 9 - h], [c.x - w / 2, c.y + 8]];
          if (hits(dot, 1)) return;
          for (var oi = 0; oi < opts.length; oi++) {
            var bx = opts[oi][0], by = opts[oi][1], r = [bx - 2, by - 3, bx + w + 2, by + h + 3];
            if (r[0] < P.x + 6 || r[2] > P.x + P.w - 6 || r[1] < P.y + 6 || r[3] > P.y + P.h - 34 || hits(r, 3)) continue;
            boxes.push(r, dot); dots.push([c.x, c.y]);
            ctx.beginPath(); ctx.arc(c.x, c.y, major ? 3.6 : 2.8, 0, 7); ctx.fillStyle = T.ink; ctx.fill();
            ctx.lineWidth = 1.5; ctx.strokeStyle = T.panel; ctx.stroke();
            ctx.textAlign = "left"; ctx.textBaseline = "alphabetic"; ctx.lineJoin = "round";
            ctx.lineWidth = 4; ctx.strokeStyle = T.panel; ctx.strokeText(c.p.name, bx, by + h);
            ctx.fillStyle = major ? T.ink : T.cityInk; ctx.fillText(c.p.name, bx, by + h);
            cityCount++;
            break;
          }
        });
      }
      ctx.textAlign = "center"; ctx.textBaseline = "middle";
      chips.forEach(function (c) {
        var l = c.l, x = c.x, y = c.y, tw = c.tw;
        ctx.font = (l.minor ? "400 " : "600 ") + "15px " + FONT_MONO;
        rrect(ctx, x - tw / 2, y - 11, tw, 22, 4); ctx.fillStyle = T.chip; ctx.fill();
        ctx.setLineDash(l.minor ? [3, 2] : []); ctx.lineWidth = 1.5; ctx.strokeStyle = l.color; ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = T.labelInk || l.color; ctx.fillText(l.pct + "%", x, y + 1);
      });
      // point
      if (probeLbl) {
        ctx.beginPath(); ctx.arc(probeLbl.x, probeLbl.y, 7, 0, 7); ctx.fillStyle = T.accent; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = T.panel; ctx.stroke();
        ctx.font = "700 17px " + FONT_UI; ctx.textAlign = "left"; ctx.textBaseline = "middle"; ctx.lineWidth = 4; ctx.strokeStyle = T.panel;
        ctx.strokeText(probeLbl.txt, probeLbl.x + 13, probeLbl.y); ctx.fillStyle = T.ink; ctx.fillText(probeLbl.txt, probeLbl.x + 13, probeLbl.y);
      }
      // graticule labels and scale bar
      ctx.font = "12px " + FONT_MONO; ctx.fillStyle = T.muted; ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
      for (var gl2 = Math.ceil(lonW / step) * step; gl2 <= lonE; gl2 += step) { var ql = proj(latS, gl2); if (ql[0] > P.x + 40 && ql[0] < P.x + P.w - 60) ctx.fillText(Math.abs(gl2) + "°" + (gl2 < 0 ? "W" : "E"), ql[0] + 4, P.y + P.h - 10); }
      for (var gt2 = Math.ceil(latS / step) * step; gt2 <= latN; gt2 += step) { var qt = proj(gt2, lonW); if (qt[1] > P.y + 30 && qt[1] < P.y + P.h - 30) ctx.fillText(Math.abs(gt2) + "°" + (gt2 < 0 ? "S" : "N"), P.x + 10, qt[1] - 4); }
      var midLat = (latS + latN) / 2, kmPerPx = 6371 * Math.cos(midLat * Math.PI / 180) / k;
      var nice = [5, 10, 25, 50, 100, 200, 250, 500, 1000].filter(function (n) { return n / kmPerPx <= 190; }).pop() || 5, bw = nice / kmPerPx;
      var sx = P.x + P.w - 30 - bw, sy = P.y + P.h - 30;
      ctx.strokeStyle = T.ink; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(sx, sy - 6); ctx.lineTo(sx, sy); ctx.lineTo(sx + bw, sy); ctx.lineTo(sx + bw, sy - 6); ctx.stroke();
      ctx.fillStyle = T.ink; ctx.textAlign = "center"; ctx.font = "600 13px " + FONT_MONO; ctx.fillText(nice + " km", sx + bw / 2, sy - 9);
      ctx.restore();
      rrect(ctx, P.x, P.y, P.w, P.h, 14); ctx.strokeStyle = T.edge; ctx.lineWidth = 1.5; ctx.stroke();

      // ---- header ----
      var title = ($("#gfxTitle").value || "").trim() || "Flood Likelihood";
      var valid = new Date(f.t + lead * 60e3);
      ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
      ctx.fillStyle = T.accent; ctx.font = "600 17px " + FONT_MONO; ctx.fillText("FLASHRISK · EXPERIMENTAL FLASH FLOOD GUIDANCE", 50, 66);
      ctx.fillStyle = T.ink; ctx.font = "700 58px " + FONT_UI; ctx.fillText(title, 46, 124);
      var dayTxt = valid.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric", year: "numeric", timeZone: "UTC" });
      var localTxt = valid.toLocaleTimeString([], { hour: "numeric", minute: "2-digit", timeZoneName: "short" });
      ctx.fillStyle = T.muted; ctx.font = "500 24px " + FONT_UI;
      ctx.fillText((lead ? "+" + lead + " min projection · valid " : "Valid ") + zTime(valid) + " " + dayTxt + " (" + localTxt + ")" + (lead ? " · made " + zTime(new Date(f.t)) : ""), 48, 162);

      // ---- right column ----
      var R = { x: 1428, w: 444 }, y = 214;
      var peak = 0;
      for (var j = 0; j < reg.H; j++) { var la = reg.north + (j + 0.5) * reg.dLat; if (la < latS || la > latN) continue;
        for (var i2 = 0; i2 < reg.W; i2++) { var lo = reg.west + (i2 + 0.5) * reg.dLon; if (lo < lonW || lo > lonE) continue; var vv = vals[j * reg.W + i2]; if (vv > peak) peak = vv; } }
      var head = function (t) { ctx.fillStyle = T.muted; ctx.font = "600 15px " + FONT_MONO; ctx.textAlign = "left"; ctx.fillText(t, R.x, y); y += 12; };
      head("PEAK IN VIEW");
      ctx.fillStyle = peak >= 0.05 ? (exp.theme === "light" ? shade(levelColor(peak), 0.62) : levelColor(peak)) : T.muted; ctx.font = "700 76px " + FONT_UI; ctx.fillText(Math.round(peak * 100) + "%", R.x - 3, y + 62);
      y += 100;
      head("LIKELIHOOD");
      y += 8;
      var rows = LV.length, rh = every5 ? 19 : 34, swW = every5 ? 46 : 60;
      LV.slice().reverse().forEach(function (v, n) {
        var ry = y + n * rh, p2 = Math.round(v * 100);
        ctx.globalAlpha = T.fill + 0.2; ctx.fillStyle = levelColor(v); rrect(ctx, R.x, ry, swW, rh - 6, 3); ctx.fill(); ctx.globalAlpha = 1;
        ctx.strokeStyle = levelColor(v); ctx.lineWidth = 1.5; ctx.setLineDash(every5 && p2 % 10 ? [4, 3] : []); ctx.stroke(); ctx.setLineDash([]);
        if (!every5 || p2 % 10 === 0 || p2 === 5 || p2 === 95) {
          ctx.fillStyle = T.ink; ctx.font = (every5 ? "500 14px " : "600 17px ") + FONT_MONO; ctx.fillText("≥ " + p2 + "%", R.x + swW + 14, ry + (rh - 6) / 2 + (every5 ? 5 : 6));
        }
      });
      y += rows * rh + 26;
      var mo = viewMotion(f.reg, { south: latS, north: latN, west: lonW, east: lonE });
      if (mo) {
        head("STORM MOTION"); y += 10;
        var ax = R.x + 22, ay = y + 20, an = (mo.toward - 90) * Math.PI / 180;
        ctx.save(); ctx.translate(ax, ay); ctx.rotate(an); ctx.fillStyle = T.ink;
        ctx.beginPath(); ctx.moveTo(18, 0); ctx.lineTo(-10, -10); ctx.lineTo(-4, 0); ctx.lineTo(-10, 10); ctx.closePath(); ctx.fill(); ctx.restore();
        ctx.fillStyle = T.ink; ctx.font = "600 20px " + FONT_UI; ctx.fillText("Toward " + C.compass(mo.toward) + " (" + Math.round(mo.toward) + "°) at " + Math.round(mo.mph) + " mph", R.x + 52, ay + 7);
        y += 72;
      }
      head("METHOD"); y += 12;
      ctx.fillStyle = T.muted; ctx.font = "400 16px " + FONT_UI;
      y = wrapText(ctx, "Logistic blend of CREST max unit streamflow, mean 1/3/6 h QPE÷FFG and CREST soil saturation (MRMS FLASH), on a 0.05° grid smoothed over ~25 km." +
        (lead ? " Projection: MRMS rain rate carried along the measured storm motion for the next " + lead + " min." : ""), R.x, y + 6, R.w, 21);
      // footer
      ctx.fillStyle = T.muted; ctx.font = "400 14px " + FONT_MONO; ctx.textAlign = "left";
      var credits = ["Data: NOAA/NSSL MRMS FLASH"];
      if (atlas) credits.push("Boundaries: US Census (us-atlas)");
      if (places) credits.push("Places: GeoNames (CC BY 4.0)");
      credits.forEach(function (c, n) { ctx.fillText(c, R.x, 1006 - (credits.length - 1 - n) * 22); });
      ctx.fillStyle = T.ink; ctx.font = "600 14px " + FONT_MONO;
      ctx.fillText("Experimental · not an official NWS product", R.x, 1028);

      var blob = await new Promise(function (res) { cv.toBlob(res, "image/png"); });
      download(blob, "flashrisk_contours_" + fileStamp(valid.getTime()) + (lead ? "_plus" + lead + "min" : "") + "_" + exp.theme + ".png");
      var miss = [];
      if (!atlas) miss.push("state and county lines");
      if (!places) miss.push("city names (open the page through serve.py)");
      setExpNote("Saved graphic " + W * S + "×" + H * S + " with " + cityCount + " city names." + (miss.length ? " Couldn't load " + miss.join(" or ") + ", so they're left out." : ""));
    } catch (e) { setExpNote("Graphic failed: " + e.message, true); }
    finally { lockMap(false); exp.busy = false; }
  }

  function segPick(id, attr, cb) {
    document.querySelectorAll("#" + id + " button").forEach(function (b) {
      b.addEventListener("click", function () {
        document.querySelectorAll("#" + id + " button").forEach(function (o) { o.setAttribute("aria-pressed", o === b ? "true" : "false"); });
        cb(b.dataset[attr]);
      });
    });
  }
  segPick("expFmt", "fmt", function (v) { exp.fmt = v; $("#expLoopTxt").textContent = v === "gif" ? "Export loop GIF" : "Export loop video"; });
  segPick("gfxTheme", "theme", function (v) { exp.theme = v; });
  $("#expLoop").addEventListener("click", exportLoop);
  $("#expPng").addEventListener("click", exportGraphic);

  setInterval(tick, 1000);
  load(); loadSites();
  window.FlashRisk = { reload: load, state: state, map: map };   // console helper: FlashRisk.reload()
})();
