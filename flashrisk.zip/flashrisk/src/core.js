/* FlashRisk core: grid containers, MRMS GRIB2 decoding, and the blend model.
   Pure functions only, so the same file runs in the browser and in node tests. */
(function (root) {
  "use strict";

  // ---------- Grid: a regular lat/lon raster with lazy value access ----------
  // lat0/lon0 = centre of cell (0,0); dlat/dlon signed steps; get(k) -> value or NaN
  function Grid(o) {
    this.ni = o.ni; this.nj = o.nj;
    this.lat0 = o.lat0; this.lon0 = o.lon0;
    this.dlat = o.dlat; this.dlon = o.dlon;
    this.get = o.get;
    this.meta = o.meta || {};
    var latA = this.lat0, latB = this.lat0 + this.dlat * (this.nj - 1);
    var lonA = this.lon0, lonB = this.lon0 + this.dlon * (this.ni - 1);
    this.south = Math.min(latA, latB) - Math.abs(this.dlat) / 2;
    this.north = Math.max(latA, latB) + Math.abs(this.dlat) / 2;
    this.west = Math.min(lonA, lonB) - Math.abs(this.dlon) / 2;
    this.east = Math.max(lonA, lonB) + Math.abs(this.dlon) / 2;
  }
  Grid.prototype.contains = function (lat, lon) {
    return lat >= this.south && lat <= this.north && lon >= this.west && lon <= this.east;
  };
  Grid.prototype.at = function (lat, lon) {
    var i = Math.round((lon - this.lon0) / this.dlon);
    var j = Math.round((lat - this.lat0) / this.dlat);
    if (i < 0 || j < 0 || i >= this.ni || j >= this.nj) return NaN;
    return this.get(j * this.ni + i);
  };
  // Max over a box of half-size (hLat, hLon) degrees; samples at most 5x5 cells.
  Grid.prototype.maxIn = function (lat, lon, hLat, hLon) {
    var ci = Math.abs(hLon / this.dlon), cj = Math.abs(hLat / this.dlat);
    if (ci < 0.75 && cj < 0.75) return this.at(lat, lon);
    var ni = Math.min(5, Math.max(1, Math.ceil(ci * 2))), nj = Math.min(5, Math.max(1, Math.ceil(cj * 2)));
    var best = NaN;
    for (var a = 0; a < nj; a++) {
      var la = lat - hLat + (2 * hLat) * (nj === 1 ? 0.5 : a / (nj - 1));
      for (var b = 0; b < ni; b++) {
        var lo = lon - hLon + (2 * hLon) * (ni === 1 ? 0.5 : b / (ni - 1));
        var v = this.at(la, lo);
        if (v === v && !(v <= best)) best = v;
      }
    }
    return best;
  };
  Grid.prototype.bilinear = function (lat, lon) {
    var fx = (lon - this.lon0) / this.dlon, fy = (lat - this.lat0) / this.dlat;
    var i = Math.floor(fx), j = Math.floor(fy);
    i = Math.max(0, Math.min(this.ni - 2, i)); j = Math.max(0, Math.min(this.nj - 2, j));
    var tx = Math.max(0, Math.min(1, fx - i)), ty = Math.max(0, Math.min(1, fy - j));
    var g = this.get.bind(this), n = this.ni;
    var v00 = g(j * n + i), v10 = g(j * n + i + 1), v01 = g((j + 1) * n + i), v11 = g((j + 1) * n + i + 1);
    var vals = [[v00, (1 - tx) * (1 - ty)], [v10, tx * (1 - ty)], [v01, (1 - tx) * ty], [v11, tx * ty]];
    var s = 0, w = 0;
    for (var k = 0; k < 4; k++) if (vals[k][0] === vals[k][0]) { s += vals[k][0] * vals[k][1]; w += vals[k][1]; }
    return w > 0 ? s / w : NaN;
  };

  // Float32 raster covering a bbox, rows north->south (ArcGIS exportImage layout)
  function gridFromArray(arr, W, H, bbox, noData, meta) {
    var dlon = (bbox.e - bbox.w) / W, dlat = (bbox.n - bbox.s) / H;
    return new Grid({
      ni: W, nj: H, lat0: bbox.n - dlat / 2, lon0: bbox.w + dlon / 2, dlat: -dlat, dlon: dlon,
      get: function (k) { var v = arr[k]; return (v === noData || v !== v || v < -1e30 || v > 1e30) ? NaN : v; },
      meta: meta
    });
  }

  // ---------- GRIB2 (MRMS) ----------
  function u32(u, o) { return ((u[o] << 24) >>> 0) + (u[o + 1] << 16) + (u[o + 2] << 8) + u[o + 3]; }
  function s32(u, o) { var v = u32(u, o); return (v & 0x80000000) ? -(v & 0x7fffffff) : v; }
  function u16(u, o) { return (u[o] << 8) | u[o + 1]; }
  function s16(u, o) { var v = u16(u, o); return (v & 0x8000) ? -(v & 0x7fff) : v; }
  function f32(u, o) { return new DataView(u.buffer, u.byteOffset + o, 4).getFloat32(0, false); }

  // Decode the first message of a GRIB2 file (MRMS files hold one field).
  // Supports grid template 3.0 and data templates 5.0 (simple) and 5.41 (PNG).
  function parseGrib2(u, UPNGlib) {
    if (!(u[0] === 71 && u[1] === 82 && u[2] === 73 && u[3] === 66)) throw new Error("Not a GRIB file (missing 'GRIB' header).");
    if (u[7] !== 2) throw new Error("Only GRIB edition 2 is supported (found edition " + u[7] + ").");
    var discipline = u[6];
    var off = 16, s = {}, refTime = null;
    while (off < u.length - 4) {
      if (u[off] === 55 && u[off + 1] === 55 && u[off + 2] === 55 && u[off + 3] === 55) break; // "7777"
      var len = u32(u, off), num = u[off + 4];
      if (!len || off + len > u.length) throw new Error("Corrupt GRIB2 section at byte " + off + ".");
      if (!s[num]) s[num] = { off: off, len: len };
      off += len;
    }
    if (s[1]) {
      var o1 = s[1].off;
      refTime = new Date(Date.UTC(u16(u, o1 + 12), u[o1 + 14] - 1, u[o1 + 15], u[o1 + 16], u[o1 + 17], u[o1 + 18]));
    }
    if (!s[3] || !s[5] || !s[7]) throw new Error("GRIB2 message is missing grid, packing, or data sections.");
    var o3 = s[3].off, tpl3 = u16(u, o3 + 12);
    if (tpl3 !== 0) throw new Error("Unsupported grid template 3." + tpl3 + " (expected lat/lon 3.0).");
    var ni = u32(u, o3 + 30), nj = u32(u, o3 + 34);
    var la1 = s32(u, o3 + 46) / 1e6, lo1 = s32(u, o3 + 50) / 1e6;
    var la2 = s32(u, o3 + 55) / 1e6, lo2 = s32(u, o3 + 59) / 1e6;
    if (lo1 > 180) lo1 -= 360; if (lo2 > 180) lo2 -= 360;
    var dlat = nj > 1 ? (la2 - la1) / (nj - 1) : 0.01, dlon = ni > 1 ? (lo2 - lo1) / (ni - 1) : 0.01;

    var cat = null, par = null;
    if (s[4]) { cat = u[s[4].off + 9]; par = u[s[4].off + 10]; }

    var o5 = s[5].off, tpl5 = u16(u, o5 + 9);
    var R = f32(u, o5 + 11), E = s16(u, o5 + 15), D = s16(u, o5 + 17), nbits = u[o5 + 19];
    var mul = Math.pow(2, E) / Math.pow(10, D), add = R / Math.pow(10, D);
    if (s[6] && u[s[6].off + 5] !== 255) throw new Error("GRIB2 bitmaps are not supported.");

    var o7 = s[7].off + 5, dataLen = s[7].len - 5, get;
    if (nbits === 0) {
      get = function () { return add; };
    } else if (tpl5 === 41) {
      var Upng = UPNGlib || root.UPNG;
      if (!Upng) throw new Error("PNG decoder not loaded.");
      var png = Upng.decode(u.slice(o7, o7 + dataLen).buffer);
      if (png.width !== ni || png.height !== nj) throw new Error("PNG size does not match grid size.");
      var d = new Uint8Array(png.data), bpp;
      if (png.ctype === 0) bpp = png.depth / 8; else if (png.ctype === 2) bpp = 3 * png.depth / 8; else if (png.ctype === 6) bpp = 4 * png.depth / 8;
      else throw new Error("Unsupported PNG colour type " + png.ctype + ".");
      if (bpp === 1) get = function (k) { return add + d[k] * mul; };
      else if (bpp === 2) get = function (k) { return add + ((d[2 * k] << 8) | d[2 * k + 1]) * mul; };
      else if (bpp === 3) get = function (k) { var p = 3 * k; return add + ((d[p] << 16) | (d[p + 1] << 8) | d[p + 2]) * mul; };
      else if (bpp === 4) get = function (k) { var p = 4 * k; return add + (((d[p] << 24) >>> 0) + (d[p + 1] << 16) + (d[p + 2] << 8) + d[p + 3]) * mul; };
      else throw new Error("Unsupported PNG bit depth.");
    } else if (tpl5 === 0) {
      var n = ni * nj, vals = new Float32Array(n), bitPos = o7 * 8;
      for (var k = 0; k < n; k++) {
        var x = 0;
        for (var b = 0; b < nbits; b++, bitPos++) x = x * 2 + ((u[bitPos >> 3] >> (7 - (bitPos & 7))) & 1);
        vals[k] = add + x * mul;
      }
      get = function (k) { return vals[k]; };
    } else {
      throw new Error("Unsupported packing template 5." + tpl5 + " (supported: 5.0 simple, 5.41 PNG).");
    }
    // MRMS uses -999 (missing) and -3 (no coverage); both become NaN
    var getClean = function (k) { var v = get(k); return v < -0.5 ? NaN : v; };
    return new Grid({
      ni: ni, nj: nj, lat0: la1, lon0: lo1, dlat: dlat, dlon: dlon, get: getClean,
      meta: { refTime: refTime, discipline: discipline, category: cat, parameter: par, packing: tpl5, nbits: nbits }
    });
  }

  // ---------- The equation ----------
  // >>> FLOOD PERCENT EQUATION <<<
  //   P = 1 / (1 + e^(-z))
  //   z = wQ*kQ*ln(Q/Q50) + wR*kR*(Rbar - R50) + kS*(S - S50)
  // Q    : CREST max unit streamflow (m3 s-1 km-2)
  // Rbar : mean of the 1, 3 and 6 h QPE/FFG ratios (fraction: 1.0 = rain equals guidance)
  // S    : CREST max soil saturation (fraction 0-1)
  // When Q or Rbar is missing, the other carries the full flow/rain weight (wQ+wR);
  // the soil term is added only when S is available.
  // Anchors: Q50 and R50 from the NWS Memphis FLASH study (onset near Q = 2.0, QPE/FFG = 100%).
  var EQ = { Q50: 2.0, kQ: 2.2, wQ: 0.6, R50: 1.0, kR: 4.5, wR: 0.4, S50: 0.70, kS: 3.0 };
  function num(v) { return typeof v === "number" && v === v; }
  function floodTerms(q, rAvg, sat) {
    var hasQ = num(q), hasR = num(rAvg), hasS = num(sat);
    if (!hasQ && !hasR) return null;
    var zQ = hasQ ? EQ.kQ * (Math.log(Math.max(q, 0.01)) - Math.log(EQ.Q50)) : NaN;
    var zR = hasR ? EQ.kR * (rAvg - EQ.R50) : NaN;
    var zS = hasS ? EQ.kS * (sat - EQ.S50) : NaN;
    var w = (hasQ ? EQ.wQ : 0) + (hasR ? EQ.wR : 0);
    var z = ((hasQ ? EQ.wQ * zQ : 0) + (hasR ? EQ.wR * zR : 0)) * ((EQ.wQ + EQ.wR) / w) + (hasS ? zS : 0);
    return { z: z, zQ: zQ, zR: zR, zS: zS, p: 1 / (1 + Math.exp(-z)) };
  }
  function floodPercent(q, rAvg, sat) {
    var t = floodTerms(q, rAvg, sat);
    return t ? t.p : NaN;
  }

  // Mean of the available 1/3/6 h ratios at one place.
  function meanRatio(r1, r3, r6) {
    var s = 0, n = 0;
    if (r1 === r1) { s += r1; n++; }
    if (r3 === r3) { s += r3; n++; }
    if (r6 === r6) { s += r6; n++; }
    return n ? s / n : NaN;
  }

  // Separable box blur in place (radius r cells), NaN treated as 0. Gives the "regional" look.
  function boxBlur(a, W, H, r) {
    if (r < 1) return a;
    var tmp = new Float32Array(W * H), x, y, k, s, n;
    for (y = 0; y < H; y++) for (x = 0; x < W; x++) {
      s = 0; n = 0;
      for (k = -r; k <= r; k++) { var xx = x + k; if (xx >= 0 && xx < W) { s += a[y * W + xx] || 0; n++; } }
      tmp[y * W + x] = s / n;
    }
    for (x = 0; x < W; x++) for (y = 0; y < H; y++) {
      s = 0; n = 0;
      for (k = -r; k <= r; k++) { var yy = y + k; if (yy >= 0 && yy < H) { s += tmp[yy * W + x]; n++; } }
      a[y * W + x] = s / n;
    }
    return a;
  }

  // ---------- Storm motion from two MRMS rain-rate fields ----------
  // Arrays are regional grids (W x H, row 0 = north), rates in mm/h.
  var NOWCAST = {
    dtMin: 20,      // minutes between the two rain-rate fields used for motion
    tile: 24,       // motion tile size, cells (~120 km at 5 km cells)
    search: 6,      // max displacement searched, cells per dtMin (~90 km/h)
    minRate: 1.0    // mm/h counted as raining for motion
  };

  function bilinear(a, W, H, x, y) {      // x, y in cell coordinates (cell centre = integer)
    if (x < 0 || y < 0 || x > W - 1 || y > H - 1) return 0;
    var i = Math.floor(x), j = Math.floor(y), tx = x - i, ty = y - j, i1 = Math.min(i + 1, W - 1), j1 = Math.min(j + 1, H - 1);
    var v00 = a[j * W + i] || 0, v10 = a[j * W + i1] || 0, v01 = a[j1 * W + i] || 0, v11 = a[j1 * W + i1] || 0;
    return v00 * (1 - tx) * (1 - ty) + v10 * tx * (1 - ty) + v01 * (1 - tx) * ty + v11 * tx * ty;
  }

  // Storm motion by tile matching of log rain rate between prev and cur (dtMin apart).
  // Returns {u, v} per-cell arrays: displacement in cells per minute (east +, south +).
  function motionField(prev, cur, W, H, opt) {
    opt = opt || NOWCAST;
    var T = opt.tile, S = opt.search, TW = Math.ceil(W / T), TH = Math.ceil(H / T);
    var tu = new Float32Array(TW * TH), tv = new Float32Array(TW * TH), ok = new Uint8Array(TW * TH), wt = new Float32Array(TW * TH);
    var lc = new Float32Array(W * H), lp = new Float32Array(W * H), k;
    for (k = 0; k < W * H; k++) { lc[k] = Math.log1p(Math.max(0, cur[k] || 0)); lp[k] = Math.log1p(Math.max(0, prev[k] || 0)); }
    var thr = Math.log1p(opt.minRate);
    for (var ty = 0; ty < TH; ty++) for (var tx = 0; tx < TW; tx++) {
      var x0 = tx * T, y0 = ty * T, x1 = Math.min(W, x0 + T), y1 = Math.min(H, y0 + T), wet = 0;
      for (var y = y0; y < y1; y++) for (var x = x0; x < x1; x++) if (lc[y * W + x] > thr) wet++;
      if (wet < 12) continue;
      var best = Infinity, bx = 0, by = 0, cost = {};
      for (var dy = -S; dy <= S; dy++) for (var dx = -S; dx <= S; dx++) {
        var ssd = 0, n = 0;
        for (y = y0; y < y1; y += 2) {          // every other cell: 4x faster, same answer at this scale
          var yp = y - dy; if (yp < 0 || yp >= H) continue;
          for (x = x0; x < x1; x += 2) {
            var xp = x - dx; if (xp < 0 || xp >= W) continue;
            var c = lc[y * W + x], p = lp[yp * W + xp];
            if (c <= thr && p <= thr) continue;
            var d = c - p; ssd += d * d; n++;
          }
        }
        if (n < 4) continue;
        var s2 = ssd / n; cost[dx + "," + dy] = s2;
        if (s2 < best || (s2 === best && dx * dx + dy * dy < bx * bx + by * by)) { best = s2; bx = dx; by = dy; }
      }
      if (best === Infinity) continue;
      var sub = function (a, b, c0) { var den = a - 2 * c0 + b; return den > 1e-9 ? Math.max(-0.5, Math.min(0.5, 0.5 * (a - b) / den)) : 0; };
      var fx = bx + (cost[(bx - 1) + "," + by] !== undefined && cost[(bx + 1) + "," + by] !== undefined ? sub(cost[(bx - 1) + "," + by], cost[(bx + 1) + "," + by], best) : 0);
      var fy = by + (cost[bx + "," + (by - 1)] !== undefined && cost[bx + "," + (by + 1)] !== undefined ? sub(cost[bx + "," + (by - 1)], cost[bx + "," + (by + 1)], best) : 0);
      tu[ty * TW + tx] = fx / opt.dtMin; tv[ty * TW + tx] = fy / opt.dtMin; ok[ty * TW + tx] = 1; wt[ty * TW + tx] = wet;
    }
    // fill tiles without rain from the mean of tiles that have it, then smooth across neighbours
    var su = 0, sv = 0, sn = 0;
    for (k = 0; k < TW * TH; k++) if (ok[k]) { su += tu[k]; sv += tv[k]; sn++; }
    var mu = sn ? su / sn : 0, mv = sn ? sv / sn : 0;
    var u2 = new Float32Array(TW * TH), v2 = new Float32Array(TW * TH);
    for (ty = 0; ty < TH; ty++) for (tx = 0; tx < TW; tx++) {
      var au = 0, av = 0, aw = 0;
      for (var oy = -1; oy <= 1; oy++) for (var ox = -1; ox <= 1; ox++) {
        var X = tx + ox, Y = ty + oy; if (X < 0 || Y < 0 || X >= TW || Y >= TH || !ok[Y * TW + X]) continue;
        var w = ox === 0 && oy === 0 ? 2 : 1; au += w * tu[Y * TW + X]; av += w * tv[Y * TW + X]; aw += w;
      }
      u2[ty * TW + tx] = aw ? au / aw : mu; v2[ty * TW + tx] = aw ? av / aw : mv;
    }
    var u = new Float32Array(W * H), v = new Float32Array(W * H);
    for (y = 0; y < H; y++) for (x = 0; x < W; x++) {
      var gx = (x + 0.5) / T - 0.5, gy = (y + 0.5) / T - 0.5;
      u[y * W + x] = bilinear(u2, TW, TH, Math.max(0, Math.min(TW - 1, gx)), Math.max(0, Math.min(TH - 1, gy)));
      v[y * W + x] = bilinear(v2, TW, TH, Math.max(0, Math.min(TW - 1, gx)), Math.max(0, Math.min(TH - 1, gy)));
    }
    // per-tile vectors are kept so motion can be reported for the area being looked at
    return { u: u, v: v, tiles: sn, meanU: mu, meanV: mv, field: { tu: tu, tv: tv, ok: ok, wt: wt, TW: TW, TH: TH, T: T } };
  }

  // Rain-weighted mean motion of the tracked tiles whose centres fall inside a lat/lon box.
  // grid: { north, west, dLat (negative: rows run south), dLon }. Returns compass direction the
  // storms are moving TOWARD (degrees, 0 = north, 90 = east), speed in km/h and mph, or null.
  function motionIn(field, grid, box) {
    if (!field) return null;
    var se = 0, sn = 0, sw = 0, n = 0;
    for (var ty = 0; ty < field.TH; ty++) for (var tx = 0; tx < field.TW; tx++) {
      var k = ty * field.TW + tx; if (!field.ok[k]) continue;
      var lat = grid.north + (ty + 0.5) * field.T * grid.dLat, lon = grid.west + (tx + 0.5) * field.T * grid.dLon;
      if (lat < box.south || lat > box.north || lon < box.west || lon > box.east) continue;
      var kx = 111.32 * grid.dLon * Math.cos(lat * Math.PI / 180), ky = 110.57 * Math.abs(grid.dLat);
      var w = field.wt[k];
      se += w * field.tu[k] * kx * 60;          // cells/min -> km/h toward east
      sn += w * -field.tv[k] * ky * 60;         // rows run south, so north is -v
      sw += w; n++;
    }
    if (!sw) return null;
    var e = se / sw, no = sn / sw, kmh = Math.hypot(e, no);
    return { toward: (Math.atan2(e, no) * 180 / Math.PI + 360) % 360, kmh: kmh, mph: kmh * 0.621371, tiles: n };
  }
  function compass(deg) {
    return ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"][Math.round(((deg % 360) + 360) % 360 / 22.5) % 16];
  }

  // =====================================================================================
  // Fast path used by the background workers: decode a GRIB2 file straight into 0.05° block
  // reductions without building a per-cell accessor (the accessor costs ~1 s per CONUS scan).
  // =====================================================================================

  // Header fields of a single-message GRIB2 file (grid, packing, where the data section sits).
  function grib2Header(u) {
    if (!(u[0] === 71 && u[1] === 82 && u[2] === 73 && u[3] === 66)) throw new Error("Not a GRIB file (missing 'GRIB' header).");
    if (u[7] !== 2) throw new Error("Only GRIB edition 2 is supported (found edition " + u[7] + ").");
    var off = 16, s = {}, refTime = null;
    while (off < u.length - 4) {
      if (u[off] === 55 && u[off + 1] === 55 && u[off + 2] === 55 && u[off + 3] === 55) break;
      var len = u32(u, off), num = u[off + 4];
      if (!len || off + len > u.length) throw new Error("Corrupt GRIB2 section at byte " + off + ".");
      if (!s[num]) s[num] = { off: off, len: len };
      off += len;
    }
    if (s[1]) { var o1 = s[1].off; refTime = Date.UTC(u16(u, o1 + 12), u[o1 + 14] - 1, u[o1 + 15], u[o1 + 16], u[o1 + 17], u[o1 + 18]); }
    if (!s[3] || !s[5] || !s[7]) throw new Error("GRIB2 message is missing grid, packing, or data sections.");
    var o3 = s[3].off;
    if (u16(u, o3 + 12) !== 0) throw new Error("Unsupported grid template 3." + u16(u, o3 + 12) + " (expected lat/lon 3.0).");
    var ni = u32(u, o3 + 30), nj = u32(u, o3 + 34);
    var la1 = s32(u, o3 + 46) / 1e6, lo1 = s32(u, o3 + 50) / 1e6, la2 = s32(u, o3 + 55) / 1e6, lo2 = s32(u, o3 + 59) / 1e6;
    if (lo1 > 180) lo1 -= 360; if (lo2 > 180) lo2 -= 360;
    var o5 = s[5].off, tpl5 = u16(u, o5 + 9);
    var R = f32(u, o5 + 11), E = s16(u, o5 + 15), D = s16(u, o5 + 17), nbits = u[o5 + 19];
    if (s[6] && u[s[6].off + 5] !== 255) throw new Error("GRIB2 bitmaps are not supported.");
    return { ni: ni, nj: nj, lat0: la1, lon0: lo1, dlat: nj > 1 ? (la2 - la1) / (nj - 1) : 0.01, dlon: ni > 1 ? (lo2 - lo1) / (ni - 1) : 0.01,
      tpl5: tpl5, nbits: nbits, mul: Math.pow(2, E) / Math.pow(10, D), add: R / Math.pow(10, D), refTime: refTime,
      data: u.subarray(s[7].off + 5, s[7].off + s[7].len) };
  }

  // PNG (GRIB2 template 5.41): header + concatenated IDAT (zlib stream), then row unfiltering.
  function pngInfo(p) {
    if (!(p[0] === 137 && p[1] === 80 && p[2] === 78 && p[3] === 71)) throw new Error("GRIB2 data section is not a PNG.");
    var off = 8, w = 0, h = 0, depth = 0, ctype = 0, parts = [], total = 0;
    while (off + 8 <= p.length) {
      var len = u32(p, off), type = String.fromCharCode(p[off + 4], p[off + 5], p[off + 6], p[off + 7]);
      if (type === "IHDR") { w = u32(p, off + 8); h = u32(p, off + 12); depth = p[off + 16]; ctype = p[off + 17]; if (p[off + 20]) throw new Error("Interlaced PNG not supported."); }
      else if (type === "IDAT") { parts.push(p.subarray(off + 8, off + 8 + len)); total += len; }
      else if (type === "IEND") break;
      off += 12 + len;
    }
    var chans = ctype === 0 ? 1 : ctype === 2 ? 3 : ctype === 4 ? 2 : ctype === 6 ? 4 : 0;
    if (!chans) throw new Error("Unsupported PNG colour type " + ctype + ".");
    var idat = new Uint8Array(total), q = 0; parts.forEach(function (a) { idat.set(a, q); q += a.length; });
    return { width: w, height: h, depth: depth, bpp: Math.max(1, chans * depth / 8), idat: idat };
  }
  function pngUnfilter(raw, info) {
    var bpp = info.bpp, stride = Math.ceil(info.width * bpp), out = new Uint8Array(stride * info.height), src = 0;
    for (var y = 0; y < info.height; y++) {
      var ft = raw[src++], o = y * stride, up = o - stride, x;
      if (ft === 0) out.set(raw.subarray(src, src + stride), o);
      else if (ft === 1) { for (x = 0; x < stride; x++) out[o + x] = (raw[src + x] + (x >= bpp ? out[o + x - bpp] : 0)) & 255; }
      else if (ft === 2) { for (x = 0; x < stride; x++) out[o + x] = (raw[src + x] + (y ? out[up + x] : 0)) & 255; }
      else if (ft === 3) { for (x = 0; x < stride; x++) out[o + x] = (raw[src + x] + (((x >= bpp ? out[o + x - bpp] : 0) + (y ? out[up + x] : 0)) >> 1)) & 255; }
      else if (ft === 4) {
        for (x = 0; x < stride; x++) {
          var a = x >= bpp ? out[o + x - bpp] : 0, b = y ? out[up + x] : 0, c = x >= bpp && y ? out[up + x - bpp] : 0;
          var pp = a + b - c, pa = Math.abs(pp - a), pb = Math.abs(pp - b), pc = Math.abs(pp - c);
          out[o + x] = (raw[src + x] + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c)) & 255;
        }
      } else throw new Error("Bad PNG filter type " + ft + ".");
      src += stride;
    }
    return out;
  }

  // Regional (block) reductions of one decoded field. want.max: block max over every cell;
  // want.mean: block mean over every other cell. Missing values (< -0.5) are skipped; empty -> NaN.
  // Also returns the field maximum and where it is (for the unit cross-check). bs = cells per block.
  function reduceField(h, pix, want, cell) {
    var ni = h.ni, nj = h.nj, bs = Math.max(1, Math.round(cell / Math.abs(h.dlon)));
    var W = Math.floor(ni / bs), H = Math.floor(nj / bs), n = W * H, add = h.add, mul = h.mul;
    var bpp = h.bpp, mx = want.max ? new Float32Array(n).fill(NaN) : null, sum = want.mean ? new Float32Array(n) : null, cnt = want.mean ? new Uint16Array(n) : null;
    var vmax = -Infinity, kmax = -1, j, i, v, k, row;
    var val = bpp === 2 ? function (q) { return add + ((pix[2 * q] << 8) | pix[2 * q + 1]) * mul; }
      : bpp === 1 ? function (q) { return add + pix[q] * mul; }
      : bpp === 4 ? function (q) { var p = 4 * q; return add + (((pix[p] << 24) >>> 0) + (pix[p + 1] << 16) + (pix[p + 2] << 8) + pix[p + 3]) * mul; }
      : function (q) { var p = 3 * q; return add + ((pix[p] << 16) | (pix[p + 1] << 8) | pix[p + 2]) * mul; };
    if (h.nbits === 0) val = function () { return add; };
    if (h.getter) val = h.getter;            // any other packing: a per-cell accessor (NaN = missing)
    for (j = 0; j < H * bs; j++) {
      var J = (j / bs) | 0, base = J * W, even = !(j & 1);
      row = j * ni;
      if (bpp === 2 && h.nbits && !h.getter) {        // the common MRMS case, inlined
        for (i = 0; i < W * bs; i++) {
          var q2 = 2 * (row + i); v = add + ((pix[q2] << 8) | pix[q2 + 1]) * mul;
          if (v < -0.5) continue;
          k = base + ((i / bs) | 0);
          if (mx && !(v <= mx[k])) mx[k] = v;
          if (sum && even && !(i & 1)) { sum[k] += v; cnt[k]++; }
          if (v > vmax) { vmax = v; kmax = row + i; }
        }
      } else {
        for (i = 0; i < W * bs; i++) {
          v = val(row + i); if (!(v >= -0.5)) continue;
          k = base + ((i / bs) | 0);
          if (mx && !(v <= mx[k])) mx[k] = v;
          if (sum && even && !(i & 1)) { sum[k] += v; cnt[k]++; }
          if (v > vmax) { vmax = v; kmax = row + i; }
        }
      }
    }
    var mean = null;
    if (sum) { mean = new Float32Array(n); for (k = 0; k < n; k++) mean[k] = cnt[k] ? sum[k] / cnt[k] : NaN; }
    var jm = kmax >= 0 ? Math.floor(kmax / ni) : 0;
    return { W: W, H: H, bs: bs, north: h.lat0 - h.dlat / 2, west: h.lon0 - h.dlon / 2, dLat: bs * h.dlat, dLon: bs * h.dlon,
      max: mx, mean: mean, vmax: vmax === -Infinity ? NaN : vmax, vlat: h.lat0 + jm * h.dlat, vlon: h.lon0 + (kmax - jm * ni) * h.dlon, refTime: h.refTime };
  }

  // Nearest-cell resample of a regional array onto another regional geometry (only needed if a
  // product ever arrives on a different grid than CREST; MRMS CONUS products normally match).
  function sameRegion(a, b) { return a.W === b.W && a.H === b.H && Math.abs(a.north - b.north) < 1e-6 && Math.abs(a.west - b.west) < 1e-6; }
  function resampleRegion(arr, from, to) {
    if (!arr || sameRegion(from, to)) return arr;
    var out = new Float32Array(to.W * to.H).fill(NaN);
    for (var J = 0; J < to.H; J++) {
      var lat = to.north + (J + 0.5) * to.dLat, jj = Math.floor((lat - from.north) / from.dLat);
      if (jj < 0 || jj >= from.H) continue;
      for (var I = 0; I < to.W; I++) {
        var ii = Math.floor((to.west + (I + 0.5) * to.dLon - from.west) / from.dLon);
        if (ii >= 0 && ii < from.W) out[J * to.W + I] = arr[jj * from.W + ii];
      }
    }
    return out;
  }

  // Build one frame from regional inputs: the likelihood now, plus storm motion when two rain-rate
  // fields are supplied. In (regional, raw units, NaN = missing): crest (max), r1/r3/r6 (max),
  // sat (mean), optional rate and prev (means). scale: ratio units (0.01 if percent); satScale likewise.
  function zeros0(a) { var o = new Float32Array(a.length); for (var k = 0; k < a.length; k++) o[k] = a[k] === a[k] ? a[k] : 0; return o; }
  function assembleFrame(I) {
    var W = I.W, H = I.H, n = W * H, sc = I.scale, ss = I.satScale, blur = I.blur, k;
    var values = new Float32Array(n), R = [I.r1, I.r3, I.r6];
    for (k = 0; k < n; k++) {
      var sv = I.sat[k], s = sv === sv ? Math.min(1, sv * ss) : NaN;
      var p = floodPercent(I.crest[k], meanRatio(R[0][k] * sc, R[1][k] * sc, R[2][k] * sc), s);
      values[k] = p === p ? p : 0;
    }
    boxBlur(values, W, H, blur);
    var out = { values: values, motion: null };
    if (!I.rate || !I.prev) return out;
    var motion = motionField(zeros0(I.prev), zeros0(I.rate), W, H);
    out.motion = { tiles: motion.tiles, field: motion.field };
    return out;
  }

  // ---------- radar: one Level II sweep rendered once to a Web-Mercator image ----------
  var DBZ_COLORS = [[5, "#04e9e7"], [10, "#019ff4"], [15, "#0300f4"], [20, "#02fd02"], [25, "#01c501"], [30, "#008e00"],
    [35, "#fdf802"], [40, "#e5bc00"], [45, "#fd9500"], [50, "#fd0000"], [55, "#d40000"], [60, "#bc0000"],
    [65, "#f800fd"], [70, "#9854c6"], [75, "#fdfdfd"]];
  // buf: serve.py payload (u32 header length, JSON header, f32 azimuths, u8 gates). size: image width/height in px.
  function renderSweep(buf, size) {
    var dv = new DataView(buf), hl = dv.getUint32(0, true);
    var meta = JSON.parse(new TextDecoder().decode(new Uint8Array(buf, 4, hl)));
    var az = new Float32Array(buf, 4 + hl, meta.nrad), gates = new Uint8Array(buf, 4 + hl + 4 * meta.nrad, meta.nrad * meta.ngates);
    var lut = new Int16Array(3600), j = 0, n = az.length;             // 0.1° bins -> nearest radial
    for (var b = 0; b < 3600; b++) {
      var a = b / 10 + 0.05;
      while (j < n - 1 && Math.abs(az[j + 1] - a) <= Math.abs(az[j] - a)) j++;
      var best = j, dd = Math.abs(az[j] - a);
      if (Math.abs(az[0] + 360 - a) < dd) { best = 0; dd = Math.abs(az[0] + 360 - a); }
      if (Math.abs(az[n - 1] - 360 - a) < dd) best = n - 1;
      lut[b] = best;
    }
    var col = new Uint32Array(256), little = new Uint8Array(new Uint32Array([1]).buffer)[0] === 1;
    for (var raw = 2; raw < 256; raw++) {
      var dbz = (raw - meta.offset) / meta.scale, hex = null;
      for (var c = DBZ_COLORS.length - 1; c >= 0; c--) if (dbz >= DBZ_COLORS[c][0]) { hex = DBZ_COLORS[c][1]; break; }
      if (hex) { var h = parseInt(hex.slice(1), 16), r = (h >> 16) & 255, g = (h >> 8) & 255, bl = h & 255; col[raw] = little ? ((255 << 24) | (bl << 16) | (g << 8) | r) >>> 0 : ((r << 24) | (g << 16) | (bl << 8) | 255) >>> 0; }
    }
    var maxR = meta.first_m + meta.gate_m * meta.ngates, lat0 = meta.lat, lon0 = meta.lon;
    var kx = 111320 * Math.cos(lat0 * Math.PI / 180), ky = 110570;
    var dLat = maxR / ky, dLon = maxR / kx, north = lat0 + dLat, south = lat0 - dLat, west = lon0 - dLon, east = lon0 + dLon;
    var my = function (lat) { return Math.log(Math.tan(Math.PI / 4 + lat * Math.PI / 360)); };
    var yN = my(north), yS = my(south), px = new Uint32Array(size * size), ng = meta.ngates, first = meta.first_m, gw = meta.gate_m;
    for (var py = 0; py < size; py++) {
      var y = yN + (yS - yN) * (py + 0.5) / size, lat = (2 * Math.atan(Math.exp(y)) - Math.PI / 2) * 180 / Math.PI, dy = (lat - lat0) * ky;
      if (Math.abs(dy) > maxR) continue;
      for (var pxi = 0; pxi < size; pxi++) {
        var dx = (west + (east - west) * (pxi + 0.5) / size - lon0) * kx, rr = Math.sqrt(dx * dx + dy * dy);
        if (rr > maxR) continue;
        var gi = Math.round((rr - first) / gw); if (gi < 0 || gi >= ng) continue;
        var ang = Math.atan2(dx, dy) * 57.29578; if (ang < 0) ang += 360;
        var v = gates[lut[Math.floor(ang * 10) % 3600] * ng + gi];
        if (v >= 2) px[py * size + pxi] = col[v];
      }
    }
    delete meta.maxR;
    return { meta: meta, rgba: new Uint8ClampedArray(px.buffer), size: size, bounds: [[south, west], [north, east]] };
  }

  var api = {
    Grid: Grid, gridFromArray: gridFromArray, parseGrib2: parseGrib2,
    EQ: EQ, floodPercent: floodPercent, floodTerms: floodTerms, meanRatio: meanRatio, boxBlur: boxBlur,
    NOWCAST: NOWCAST, motionField: motionField, motionIn: motionIn, compass: compass,
    grib2Header: grib2Header, pngInfo: pngInfo, pngUnfilter: pngUnfilter, reduceField: reduceField, sameRegion: sameRegion, resampleRegion: resampleRegion,
    assembleFrame: assembleFrame, renderSweep: renderSweep, DBZ_COLORS: DBZ_COLORS
  };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.FBCore = api;
})(typeof window !== "undefined" ? window : globalThis);
