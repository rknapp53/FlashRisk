const fs = require("fs"), zlib = require("zlib"), assert = require("assert");
const UPNG = require("upng-js");
const C = require("../src/core.js");

// 1) GRIB2 PNG round trip (MRMS-style file written by make_grib.py)
const g = C.parseGrib2(new Uint8Array(zlib.gunzipSync(fs.readFileSync(process.argv[2]))), UPNG);
assert.strictEqual(g.ni, 7); assert.strictEqual(g.nj, 5);
assert(Math.abs(g.lat0 - 54.995) < 1e-6 && Math.abs(g.lon0 - -129.995) < 1e-6);
for (let j = 0; j < 5; j++) for (let i = 0; i < 7; i++) {
  const v = g.get(j * 7 + i);
  if (j === 2 && i === 3) assert(Number.isNaN(v), "missing should be NaN");
  else assert(Math.abs(v - (j * 7 + i) * 0.5) < 1e-6, `cell ${i},${j} = ${v}`);
}
assert.strictEqual(g.meta.refTime.toISOString(), "2026-11-03T17:40:00.000Z");
console.log("GRIB2 PNG decode: ok");

// 2) Equation + helpers
assert(Math.abs(C.floodPercent(2.0, 1.0, 0.70) - 0.5) < 1e-9, "onset point is 50%");
assert(Math.abs(C.floodPercent(2.0, 1.0) - 0.5) < 1e-9, "no soil term when S is missing");
assert(C.floodPercent(2.0, 1.0, 0.95) > 0.65 && C.floodPercent(2.0, 1.0, 0.40) < 0.32, "wet soil raises, dry soil lowers");
assert(C.floodPercent(6, 1.5) > 0.85 && C.floodPercent(0.1, 0.1) < 0.02);
assert(C.floodPercent(NaN, 1.2) > 0.5 && Number.isNaN(C.floodPercent(NaN, NaN)));
assert.strictEqual(C.meanRatio(1, NaN, 2), 1.5);
assert(Number.isNaN(C.meanRatio(NaN, NaN, NaN)));
const a = new Float32Array([0, 0, 9, 0, 0]); C.boxBlur(a, 5, 1, 1);
assert.deepStrictEqual(Array.from(a), [0, 3, 3, 3, 0]);
console.log("equation + helpers: ok");
