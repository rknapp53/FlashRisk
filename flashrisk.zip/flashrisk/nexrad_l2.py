"""NEXRAD Level II (Archive II) reader for FlashRisk — standard library only.

Reads just the lowest-elevation reflectivity sweep from a volume file in the
unidata-nexrad-level2 AWS bucket, using HTTP byte ranges so a 5-15 MB volume
usually costs 1-2 MB of download.

Archive II layout (ICD 2620010):
  24-byte volume header ("AR2V00xx.", date, time, ICAO)
  then LDM records: 4-byte big-endian size, followed by that many bytes of bzip2 data.
  Each decompressed record holds messages, each preceded by a 12-byte CTM header:
    message header (16 bytes): size_hw u16, channel u8, type u8, seq u16, jdate u16, ms u32, nseg u16, seg u16
    type 31 messages are variable length (12 + 2*size_hw bytes from CTM start);
    every other type occupies a fixed 2432-byte frame.
  Message 31 data header (offsets from its own start, right after the 16-byte header):
    0 radar id (4s), 4 collect ms (u32), 8 mjd (u16), 10 az number (u16), 12 azimuth (f32),
    16 compression (u8), 17 spare, 18 radial length (u16), 20 az spacing (u8), 21 radial status (u8),
    22 elevation number (u8), 23 cut sector (u8), 24 elevation angle (f32), 28 spot blank (u8),
    29 az indexing (u8), 30 block count (u16), 32.. block pointers (u32 each, relative to 0)
  Moment block ("D" + 3-char name): 4 reserved (u32), 8 ngates (u16), 10 first gate m (u16),
    12 gate spacing m (u16), 14 tover, 16 snr, 18 control (u8), 19 word size (u8),
    20 scale (f32), 24 offset (f32), 28.. data.  value = (raw - offset) / scale; raw 0/1 = no data.
  Volume block ("RVOL"): 8 lat (f32), 12 lon (f32).
"""
import bz2
import json
import re
import struct
import xml.etree.ElementTree as ET

BUCKET = "https://unidata-nexrad-level2.s3.amazonaws.com/"
CHUNK = 1_200_000
MAX_BYTES = 12_000_000
_KEY_RE = re.compile(r"/([A-Z]{4})(\d{8})_(\d{6})(?:_V0\d)?(?:\.gz)?$")


def list_scans(fetch, site, day):
    """Volume keys for one site and UTC day (YYYY/MM/DD), oldest first: [(key, epoch_s)]."""
    import calendar
    out, token = [], None
    for _ in range(10):
        url = BUCKET + "?list-type=2&prefix=" + f"{day}/{site}/"
        if token:
            from urllib.parse import quote
            url += "&continuation-token=" + quote(token, safe="")
        code, _, body, _ = fetch(url)
        if code >= 400:
            raise RuntimeError(f"S3 listing HTTP {code}")
        root = ET.fromstring(body)
        ns = {"s3": root.tag.split("}")[0].strip("{")} if root.tag.startswith("{") else {}
        q = (lambda tag: "s3:" + tag) if ns else (lambda tag: tag)
        for c in root.findall(q("Contents"), ns):
            key = c.findtext(q("Key"), default="", namespaces=ns)
            if key.endswith("_MDM"):
                continue
            m = _KEY_RE.search(key)
            if not m:
                continue
            d, t = m.group(2), m.group(3)
            ts = calendar.timegm((int(d[:4]), int(d[4:6]), int(d[6:]), int(t[:2]), int(t[2:4]), int(t[4:]), 0, 0, 0))
            out.append((key, ts))
        if root.findtext(q("IsTruncated"), default="false", namespaces=ns) == "true":
            token = root.findtext(q("NextContinuationToken"), default=None, namespaces=ns)
            if not token:
                break
        else:
            break
    return sorted(out, key=lambda x: x[1])


class _RangeReader:
    """Grows a byte buffer with HTTP Range requests as the parser asks for more."""

    def __init__(self, fetch, url):
        self.fetch, self.url, self.buf, self.eof = fetch, url, bytearray(), False

    def ensure(self, n):
        while len(self.buf) < n and not self.eof:
            if len(self.buf) >= MAX_BYTES:
                raise RuntimeError("lowest tilt not found in the first 12 MB")
            start = len(self.buf)
            code, _, body, _ = self.fetch(self.url, {"Range": f"bytes={start}-{start + CHUNK - 1}"})
            if code == 416:
                self.eof = True
                break
            if code >= 400:
                raise RuntimeError(f"Level II download HTTP {code}")
            if code == 200 and start > 0:      # server ignored Range and sent the whole file
                body = body[start:]
            if code == 200:
                self.eof = True
            self.buf.extend(body)
            if len(body) < CHUNK:
                self.eof = True
        return len(self.buf) >= n


def lowest_reflectivity(fetch, key):
    """Return (header dict, azimuths list, packed gate bytes) for the lowest REF sweep."""
    url = BUCKET + key
    rd = _RangeReader(fetch, url)
    if not rd.ensure(24):
        raise RuntimeError("file too short")
    head = bytes(rd.buf[:24])
    if not head.startswith(b"AR2V"):
        if head[:2] == b"\x1f\x8b":
            raise RuntimeError("gzipped archive files are not supported")
        raise RuntimeError("not an Archive II file")
    pos, radials, meta, done = 24, [], {}, False
    while not done:
        if not rd.ensure(pos + 4):
            break
        size = abs(struct.unpack_from(">i", rd.buf, pos)[0])
        pos += 4
        if size == 0:
            break
        if not rd.ensure(pos + size):
            break
        data = bz2.decompress(bytes(rd.buf[pos:pos + size]))
        pos += size
        p = 0
        while p + 28 <= len(data):
            size_hw, _ch, mtype = struct.unpack_from(">HBB", data, p + 12)
            if mtype == 31 and size_hw:
                m = p + 28                                  # start of message 31 data header
                elev_num = data[m + 22]
                if radials and elev_num != meta["elev_num"]:
                    done = True
                    break
                az = struct.unpack_from(">f", data, m + 12)[0]
                elev = struct.unpack_from(">f", data, m + 24)[0]
                nblk = struct.unpack_from(">H", data, m + 30)[0]
                ptrs = struct.unpack_from(">" + "I" * min(nblk, 10), data, m + 32)
                ref = None
                for ptr in ptrs:
                    b = m + ptr
                    name = data[b:b + 4]
                    if name == b"RVOL" and "lat" not in meta:
                        meta["lat"], meta["lon"] = struct.unpack_from(">ff", data, b + 8)
                    elif name == b"DREF":
                        ng, first, gw = struct.unpack_from(">HHH", data, b + 8)
                        word = data[b + 19]
                        scale, offset = struct.unpack_from(">ff", data, b + 20)
                        if word == 8:
                            ref = (ng, first, gw, scale, offset, bytes(data[b + 28:b + 28 + ng]))
                if ref is not None:
                    if not radials:
                        meta.update(elev_num=elev_num, elev=round(elev, 2), ngates=ref[0], first_m=ref[1], gate_m=ref[2],
                                    scale=ref[3], offset=ref[4],
                                    ms=struct.unpack_from(">I", data, m + 4)[0], mjd=struct.unpack_from(">H", data, m + 8)[0])
                    radials.append((az, ref[5]))
                p += 12 + 2 * size_hw
            else:
                p += 2432
    if not radials:
        raise RuntimeError("no reflectivity radials found")
    ng = meta["ngates"]
    radials.sort(key=lambda r: r[0])
    gates = bytearray(len(radials) * ng)
    for i, (_, g) in enumerate(radials):
        gates[i * ng:i * ng + min(ng, len(g))] = g[:ng]
    meta["nrad"] = len(radials)
    meta["time"] = (meta.pop("mjd") - 1) * 86400 + meta.pop("ms") / 1000.0   # epoch seconds
    meta["bytes_read"] = len(rd.buf)
    return meta, [r[0] for r in radials], bytes(gates)


def pack(meta, azimuths, gates):
    """Binary payload for the browser: u32 LE header length, JSON header, f32 LE azimuths, u8 gates."""
    h = json.dumps(meta).encode()
    h += b" " * ((4 - (4 + len(h)) % 4) % 4)          # keep the float array 4-byte aligned
    return struct.pack("<I", len(h)) + h + struct.pack("<%df" % len(azimuths), *azimuths) + gates
