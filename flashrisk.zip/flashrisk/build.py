import pathlib, sys
src = pathlib.Path("src")
html = (src / "index.html").read_text()
html = html.replace("/*CORE*/", (src / "core.js").read_text()).replace("/*APP*/", (src / "app.js").read_text())
out = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "dist/index.html")
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(html)
print("built", out, len(html), "bytes")
landing = out.parent / "landing.html"
landing.write_text((src / "landing.html").read_text())
print("built", landing)
import json
worker = out.parent / "worker.js"   # Cloudflare Worker that shows src/offline.html when the tunnel or serve.py is down
worker.write_text(pathlib.Path("cloudflare/worker.template.js").read_text().replace('/*OFFLINE_HTML*/""', json.dumps((src / "offline.html").read_text())))
print("built", worker)
