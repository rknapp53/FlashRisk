// Storm-motion checks on a synthetic storm moving east-northeast at ~40 km/h on 5 km cells.
const assert = require("assert");
const C = require("../src/core.js");
const W = 120, H = 80, U = 8 / 60, V = -4 / 60;   // cells per minute (8 cells/h east, 4 cells/h north)
function storm(cx, cy, peak, sig) {
  const a = new Float32Array(W * H);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const d2 = ((x - cx) ** 2 + (y - cy) ** 2) / (2 * sig * sig);
    a[y * W + x] = peak * Math.exp(-d2) + (((x * 7 + y * 13) % 5) === 0 ? 0.3 : 0);   // a little texture
  }
  return a;
}
const dt = C.NOWCAST.dtMin;
const prev = storm(40, 50, 60, 6), cur = storm(40 + U * dt, 50 + V * dt, 60, 6);

// 1) motion
const m = C.motionField(prev, cur, W, H);
const k = 50 * W + 43;
console.log("motion at storm (cells/min): u=%s v=%s  (truth %s, %s)", m.u[k].toFixed(3), m.v[k].toFixed(3), U.toFixed(3), V.toFixed(3));
assert(Math.abs(m.u[k] - U) < 0.04 && Math.abs(m.v[k] - V) < 0.04, "motion recovered");

// 7) motion is reported for the area asked about: a NW-moving storm in the south-east of the grid and a
//    NE-moving storm in the north-west, on a 0.05° grid like the app's (rows run south).
{
  const W2 = 160, H2 = 120, grid = { north: 32, west: -86, dLat: -0.05, dLon: 0.05 };
  const two = (sh) => {
    const a = new Float32Array(W2 * H2);
    const blob = (cx, cy) => { for (let y = 0; y < H2; y++) for (let x = 0; x < W2; x++) { const d2 = ((x - cx) ** 2 + (y - cy) ** 2) / 50; a[y * W2 + x] += 50 * Math.exp(-d2) + (((x * 7 + y * 13) % 5) === 0 ? 0.3 : 0); } };
    blob(120 - 3 * sh, 90 - 3 * sh);   // moves up-left: west and north = NW
    blob(30 + 3 * sh, 30 - 3 * sh);    // moves up-right: east and north = NE
    return a;
  };
  const mf = C.motionField(two(0), two(1), W2, H2);
  const lat = j => grid.north + j * grid.dLat, lon = i => grid.west + i * grid.dLon;
  const se = C.motionIn(mf.field, grid, { north: lat(60), south: lat(H2), west: lon(80), east: lon(W2) });
  const nw = C.motionIn(mf.field, grid, { north: lat(0), south: lat(60), west: lon(0), east: lon(80) });
  console.log("motion in view: SE box toward %s° (%s) %s mph; NW box toward %s° (%s) %s mph",
    se.toward.toFixed(0), C.compass(se.toward), se.mph.toFixed(0), nw.toward.toFixed(0), C.compass(nw.toward), nw.mph.toFixed(0));
  assert(Math.abs(se.toward - 315) < 20 && C.compass(se.toward) === "NW", "south-east storm moves NW");
  assert(Math.abs(nw.toward - 45) < 20 && C.compass(nw.toward) === "NE", "north-west storm moves NE");
  assert(C.motionIn(mf.field, grid, { north: 50, south: 45, west: -70, east: -60 }) === null, "no rain in box -> null");
  console.log("motion in view: ok");
}

console.log("storm motion: ok");
