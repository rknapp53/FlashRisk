#!/usr/bin/env python3
"""FlashRisk local server: serves the app, relays MRMS FLASH data, and decodes NEXRAD Level II radar.

Run:  python3 serve.py          then open http://localhost:8787
Check: http://localhost:8787/api/check   tests every data source and shows what failed.
Uses only the Python standard library. Listens on this computer only (127.0.0.1).
"""
import gzip
import http.server
import re
import threading
from collections import OrderedDict
import json
import pathlib
import shutil
import socketserver
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

import nexrad_l2

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8787
ROOT = pathlib.Path(__file__).resolve().parent
PAGE = ROOT / "dist" / "index.html"
if not PAGE.exists():
    PAGE = ROOT / "index.html"
LANDING = next((f for f in (ROOT / "dist" / "landing.html", ROOT / "src" / "landing.html", ROOT / "landing.html") if f.exists()), None)
ALLOWED = {
    "mrms.ncep.noaa.gov",            # FLASH CREST and QPE/FFG grids, MRMS rain rate/QPE, directory listings for the loop
    "mapservices.weather.noaa.gov",  # one-time QPE/FFG unit check
    "opengeo.ncep.noaa.gov",         # radar site list
    "mesonet.agron.iastate.edu",     # NWS warnings and storm reports (verification)
}
_F = "https://mrms.ncep.noaa.gov/2D/FLASH/{0}/MRMS_FLASH_{0}.latest.grib2.gz"
def checks():
    now = time.time()
    sts, ets = time.strftime("%Y-%m-%dT%H:%MZ", time.gmtime(now - 6 * 3600)), time.strftime("%Y-%m-%dT%H:%MZ", time.gmtime(now))
    return [
        ("FLASH CREST max unit streamflow", _F.format("CREST_MAXUNITSTREAMFLOW")),
        ("FLASH QPE/FFG 1 h", _F.format("QPE_FFG01H")),
        ("FLASH QPE/FFG 3 h", _F.format("QPE_FFG03H")),
        ("FLASH QPE/FFG 6 h", _F.format("QPE_FFG06H")),
        ("FLASH CREST soil saturation", _F.format("CREST_MAXSOILSAT")),
        ("FLASH CREST file list (loop)", "https://mrms.ncep.noaa.gov/2D/FLASH/CREST_MAXUNITSTREAMFLOW/"),
        ("MRMS rain rate (storm motion)", "https://mrms.ncep.noaa.gov/2D/PrecipRate/"),
        ("NWS MRMS QPE service (unit check)", "https://mapservices.weather.noaa.gov/raster/rest/services/obs/mrms_qpe/ImageServer?f=json"),
        ("NWS FFG service (unit check)", "https://mapservices.weather.noaa.gov/raster/rest/services/precip/rfc_gridded_ffg/MapServer?f=json"),
        ("NWS radar site list", "https://opengeo.ncep.noaa.gov/geoserver/nws/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=nws:radar_sites&outputFormat=application/json"),
        ("AWS Level II file list (KMLB today)", nexrad_l2.BUCKET + "?list-type=2&max-keys=5&prefix=" + time.strftime("%Y/%m/%d", time.gmtime()) + "/KMLB/"),
        ("IEM warnings (MLB, last 6 h)", "https://mesonet.agron.iastate.edu/geojson/sbw.py?sts=" + sts + "&ets=" + ets + "&wfos=MLB"),
        ("IEM storm reports (MLB, last 6 h)", "https://mesonet.agron.iastate.edu/geojson/lsr.py?sts=" + sts + "&ets=" + ets + "&wfos=MLB"),
    ]

# Python from python.org on macOS often ships without CA certificates. Try certifi,
# and fall back to the system curl (which uses the OS certificate store).
SSL_CTX = ssl.create_default_context()
try:
    import certifi  # type: ignore
    SSL_CTX = ssl.create_default_context(cafile=certifi.where())
except Exception:
    pass
CURL = shutil.which("curl")
use_curl = False  # switches on after the first certificate failure


def fetch(url, headers=None):
    """Return (status, content_type, body, via). Raises on network failure."""
    global use_curl
    hdrs = {"User-Agent": "FlashRisk local relay"}
    hdrs.update(headers or {})
    if not use_curl:
        req = urllib.request.Request(url, headers=hdrs)
        try:
            with urllib.request.urlopen(req, timeout=60, context=SSL_CTX) as r:
                return r.status, r.headers.get("Content-Type", "application/octet-stream"), r.read(), "python"
        except urllib.error.HTTPError as e:
            return e.code, "text/plain; charset=utf-8", f"Upstream HTTP {e.code}".encode(), "python"
        except urllib.error.URLError as e:
            if isinstance(e.reason, ssl.SSLError) and CURL:
                use_curl = True
                print("Python couldn't verify SSL certificates; switching to the system curl.", file=sys.stderr)
            else:
                raise
    if not CURL:
        raise RuntimeError("No working HTTPS client (Python certificates missing and curl not found)")
    cmd = [CURL, "-sS", "-L", "--max-time", "60", "-w", "\n%{http_code} %{content_type}"]
    for k, val in hdrs.items():
        cmd += ["-H", f"{k}: {val}"]
    p = subprocess.run(cmd + [url], capture_output=True)
    if p.returncode != 0:
        raise RuntimeError(p.stderr.decode(errors="replace").strip() or f"curl exit {p.returncode}")
    body, _, tail = p.stdout.rpartition(b"\n")
    code, _, ctype = tail.decode().partition(" ")
    return int(code or 502), ctype or "application/octet-stream", body, "curl"


# ---------- NEXRAD Level II (AWS unidata-nexrad-level2) ----------
_SITE_RE = re.compile(r"^[A-Z]{4}$")
_KEY_OK = re.compile(r"^\d{4}/\d{2}/\d{2}/[A-Z]{4}/[A-Z]{4}\d{8}_\d{6}(_V0\d)?$")
_list_cache, _scan_cache, _lock = {}, OrderedDict(), threading.Lock()


def l2_list(site, start, end):
    days, t = [], start - (start % 86400)
    while t <= end and len(days) < 3:
        days.append(time.strftime("%Y/%m/%d", time.gmtime(t)))
        t += 86400
    out = []
    for day in days:
        ck = (site, day)
        hit = _list_cache.get(ck)
        if not hit or time.time() - hit[0] > 90:
            hit = (time.time(), nexrad_l2.list_scans(fetch, site, day))
            _list_cache[ck] = hit
        out += [{"key": k, "t": int(ts * 1000)} for k, ts in hit[1] if start - 900 <= ts <= end + 300]
    return out


def l2_scan(key):
    with _lock:
        if key in _scan_cache:
            _scan_cache.move_to_end(key)
            return _scan_cache[key]
    meta, az, gates = nexrad_l2.lowest_reflectivity(fetch, key)
    meta["key"] = key
    blob = gzip.compress(nexrad_l2.pack(meta, az, gates), 5)
    with _lock:
        _scan_cache[key] = blob
        while len(_scan_cache) > 60:
            _scan_cache.popitem(last=False)
    return blob


class Handler(http.server.BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="text/plain; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/offline":                       # preview of the "down for rest" page the Cloudflare Worker shows
            f = ROOT / "src" / "offline.html"
            return self._send(200, f.read_bytes(), "text/html; charset=utf-8") if f.exists() else self._send(404, b"Not found")
        if parsed.path in ("/", "/index.html") and LANDING:     # landing page; its Enter button goes to /map
            return self._send(200, LANDING.read_bytes(), "text/html; charset=utf-8")
        if parsed.path in ("/", "/index.html", "/map", "/map/"):
            return self._send(200, PAGE.read_bytes(), "text/html; charset=utf-8")
        if parsed.path == "/api/check":
            return self._check()
        if parsed.path == "/data/us_places.tsv":         # city names for the contour graphic
            f = ROOT / "data" / "us_places.tsv"
            return self._send(200, f.read_bytes(), "text/tab-separated-values; charset=utf-8") if f.exists() else self._send(404, b"Not found")
        if parsed.path.startswith("/api/l2/"):
            return self._level2(parsed)
        if parsed.path != "/api/relay":
            return self._send(404, b"Not found")
        target = urllib.parse.parse_qs(parsed.query).get("url", [""])[0]
        t = urllib.parse.urlparse(target)
        if t.scheme != "https" or t.hostname not in ALLOWED:
            print(f"  blocked host: {t.hostname}", file=sys.stderr)
            return self._send(403, f"Host not allowed: {t.hostname}".encode())
        started = time.time()
        try:
            code, ctype, body, via = fetch(target)
        except Exception as e:
            print(f"  FAIL {t.hostname}{t.path[:60]}  {e}", file=sys.stderr)
            return self._send(502, f"Upstream error: {e}".encode())
        mark = "ok  " if code < 400 else "FAIL"
        print(f"  {mark} {code} {t.hostname}{t.path[:60]}  {len(body)//1024} KB  {time.time()-started:.1f}s via {via}", file=sys.stderr)
        return self._send(code, body, ctype)

    def _level2(self, parsed):
        q = urllib.parse.parse_qs(parsed.query)
        started = time.time()
        try:
            if parsed.path == "/api/l2/list":
                site = q.get("site", [""])[0].upper()
                if not _SITE_RE.match(site):
                    return self._send(400, b"bad site")
                start, end = int(q.get("start", ["0"])[0]) // 1000, int(q.get("end", ["0"])[0]) // 1000
                body = json.dumps({"site": site, "scans": l2_list(site, start, end)}).encode()
                print(f"  ok   L2 list {site}  {time.time()-started:.1f}s", file=sys.stderr)
                return self._send(200, body, "application/json")
            if parsed.path == "/api/l2/scan":
                key = q.get("key", [""])[0]
                if not _KEY_OK.match(key):
                    return self._send(400, b"bad key")
                blob = l2_scan(key)
                print(f"  ok   L2 scan {key.rsplit('/', 1)[-1]}  {len(blob)//1024} KB  {time.time()-started:.1f}s", file=sys.stderr)
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Encoding", "gzip")
                self.send_header("Content-Length", str(len(blob)))
                self.send_header("Cache-Control", "max-age=86400")
                self.end_headers()
                self.wfile.write(blob)
                return None
        except Exception as e:
            print(f"  FAIL L2 {parsed.path} {parsed.query[:80]}  {e}", file=sys.stderr)
            return self._send(502, f"Level II error: {e}".encode())
        return self._send(404, b"Not found")

    def _check(self):
        rows = []
        for name, url in checks():
            started = time.time()
            try:
                code, ctype, body, via = fetch(url)
                ok = code < 400 and len(body) > 100
                if code < 400 and "/geojson/" in url and body.lstrip()[:1] == b"{":
                    try:                                  # an empty list is a valid answer: nothing reported yet
                        ok, n = True, len(json.loads(body).get("features", []))
                    except ValueError:
                        ok, n = False, 0
                    note = f"HTTP {code}, {n} item{'s' if n != 1 else ''}, {time.time()-started:.1f}s via {via}"
                else:
                    note = f"HTTP {code}, {len(body)//1024} KB, {time.time()-started:.1f}s via {via}"
            except Exception as e:
                ok, note = False, str(e)
            rows.append({"source": name, "ok": ok, "detail": note})
        report = {
            "python": sys.version.split()[0],
            "certificates": "certifi" if SSL_CTX.cert_store_stats().get("x509_ca", 0) and "certifi" in sys.modules else "system default",
            "https_client": "curl fallback" if use_curl else "python",
            "results": rows,
        }
        return self._send(200, json.dumps(report, indent=2).encode(), "application/json")

    def log_message(self, fmt, *args):
        pass  # relay requests are logged above in plain words


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


if __name__ == "__main__":
    try:
        httpd = Server(("127.0.0.1", PORT), Handler)
    except OSError as e:
        sys.exit(f"Port {PORT} is busy ({e.strerror}). Try: python3 serve.py {PORT + 1}")
    with httpd:
        print(f"FlashRisk running at http://localhost:{PORT}")
        print(f"Data check:            http://localhost:{PORT}/api/check")
        print("Press Ctrl+C to stop.")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            pass
