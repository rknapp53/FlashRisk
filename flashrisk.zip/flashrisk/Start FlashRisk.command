#!/bin/bash
# Double-click to start FlashRisk on a Mac. Keep this window open while you use it.
cd "$(dirname "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 isn't installed. A box should appear offering to install the Command Line Tools — click Install, then run this again."
  xcode-select --install 2>/dev/null
  read -r -p "Press Return to close."
  exit 1
fi
PORT=8787
while lsof -iTCP:$PORT -sTCP:LISTEN >/dev/null 2>&1; do PORT=$((PORT + 1)); done
( sleep 2; open "http://localhost:$PORT/" ) &
echo "Opening FlashRisk in your browser (http://localhost:$PORT). Close this window or press Control-C to stop."
python3 serve.py $PORT
