// FlashRisk "down for rest" Worker.
// Sits in front of the Cloudflare Tunnel hostname. Every request goes to the tunnel as normal;
// when the Mac, cloudflared or serve.py isn't running, visitors get the resting page instead of a Cloudflare error.
// build.py writes the deployable copy to dist/worker.js with the page from src/offline.html filled in.

const OFFLINE_HTML = /*OFFLINE_HTML*/"";

// 502-504: cloudflared is up but serve.py isn't answering. 520-530: Cloudflare couldn't reach the origin;
// 530 is what a Worker gets back when the tunnel itself is down (error 1033).
const DOWN = new Set([502, 503, 504, 520, 521, 522, 523, 524, 525, 526, 527, 530]);

export default {
  async fetch(request) {
    let res;
    try {
      res = await fetch(request);
    } catch (e) {
      return offline(request);
    }
    return DOWN.has(res.status) ? offline(request) : res;
  },
};

function offline(request) {
  const path = new URL(request.url).pathname;
  // Data calls from an open map get a short plain answer; page visits get the resting page.
  if (path.startsWith("/api/") || path.startsWith("/data/")) {
    return new Response("FlashRisk servers are resting", {
      status: 503,
      headers: { "content-type": "text/plain; charset=utf-8", "retry-after": "300", "cache-control": "no-store", "x-flashrisk-offline": "1" },
    });
  }
  return new Response(OFFLINE_HTML, {
    status: 503,   // 503 tells search engines and monitors this is temporary
    headers: { "content-type": "text/html; charset=utf-8", "retry-after": "300", "cache-control": "no-store", "x-flashrisk-offline": "1" },
  });
}
